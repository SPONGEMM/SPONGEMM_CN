#ifndef SELECT_CUH
#define SELECT_CUH

#include "../common.cuh"
#include <vector>

struct SELECT
{
    std::vector<float*> select_atom_energy;
    std::vector<float*> select_energy;
    std::vector<VECTOR*> select_force;
    std::vector<float*> select_atom_virial;
    std::vector<float*> select_virial;

    void Initial();

    int Add_One_Energy(int atom_numbers);

    int Add_One_Force(int atom_numbers);

    int Add_One_Virial(int atom_numbers);

    void Clear();
};

#endif