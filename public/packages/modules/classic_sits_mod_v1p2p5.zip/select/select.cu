#include "select.cuh"

void SELECT::Initial()
{
    //select_atom_energy = vector();
    //select_energy = vector();
    //select_force = vector();
    //select_atom_virial = vector();
    //select_virial = vector();
}

int SELECT::Add_One_Energy(int atom_numbers)
{
    float * tmp_atom_energy;
    float * tmp_energy;
    Cuda_Malloc_Safely((void**)&tmp_atom_energy, sizeof(float)*atom_numbers);
    Cuda_Malloc_Safely((void**)&tmp_energy, sizeof(float));
    select_atom_energy.push_back(tmp_atom_energy);
    select_energy.push_back(tmp_energy);
    return select_energy.size()-1;
}

int SELECT::Add_One_Force(int atom_numbers)
{
    VECTOR * tmp_force;
    Cuda_Malloc_Safely((void**)&tmp_force, sizeof(VECTOR)*atom_numbers);
    select_force.push_back(tmp_force);
    return (select_force.size() - 1);
}

int SELECT::Add_One_Virial(int atom_numbers)
{
    float * tmp_atom_virial;
    float * tmp_virial;
    Cuda_Malloc_Safely((void**)&tmp_atom_virial, sizeof(float)*atom_numbers);
    Cuda_Malloc_Safely((void**)&tmp_virial, sizeof(float)*atom_numbers);
    select_atom_virial.push_back(tmp_atom_virial);
    select_virial.push_back(tmp_virial);
    return select_virial.size()-1;
}

void SELECT::Clear()
{
    int size = select_atom_energy.size();
    for (int i = 0; i < size; ++i)
    {
        cudaFree(select_atom_energy[i]);
        cudaFree(select_energy[i]);
    }
    size = select_force.size();
    for (int i = 0; i < size; ++i)
    {
        cudaFree(select_force[i]);
        cudaFree(select_force[i]);
    }
    size = select_virial.size();
    for (int i = 0; i < size; ++i)
    {
        cudaFree(select_virial[i]);
        cudaFree(select_virial[i]);
    }
}