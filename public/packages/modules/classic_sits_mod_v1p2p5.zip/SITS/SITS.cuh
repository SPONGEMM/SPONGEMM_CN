#ifndef SITS_CUH
#define SITS_CUH

#include "../common.cuh"
#include "../control.cuh"
#include "../select/select.cuh"
#include "../Lennard_Jones_force/Lennard_Jones_force.cuh"

enum SITS_MODE
{
    CLASSIC = 0,
};

struct CLASSIC_SITS_INFORMATION ;
struct SITS_INFORMATION ;

struct CLASSIC_SITS_INFORMATION
{
    int is_initialized = 0;

    SITS_INFORMATION * sits_controller;
    int k_numbers;
    float * beta_k;
    float * NkExpBetakU;
    float * Nk;
    float * sum_a;
    float * sum_b;
    float * factor;

    int record_count;
    int record_interval;
    int update_interval;
    int reset = 1;

    //ene_recorded - vshift - ene
	//gf - gf - log( n_k * exp(-beta_k * ene) )
	//gfsum - gfsum - log( Sum_(k=1)^N ( log( n_k * exp(-beta_k * ene) ) ) )
	//log_weight - rb - log of the weighting function
	//log_mk_inverse - ratio - log(m_k^-1)
	//log_norm_old - normlold - W(j-1)
	//log_norm - norml - W(j)
	//log_pk - rbfb - log(p_k)
	//log_nk_inverse - pratio - log(n_k^-1)
	//log_nk - fb - log(n_k)

    float *ene_recorded;
	float *gf;
	float *gfsum;
	float *log_weight;
	float *log_mk_inverse;
	float *log_norm_old;
	float *log_norm;
	float *log_pk;
	float *log_nk_inverse;
	float *log_nk;

    float pe_a = 1.0;
    float pe_b = 0.0;
    float fb_bias = 0.0;

    int nk_fix = 0;

    //record
    FILE * nk_traj_file;
    FILE * nk_rest_file; 

    char nk_rest_file_name[CHAR_LENGTH_MAX];
    

    float * nk_record_cpu;
    float * log_norm_record_cpu;

    void Initial(CONTROLLER *controller, SITS_INFORMATION * sits);

    void Memory_Allocate();

    void Clear();

    void SITS_Record_Ene();

    void SITS_Update_gf();

    void SITS_Update_gfsum();

    void SITS_Update_log_pk();

    void SITS_Update_log_mk_inverse();

    void SITS_Update_log_nk_inverse();

    void SITS_Update_nk();

    void SITS_Update_Common();

    void SITS_Update_Nk();

    void SITS_Write_Nk_Norm();

    void SITS_Update_Fb(float beta_0);

    float SITS_Get_Fb();
};

struct SITS_INFORMATION
{
    int is_initialized = 0;
    int sits_mode = 0;
    int atom_numbers;
    int *atom_sys_mark;
    
    float pwwp_enhance_factor = 0.5;
    float h_factor = 1.0;

    float h_pp_energy;
    float h_pw_energy;

    int need_potential;

    SELECT pw_select;

    CLASSIC_SITS_INFORMATION classic_sits;
    
    void Initial(CONTROLLER * controller, int atom_numbers_);

    void Reset_Force_Energy(int md_need_potential);

    float Get_Potential(int is_download = 1);

    void Update(int frame_numbers);

    void Enhance_Force(VECTOR *md_frc, float beta_0);

    void Memory_Allocate();

    void SITS_LJ_Force_With_Direct_CF(const UNSIGNED_INT_VECTOR *uint_crd, float * charge, LENNARD_JONES_INFORMATION * lj_info, VECTOR *md_frc,
        const ATOM_GROUP *nl, const float cutoff, const float pme_beta);

    void SITS_LJ_Direct_CF_Force_With_Atom_Energy(const UNSIGNED_INT_VECTOR *uint_crd, const float * charge,LENNARD_JONES_INFORMATION * lj_info, VECTOR *md_frc,
        const ATOM_GROUP *nl, const float cutoff, const float pme_beta,float *atom_energy_ww);

    float Get_Fb();
    
    void Clear();
};

#endif