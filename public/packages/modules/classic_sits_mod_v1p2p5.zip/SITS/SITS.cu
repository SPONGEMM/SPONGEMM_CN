#include "SITS.cuh"

#define TWO_DIVIDED_BY_SQRT_PI 1.1283791670218446

static __global__ void SITS_LJ_Force_With_Direct_CF_CUDA(
	const int atom_numbers, const ATOM_GROUP *nl,
	const UINT_VECTOR_LJ_TYPE *uint_crd, const VECTOR boxlength,
	const float *LJ_type_A, const float *LJ_type_B, const int * atom_sys_mark, const float cutoff,
	VECTOR *frc_ww, VECTOR *frc_pp, VECTOR *frc_pw, const float pme_beta,const float sqrt_pi)
{
	int atom_i = blockDim.y*blockIdx.y + threadIdx.y;
	if (atom_i < atom_numbers)
	{
		ATOM_GROUP nl_i = nl[atom_i];
		int N = nl_i.atom_numbers;
		int atom_j;
		int int_x;
		int int_y;
		int int_z;
		UINT_VECTOR_LJ_TYPE r1 = uint_crd[atom_i], r2;
		VECTOR dr;
		float dr_2;
		float dr_4;
		float dr_8;
		float dr_6;
		float frc_abs = 0.;
		VECTOR frc_lin_ww, frc_lin_pw, frc_lin_pp;
		VECTOR frc_record_ww = {0., 0., 0.}, frc_record_pw = {0., 0., 0.}, frc_record_pp = { 0., 0., 0. };

		//CF
		float charge_i = r1.charge; //r1.charge;
		float charge_j;
		float dr_abs;
		float dr_1;
		float beta_dr;
		float frc_cf_abs;
		//

		int x, y;
		int atom_pair_LJ_type;
		int atom_mark_i = atom_sys_mark[atom_i], atom_mark_j;
		for (int j = threadIdx.x; j < N; j = j + blockDim.x)
		{
			atom_j = nl_i.atom_serial[j];
			r2 = uint_crd[atom_j];
			//CF
			charge_j = r2.charge;
			atom_mark_j = atom_sys_mark[atom_j];

			int_x = r2.uint_x - r1.uint_x;
			int_y = r2.uint_y - r1.uint_y;
			int_z = r2.uint_z - r1.uint_z;
			dr.x = boxlength.x*int_x;
			dr.y = boxlength.y*int_y;
			dr.z = boxlength.z*int_z;
			dr_abs = norm3df(dr.x, dr.y, dr.z);
			if (dr_abs < cutoff)
			{
				dr_1 = 1. / dr_abs;
				dr_2 = dr_1*dr_1;
				dr_4 = dr_2*dr_2;
				dr_8 = dr_4*dr_4;
				dr_6 = dr_4 * dr_2;


				y = (r2.LJ_type - r1.LJ_type);
				x = y >> 31;
				y = (y^x) - x;
				x = r2.LJ_type + r1.LJ_type;
				r2.LJ_type = (x + y) >> 1;
				x = (x - y) >> 1;
				atom_pair_LJ_type = (r2.LJ_type*(r2.LJ_type + 1) >> 1) + x;


				frc_abs = (-LJ_type_A[atom_pair_LJ_type] * dr_6
					+ LJ_type_B[atom_pair_LJ_type]) * dr_8;
				//PME的直接部分
				beta_dr = pme_beta*dr_abs;
				//sqrt_pi= 2/sqrt(3.141592654);
				frc_cf_abs = beta_dr *sqrt_pi * expf(-beta_dr*beta_dr) + erfcf(beta_dr);
				frc_cf_abs = frc_cf_abs * dr_2 *dr_1;
				frc_cf_abs = charge_i * charge_j*frc_cf_abs;

				frc_abs = frc_abs - frc_cf_abs;

				if (atom_mark_i == 0 && atom_mark_j == 0)
				{
					frc_lin_pp.x = frc_abs*dr.x;
					frc_lin_pp.y = frc_abs*dr.y;
					frc_lin_pp.z = frc_abs*dr.z;

					frc_record_pp.x = frc_record_pp.x + frc_lin_pp.x;
					frc_record_pp.y = frc_record_pp.y + frc_lin_pp.y;
					frc_record_pp.z = frc_record_pp.z + frc_lin_pp.z;
						
					atomicAdd(&frc_pp[atom_j].x, -frc_lin_pp.x);
					atomicAdd(&frc_pp[atom_j].y, -frc_lin_pp.y);
					atomicAdd(&frc_pp[atom_j].z, -frc_lin_pp.z);
				}
				else if (atom_mark_i == 1 && atom_mark_j == 1)
				{
					frc_lin_ww.x = frc_abs*dr.x;
					frc_lin_ww.y = frc_abs*dr.y;
					frc_lin_ww.z = frc_abs*dr.z;

					frc_record_ww.x = frc_record_ww.x + frc_lin_ww.x;
					frc_record_ww.y = frc_record_ww.y + frc_lin_ww.y;
					frc_record_ww.z = frc_record_ww.z + frc_lin_ww.z;
						
					atomicAdd(&frc_ww[atom_j].x, -frc_lin_ww.x);
					atomicAdd(&frc_ww[atom_j].y, -frc_lin_ww.y);
					atomicAdd(&frc_ww[atom_j].z, -frc_lin_ww.z);
				}
				else
				{
					frc_lin_pw.x = frc_abs*dr.x;
					frc_lin_pw.y = frc_abs*dr.y;
					frc_lin_pw.z = frc_abs*dr.z;

					frc_record_pw.x = frc_record_pw.x + frc_lin_pw.x;
					frc_record_pw.y = frc_record_pw.y + frc_lin_pw.y;
					frc_record_pw.z = frc_record_pw.z + frc_lin_pw.z;
						
					atomicAdd(&frc_pw[atom_j].x, -frc_lin_pw.x);
					atomicAdd(&frc_pw[atom_j].y, -frc_lin_pw.y);
					atomicAdd(&frc_pw[atom_j].z, -frc_lin_pw.z);
				}
			}
			
		}//atom_j cycle

		int delta = 32;
		for (int i = 0; i < 5; i += 1)
		{
			delta >>= 1;
			frc_record_pp.x += __shfl_down_sync(0xFFFFFFFF, frc_record_pp.x, delta, 32);
			frc_record_pp.y += __shfl_down_sync(0xFFFFFFFF, frc_record_pp.y, delta, 32);
			frc_record_pp.z += __shfl_down_sync(0xFFFFFFFF, frc_record_pp.z, delta, 32);

			frc_record_pw.x += __shfl_down_sync(0xFFFFFFFF, frc_record_pw.x, delta, 32);
			frc_record_pw.y += __shfl_down_sync(0xFFFFFFFF, frc_record_pw.y, delta, 32);
			frc_record_pw.z += __shfl_down_sync(0xFFFFFFFF, frc_record_pw.z, delta, 32);

			frc_record_ww.x += __shfl_down_sync(0xFFFFFFFF, frc_record_ww.x, delta, 32);
			frc_record_ww.y += __shfl_down_sync(0xFFFFFFFF, frc_record_ww.y, delta, 32);
			frc_record_ww.z += __shfl_down_sync(0xFFFFFFFF, frc_record_ww.z, delta, 32);
		}
		if (threadIdx.x == 0)
		{
			atomicAdd(&frc_pp[atom_i].x, frc_record_pp.x);
			atomicAdd(&frc_pp[atom_i].y, frc_record_pp.y);
			atomicAdd(&frc_pp[atom_i].z, frc_record_pp.z);

			atomicAdd(&frc_ww[atom_i].x, frc_record_ww.x);
			atomicAdd(&frc_ww[atom_i].y, frc_record_ww.y);
			atomicAdd(&frc_ww[atom_i].z, frc_record_ww.z);

			atomicAdd(&frc_pw[atom_i].x, frc_record_pw.x);
			atomicAdd(&frc_pw[atom_i].y, frc_record_pw.y);
			atomicAdd(&frc_pw[atom_i].z, frc_record_pw.z);
		}
	}
}



static __global__ void SITS_LJ_Direct_CF_Force_With_Atom_Energy_CUDA(
	const int atom_numbers, const ATOM_GROUP *nl,
	const UINT_VECTOR_LJ_TYPE *uint_crd, const VECTOR boxlength,
	const float *LJ_type_A, const float *LJ_type_B, const int * atom_sys_mark,const float cutoff,
	VECTOR *frc_ww, VECTOR * frc_pp, VECTOR * frc_pw, const float pme_beta, const float sqrt_pi,float *atom_energy_ww, float * atom_energy_pp, float * atom_energy_pw)
{
	int atom_i = blockDim.y*blockIdx.y + threadIdx.y;
	if (atom_i < atom_numbers)
	{
		ATOM_GROUP nl_i = nl[atom_i];
		int N = nl_i.atom_numbers;
		int atom_j;
		int int_x;
		int int_y;
		int int_z;
		UINT_VECTOR_LJ_TYPE r1 = uint_crd[atom_i], r2;
		VECTOR dr;
		float dr_2;
		float dr_4;
		float dr_8;
		float dr_6;
		float frc_abs = 0.;
		VECTOR frc_lin_ww, frc_lin_pw, frc_lin_pp;
		VECTOR frc_record_ww = {0., 0., 0.}, frc_record_pw = {0., 0., 0.}, frc_record_pp = { 0., 0., 0. };

		//CF
		float charge_i = r1.charge; //r1.charge;
		float charge_j;
		float dr_abs;
		float dr_1;
		float beta_dr;
		float frc_cf_abs;


		//能量
		float ene_lin_pp=0., ene_lin_pw=0., ene_lin_ww = 0.;
		float ene_lin2_pp=0., ene_lin2_pw=0., ene_lin2_ww = 0.;
		
		float tmp_ene, tmp_ene2;

		int x, y;
		int atom_pair_LJ_type;

		int atom_mark_i = atom_sys_mark[atom_i], atom_mark_j;
		for (int j = threadIdx.x; j < N; j = j + blockDim.x)
		{

			atom_j = nl_i.atom_serial[j];
			r2 = uint_crd[atom_j];
			//CF
			charge_j = r2.charge;
			atom_mark_j = atom_sys_mark[atom_j];

			int_x = r2.uint_x - r1.uint_x;
			int_y = r2.uint_y - r1.uint_y;
			int_z = r2.uint_z - r1.uint_z;
			dr.x = boxlength.x*int_x;
			dr.y = boxlength.y*int_y;
			dr.z = boxlength.z*int_z;
			dr_abs = norm3df(dr.x, dr.y, dr.z);
			if (dr_abs < cutoff)
			{

				dr_1 = 1. / dr_abs;
				dr_2 = dr_1*dr_1;
				dr_4 = dr_2*dr_2;
				dr_8 = dr_4*dr_4;
				dr_6 = dr_4 * dr_2;


				y = (r2.LJ_type - r1.LJ_type);
				x = y >> 31;
				y = (y^x) - x;
				x = r2.LJ_type + r1.LJ_type;
				r2.LJ_type = (x + y) >> 1;
				x = (x - y) >> 1;
				atom_pair_LJ_type = (r2.LJ_type*(r2.LJ_type + 1) >> 1) + x;

				frc_abs = (-LJ_type_A[atom_pair_LJ_type] * dr_6
					+ LJ_type_B[atom_pair_LJ_type]) * dr_8;
				//CF
				//dr_abs = sqrtf(dr2);
				beta_dr = pme_beta*dr_abs;
				//sqrt_pi= 2/sqrt(3.141592654);
				frc_cf_abs = beta_dr *sqrt_pi * expf(-beta_dr*beta_dr) + erfcf(beta_dr);
				frc_cf_abs = frc_cf_abs * dr_2 *dr_1;
				frc_cf_abs = charge_i * charge_j*frc_cf_abs;

				//能量
				tmp_ene2 = charge_i * charge_j * erfcf(beta_dr) *dr_1;
				tmp_ene = (0.083333333*LJ_type_A[atom_pair_LJ_type] * dr_6
					- 0.166666666*LJ_type_B[atom_pair_LJ_type]) * dr_6;

				//两种力的绝对值
				frc_abs = frc_abs - frc_cf_abs;


				if (atom_mark_i == 0 && atom_mark_j == 0)
				{
					frc_lin_pp.x = frc_abs*dr.x;
					frc_lin_pp.y = frc_abs*dr.y;
					frc_lin_pp.z = frc_abs*dr.z;

					frc_record_pp.x = frc_record_pp.x + frc_lin_pp.x;
					frc_record_pp.y = frc_record_pp.y + frc_lin_pp.y;
					frc_record_pp.z = frc_record_pp.z + frc_lin_pp.z;

					ene_lin2_pp += tmp_ene2;
					ene_lin_pp += tmp_ene;
						
					atomicAdd(&frc_pp[atom_j].x, -frc_lin_pp.x);
					atomicAdd(&frc_pp[atom_j].y, -frc_lin_pp.y);
					atomicAdd(&frc_pp[atom_j].z, -frc_lin_pp.z);
				}
				else if (atom_mark_i == 1 && atom_mark_j == 1)
				{
					frc_lin_ww.x = frc_abs*dr.x;
					frc_lin_ww.y = frc_abs*dr.y;
					frc_lin_ww.z = frc_abs*dr.z;

					frc_record_ww.x = frc_record_ww.x + frc_lin_ww.x;
					frc_record_ww.y = frc_record_ww.y + frc_lin_ww.y;
					frc_record_ww.z = frc_record_ww.z + frc_lin_ww.z;

					ene_lin2_ww += tmp_ene2;
					ene_lin_ww += tmp_ene;
						
					atomicAdd(&frc_ww[atom_j].x, -frc_lin_ww.x);
					atomicAdd(&frc_ww[atom_j].y, -frc_lin_ww.y);
					atomicAdd(&frc_ww[atom_j].z, -frc_lin_ww.z);
				}
				else
				{
					frc_lin_pw.x = frc_abs*dr.x;
					frc_lin_pw.y = frc_abs*dr.y;
					frc_lin_pw.z = frc_abs*dr.z;

					frc_record_pw.x = frc_record_pw.x + frc_lin_pw.x;
					frc_record_pw.y = frc_record_pw.y + frc_lin_pw.y;
					frc_record_pw.z = frc_record_pw.z + frc_lin_pw.z;

					ene_lin2_pw += tmp_ene2;
					ene_lin_pw += tmp_ene;
						
					atomicAdd(&frc_pw[atom_j].x, -frc_lin_pw.x);
					atomicAdd(&frc_pw[atom_j].y, -frc_lin_pw.y);
					atomicAdd(&frc_pw[atom_j].z, -frc_lin_pw.z);
				}
			}

		}//atom_j cycle
		ene_lin_pp += ene_lin2_pp;
		ene_lin_pw += ene_lin2_pw;
		ene_lin_ww += ene_lin2_ww;
		int delta = 32;
		for (int i = 0; i < 5; i += 1)
		{
			delta >>= 1;
			frc_record_pp.x += __shfl_down_sync(0xFFFFFFFF, frc_record_pp.x, delta, 32);
			frc_record_pp.y += __shfl_down_sync(0xFFFFFFFF, frc_record_pp.y, delta, 32);
			frc_record_pp.z += __shfl_down_sync(0xFFFFFFFF, frc_record_pp.z, delta, 32);

			frc_record_pw.x += __shfl_down_sync(0xFFFFFFFF, frc_record_pw.x, delta, 32);
			frc_record_pw.y += __shfl_down_sync(0xFFFFFFFF, frc_record_pw.y, delta, 32);
			frc_record_pw.z += __shfl_down_sync(0xFFFFFFFF, frc_record_pw.z, delta, 32);

			frc_record_ww.x += __shfl_down_sync(0xFFFFFFFF, frc_record_ww.x, delta, 32);
			frc_record_ww.y += __shfl_down_sync(0xFFFFFFFF, frc_record_ww.y, delta, 32);
			frc_record_ww.z += __shfl_down_sync(0xFFFFFFFF, frc_record_ww.z, delta, 32);
			
			ene_lin_pp += __shfl_down_sync(0xFFFFFFFF, ene_lin_pp, delta, 32);
			ene_lin_pw += __shfl_down_sync(0xFFFFFFFF, ene_lin_pw, delta, 32);
			ene_lin_ww += __shfl_down_sync(0xFFFFFFFF, ene_lin_ww, delta, 32);
		}
		if (threadIdx.x == 0)
		{
			atomicAdd(&frc_pp[atom_i].x, frc_record_pp.x);
			atomicAdd(&frc_pp[atom_i].y, frc_record_pp.y);
			atomicAdd(&frc_pp[atom_i].z, frc_record_pp.z);

			atomicAdd(&frc_ww[atom_i].x, frc_record_ww.x);
			atomicAdd(&frc_ww[atom_i].y, frc_record_ww.y);
			atomicAdd(&frc_ww[atom_i].z, frc_record_ww.z);

			atomicAdd(&frc_pw[atom_i].x, frc_record_pw.x);
			atomicAdd(&frc_pw[atom_i].y, frc_record_pw.y);
			atomicAdd(&frc_pw[atom_i].z, frc_record_pw.z);

			atom_energy_pp[atom_i] += ene_lin_pp;
			atom_energy_pw[atom_i] += ene_lin_pw;
			atom_energy_ww[atom_i] += ene_lin_ww;
		}

		
	}
}


__device__ float log_add_log(float a, float b)
{
	return fmaxf(a, b) + logf(1.0 + expf(-fabsf(a - b)));
}

__global__ void SITS_Record_Ene_CUDA(float * ene_record, const float *pw_ene, const float *pp_ene, const float pe_a, const float pe_b, const float pwwp_enhance_factor)
{
    float temp = *pw_ene * pwwp_enhance_factor + *pp_ene;
	temp = pe_a * temp + pe_b;

	*ene_record = temp;
	//printf("temp = %f!\n", temp);
}

__global__ void SITS_Update_gf_CUDA(const int kn, float *gf,
	const float *ene_record, const float *log_nk, const float *beta_k)
{
    int i = blockDim.x * blockIdx.x + threadIdx.x;
	if (i < kn)
	{
		gf[i] = -beta_k[i] * ene_record[0] + log_nk[i];
	}
}

__global__ void SITS_Update_gfsum_CUDA(const int kn, float *gfsum, const float *gf)
{
	if (threadIdx.x == 0)
	{
		gfsum[0] = -FLT_MAX;
	};
	for (int i = 0; i < kn; i = i + 1)
	{
		gfsum[0] = log_add_log(gfsum[0], gf[i]);
	}
}

__global__ void SITS_Update_log_pk_CUDA(const int kn, float *log_pk, 
	const float *gf, const float *gfsum, const int reset)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	if (i < kn)
	{
		float gfi = gf[i];
		log_pk[i] = ((float)reset) * gfi + ((float)(1 - reset)) * log_add_log(log_pk[i], gfi - gfsum[0]);
	}
}

__global__ void SITS_Update_log_mk_inverse_CUDA(const int kn, 
	float *log_weight, float *log_mk_inverse, float *log_norm_old, 
	float *log_norm, const float *log_pk, const float *log_nk)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	if (i < kn - 1)
	{
		log_weight[i] = (log_pk[i] + log_pk[i + 1]) * 0.5;
		//printf("DEBUG log_weight: %d %f %f\n", i, log_pk[i], log_pk[i + 1]);
		log_mk_inverse[i] = log_nk[i] - log_nk[i + 1];
		log_norm_old[i] = log_norm[i];
		log_norm[i] = log_add_log(log_norm[i], log_weight[i]);
		log_mk_inverse[i] = log_add_log(log_mk_inverse[i] + log_norm_old[i] - log_norm[i], log_pk[i + 1] - log_pk[i] + log_mk_inverse[i] + log_weight[i] - log_norm[i]);
		//printf("DEBUG log_norm: %d %f %f\n", i, log_norm[i], log_weight[i]);
	}
}

__global__ void SITS_Update_log_nk_inverse_CUDA(const int kn,
	float *log_nk_inverse, 	const float *log_mk_inverse)
{
	for (int i = 0; i < kn - 1; i++)
	{
		log_nk_inverse[i + 1] = log_nk_inverse[i] + log_mk_inverse[i];
	}
}

__global__ void SITS_Update_nk_CUDA(const int kn,
	float *log_nk, float *nk, const float *log_nk_inverse)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	if (i < kn )
	{
		log_nk[i] = -log_nk_inverse[i];
		nk[i] = exp(log_nk[i]);
	}
}

__global__ void SITS_For_Enhanced_Force_Calculate_NkExpBetakU_1_CUDA
(const int k_numbers, const float *beta_k, const float *nk,float *nkexpbetaku,
const float ene)
{
	float lin = beta_k[k_numbers-1];
	for (int i = threadIdx.x; i < k_numbers; i = i + blockDim.x)
	{
		nkexpbetaku[i] = nk[i] * expf(-(beta_k[i] - lin) * ene);
		//printf("%f %f\n", beta_k[i], nkexpbetaku[i]);
	}
}

__global__ void SITS_For_Enhanced_Force_Calculate_NkExpBetakU_2_CUDA
(const int k_numbers, const float *beta_k, const float *nk, float *nkexpbetaku,
const float ene)
{
	float lin = beta_k[0];
	for (int i = threadIdx.x; i < k_numbers; i = i + blockDim.x)
	{
		nkexpbetaku[i] = nk[i] * expf(-(beta_k[i] - lin) * ene);
		//printf("%f %f\n", beta_k[i], nkexpbetaku[i]);
	}
}

__global__ void SITS_For_Enhanced_Force_Sum_Of_Above_CUDA
(const int k_numbers, const float *nkexpbetaku, const float *beta_k, float *sum_of_above)
{
	if (threadIdx.x == 0)
	{
		sum_of_above[0] = 0.;
	}
	__syncthreads();
	float lin = 0.;
	for (int i = threadIdx.x; i < k_numbers; i = i + blockDim.x)
	{
		lin = lin + beta_k[i]*nkexpbetaku[i];
	}
	atomicAdd(sum_of_above, lin);
}

__global__ void SITS_For_Enhanced_Force_Sum_Of_NkExpBetakU_CUDA
(const int k_numbers,const float *nkexpbetaku, float *sum_of_below)
{
	if (threadIdx.x == 0)
	{
		sum_of_below[0] = 0.;
	}
	__syncthreads();
	float lin = 0.;
	for (int i = threadIdx.x; i < k_numbers; i = i + blockDim.x)
	{
		lin = lin + nkexpbetaku[i];
		//printf("lin: %f, Add: %f\n", lin, nkexpbetaku[i]);
	}
	atomicAdd(sum_of_below, lin);
	//printf("haha: %f\n", *sum_of_below);
}

__global__ void SITS_For_Enhanced_Force_Protein_Water_CUDA
(
    const int atom_numbers, const int * atom_sys_mark,  VECTOR * md_frc, const VECTOR * pp_frc, const VECTOR * pw_frc, const float factor, const float pwwp_enhance_factor
)
{
	float lin = pwwp_enhance_factor * factor + (1 - pwwp_enhance_factor);
    for (int i = threadIdx.x; i < atom_numbers; i = i + blockDim.x)
	{
        if (atom_sys_mark[i] == 0)
        {
            //protein
            md_frc[i].x += factor*(pp_frc[i].x) + lin*pw_frc[i].x;
		    md_frc[i].y += factor*(pp_frc[i].y) + lin*pw_frc[i].y;
		    md_frc[i].z += factor*(pp_frc[i].z) + lin*pw_frc[i].z;
			//printf("i = %d\n", i);
        }
        else
        {
            //water
            md_frc[i].x += lin*pw_frc[i].x;
		    md_frc[i].y += lin*pw_frc[i].y;
		    md_frc[i].z += lin*pw_frc[i].z;
			//printf("debug this should be 0: %f %f %f\n", pp_frc[i].x, pp_frc[i].y, pp_frc[i].z);
        }
		//debug
		//md_frc[i].x += pp_frc[i].x + pw_frc[i].x;
		//md_frc[i].y += pp_frc[i].y + pw_frc[i].y;
		//md_frc[i].z += pp_frc[i].z + pw_frc[i].z;
	}
}

__global__ void SITS_Get_Current_Fb(const int atom_numbers, const int *atom_sys_mark,
	const float *pp_ene, const float *pw_ene,
	const int k_numbers,float *nkexpbetaku,
	const float *beta_k, const float *n_k,
	float *sum_a,float *sum_b,float *factor,
	const float beta_0, const float pe_a, const float pe_b, const float fb_bias, const float pwwp_enhance_factor)
{
	float ene = pp_ene[0] + pwwp_enhance_factor*pw_ene[0];
	ene = float(pe_a * ene + pe_b);

	if (ene > 0)
	{
		SITS_For_Enhanced_Force_Calculate_NkExpBetakU_1_CUDA << <1, 64 >> >
			(k_numbers, beta_k, n_k, nkexpbetaku, ene);
	}
	else
	{
		SITS_For_Enhanced_Force_Calculate_NkExpBetakU_2_CUDA << <1, 64 >> >
			(k_numbers, beta_k, n_k, nkexpbetaku, ene);
	}

	SITS_For_Enhanced_Force_Sum_Of_NkExpBetakU_CUDA << <1, 128 >> >
			(k_numbers, nkexpbetaku, sum_b);

	SITS_For_Enhanced_Force_Sum_Of_Above_CUDA << <1, 128 >> >
		(k_numbers, nkexpbetaku, beta_k, sum_a);

	cudaDeviceSynchronize();

	//cudaError_t cuerr = cudaGetLastError();
	//printf("cuerr: %s\n", cudaGetErrorString(cuerr));

	factor[0] = sum_a[0] / sum_b[0] / beta_0 + fb_bias;
	//printf("before: ! sum_a[0] = %f, sum_b[0] = %f, beta_0 = %f, factor[0] = %f\n", sum_a[0], sum_b[0], beta_0, factor[0]);
	/*if (!isinf(factor[0]) && !isnan(factor[0]) && (factor[0] > 0.2 * factor[1]) && (factor[0] < 5 * factor[1]) )
	{
		factor[1] = factor[0];
	}
	else
	{
		factor[0] = factor[1];
	}*/
	//printf("sum_a = %f, sum_b = %f, beta_0 = %f, fc = %f, factor[0] = %f, factor[1] = %f\n", sum_a[0], sum_b[0], beta_0, fc, factor[0], factor[1]);
	__syncthreads();
}

/*__global__ void SITS_Enhanced_Force_CUDA
(const int atom_numbers, const int *atom_sys_mark,
VECTOR *md_frc, const VECTOR * pp_frc, const VECTOR *pw_frc,
const float *pp_ene, const float *pw_ene,
const int k_numbers,float *nkexpbetaku,
const float *beta_k, const float *n_k,
float *sum_a,float *sum_b,float *factor,
const float beta_0, const float pe_a, const float pe_b, const float fb_bias, const float pwwp_enhance_factor)
{
	float ene = pp_ene[0] + pwwp_enhance_factor*pw_ene[0];
	ene = float(pe_a * ene + pe_b);

    if (ene > 0)
    {
        SITS_For_Enhanced_Force_Calculate_NkExpBetakU_1_CUDA << <1, 64 >> >
            (k_numbers, beta_k, n_k, nkexpbetaku, ene);
    }
    else
    {
        SITS_For_Enhanced_Force_Calculate_NkExpBetakU_2_CUDA << <1, 64 >> >
            (k_numbers, beta_k, n_k, nkexpbetaku, ene);
    }

	SITS_For_Enhanced_Force_Sum_Of_NkExpBetakU_CUDA << <1, 128 >> >
			(k_numbers, nkexpbetaku, sum_b);

	SITS_For_Enhanced_Force_Sum_Of_Above_CUDA << <1, 128 >> >
		(k_numbers, nkexpbetaku, beta_k, sum_a);

	cudaDeviceSynchronize();

	//cudaError_t cuerr = cudaGetLastError();
	//printf("cuerr: %s\n", cudaGetErrorString(cuerr));

	factor[0] = sum_a[0] / sum_b[0] / beta_0;
	//printf("before: ! sum_a[0] = %f, sum_b[0] = %f, beta_0 = %f, factor[0] = %f\n", sum_a[0], sum_b[0], beta_0, factor[0]);
	if (!isinf(factor[0]) && !isnan(factor[0]) && (factor[0] > 0.2 * factor[1]) && (factor[0] < 5 * factor[1]) )
	{
		factor[1] = factor[0];
	}
	else
	{
		factor[0] = factor[1];
	}
	float fc = factor[0] + fb_bias;
	//printf("sum_a = %f, sum_b = %f, beta_0 = %f, fc = %f, factor[0] = %f, factor[1] = %f\n", sum_a[0], sum_b[0], beta_0, fc, factor[0], factor[1]);
	__syncthreads();

	SITS_For_Enhanced_Force_Protein_Water_CUDA << <1, 128 >> >
		(atom_numbers, atom_sys_mark, md_frc, pp_frc, pw_frc, fc, pwwp_enhance_factor);
}*/


void CLASSIC_SITS_INFORMATION::Initial(CONTROLLER * controller, SITS_INFORMATION * sits)
{
	controller[0].printf("START INITIALIZING CLASSIC SITS\n");
	is_initialized = 1;
	sits_controller = sits;
	if (controller[0].Command_Exist("SITS_k_numbers"))
	{
		k_numbers = atoi(controller[0].Command("SITS_k_numbers"));
		if (k_numbers <= 0)
		{
			controller[0].printf("Error: SITS k numbers cannot be smaller than 0\n");
			getchar();
			exit(0);
		}
	}
	else
	{
		k_numbers = 40;
	}
	controller[0].printf("\tk numbers is %d\n",k_numbers);
	Memory_Allocate();
	
	if (controller[0].Command_Exist("SITS_T_low") || controller[0].Command_Exist("SITS_T"))
	{
		controller[0].printf("\tRead SITS temperature information.\n");
		float * beta_k_tmp;
		Malloc_Safely((void**)&beta_k_tmp, sizeof(float)*k_numbers);
		if (controller[0].Command_Exist("SITS_T_low"))
		{
			if (!controller[0].Command_Exist("SITS_T_high"))
			{
				controller[0].printf("\tError: SITS T high must be explicitly given with SITS T low in mdin\n");
				getchar();
				exit(0);
			}
			float T_low = atof(controller[0].Command("SITS_T_low"));
			float T_high = atof(controller[0].Command("SITS_T_high"));
			float T_space = (T_high - T_low) / (k_numbers - 1);
			
			for (int i = 0; i < k_numbers; ++i)
			{
				beta_k_tmp[i] = 1.0/(CONSTANT_kB * (T_low + T_space * i));
				//printf("beta_k_tmp = %f, T = %f\n", beta_k_tmp[i], T_low + T_space * i);
			}
		}
		else
		{
			const char* char_pt = controller[0].Command("SITS_T");
			for (int i = 0; i < k_numbers; ++i)
			{
				float tmp_T;
				//printf("! %s\n", char_pt);
				sscanf(char_pt, "%f", &tmp_T);
				if (i != k_numbers - 1)
				{
					while(*char_pt != '/' && *char_pt != '\0')
						++char_pt;
					if (*char_pt == '/')
						++char_pt;
					if (*char_pt == '\0')
					{
						controller[0].printf("\tError: number of input SITS T != SITS k numbers\n");
						getchar();
						exit(1);
					}
				}
				beta_k_tmp[i] = 1.0/(CONSTANT_kB * tmp_T);
				//printf("tmpT %f!\n", tmp_T);
				//getchar();
			}
		}
		cudaMemcpy(beta_k, beta_k_tmp, sizeof(float)*k_numbers, cudaMemcpyHostToDevice);
		free(beta_k_tmp);
	}
	else
	{
		controller[0].printf("\tError: SITS T must be explicitly given in mdin.\n");
		getchar();
		exit(0);
	}

	
	reset = 1;
	record_count = 0;
	
	if (controller[0].Command_Exist("SITS_record_interval"))
	{
		record_interval = atoi(controller[0].Command("SITS_record_interval"));
	}
	else
	{
		record_interval = 1;
	}
	if (controller[0].Command_Exist("SITS_update_interval"))
	{
		update_interval = atoi(controller[0].Command("SITS_update_interval"));
	}
	else
	{
		update_interval = 100;
	}
	if (controller[0].Command_Exist("SITS_pe_a"))
	{
		pe_a = atof(controller[0].Command("SITS_pe_a"));
		controller[0].printf("\tSITS_pe_a set to %f\n", pe_a);
	}
	else
	{
		pe_a = 1.0;
	}
	if (controller[0].Command_Exist("SITS_pe_b"))
	{
		pe_b = atof(controller[0].Command("SITS_pe_b"));
		controller[0].printf("\tSITS_pe_b set to %f\n", pe_b);
	}
	else
	{
		pe_b = 0.0;
	}
	if (controller[0].Command_Exist("SITS_fb_bias"))
	{
		fb_bias = atof(controller[0].Command("SITS_fb_bias"));
		controller[0].printf("\tSITS_fb_bias set to %f\n", fb_bias);
	}
	else
	{
		fb_bias = 0.0;
	}

	controller[0].printf("\tSITS record interval set to %d\n", record_interval);
	controller[0].printf("\tSITS update interval set to %d\n", update_interval);

	int nk_rest = 0;
	if (controller[0].Command_Exist("SITS_nk_rest"))
		nk_rest = atoi(controller[0].Command("SITS_nk_rest"));

	float * beta_lin;
	Malloc_Safely((void**)&beta_lin, sizeof(float)*k_numbers);

	for (int i = 0; i < k_numbers; ++i)
		beta_lin[i] = -FLT_MAX;

	cudaMemcpy(log_norm_old, beta_lin, sizeof(float)*k_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(log_norm, beta_lin, sizeof(float)*k_numbers, cudaMemcpyHostToDevice);

	cudaMemset(log_nk_inverse, 0, sizeof(float)*k_numbers);

	if (nk_rest == 0)
	{
		for (int i = 0; i < k_numbers; ++i)
		{
			beta_lin[i] = 0.0;
		}
	}
	else
	{
		FILE * nk_read_file;
		if (controller[0].Command_Exist("SITS_nk_in_file"))
		{
			controller[0].printf("\tRead Nk from %s\n", controller[0].Command("SITS_nk_in_file"));
			Open_File_Safely(&nk_read_file, controller[0].Command("SITS_nk_in_file"),"r");
			for (int i = 0; i < k_numbers; ++i)
			{
				fscanf(nk_read_file, "%f", beta_lin + i);
				beta_lin[i] = logf(beta_lin[i]);
			}
		}
		else
		{
			controller[0].printf("\tError: SITS nk in file must be given when set SITS_nk_rest = 1.\n");
			getchar();
			exit(0);
		}
	}
	cudaMemcpy(log_nk, beta_lin, sizeof(float)*k_numbers, cudaMemcpyHostToDevice);

	for (int i = 0; i < k_numbers; ++i)
	{
		beta_lin[i] = -beta_lin[i];
	}
	cudaMemcpy(log_nk_inverse, beta_lin, sizeof(float)*k_numbers, cudaMemcpyHostToDevice);
	
	for (int i = 0; i < k_numbers; ++i)
	{
		beta_lin[i] = expf(-beta_lin[i]);
		//printf("beta_lin[i]: %f\n", beta_lin[i]);
	}

	cudaMemcpy(Nk, beta_lin, sizeof(float)*k_numbers, cudaMemcpyHostToDevice);

	free(beta_lin);
	Reset_List(factor, 1.0, 1);
	
	if (controller[0].Command_Exist("SITS_nk_traj_file"))
	{
		Open_File_Safely(&nk_traj_file, controller[0].Command("SITS_nk_traj_file"), "wb");
	}
	else
	{
		Open_File_Safely(&nk_traj_file, "SITS_nk_traj.dat", "wb");
	}
	if (controller[0].Command_Exist("SITS_nk_rest_file"))
	{
		strcpy(nk_rest_file_name, controller[0].Command("SITS_nk_rest_file"));
	}
	else
	{
		strcpy(nk_rest_file_name, "SITS_nk_rest.txt");
	}

	if (controller[0].Command_Exist("SITS_nk_fix"))
	{
		nk_fix = atoi(controller[0].Command("SITS_nk_fix"));
	}
	else
	{
		nk_fix = 0;
	}
	controller[0].printf("\tSITS nk fix is: %d\n", nk_fix);
	//controller[0].printf("\tRestart ln(Wk) will be written in %s\n", norm_rest_file_name);
	controller[0].printf("\tRestart Nk will be written in %s\n", nk_rest_file_name);

	controller[0].printf("END INITIALIZING CLASSIC SITS\n");
}


void CLASSIC_SITS_INFORMATION::Memory_Allocate()
{
	Cuda_Malloc_Safely((void**)&ene_recorded, sizeof(float));
	Cuda_Malloc_Safely((void**)&gf, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&gfsum, sizeof(float));
	Cuda_Malloc_Safely((void**)&log_weight, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&log_mk_inverse, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&log_norm_old, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&log_norm, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&log_pk, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&log_nk_inverse, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&log_nk, sizeof(float)*k_numbers);

	Cuda_Malloc_Safely((void**)&beta_k, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&NkExpBetakU, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&Nk, sizeof(float)*k_numbers);
	Cuda_Malloc_Safely((void**)&sum_a, sizeof(float));
	Cuda_Malloc_Safely((void**)&sum_b, sizeof(float));
	Cuda_Malloc_Safely((void**)&factor, sizeof(float));

	Malloc_Safely((void**)&nk_record_cpu, sizeof(float)*k_numbers);
	Malloc_Safely((void**)&log_norm_record_cpu, sizeof(float)*k_numbers);
}


void CLASSIC_SITS_INFORMATION::Clear()
{
	cudaFree(ene_recorded);
	cudaFree(gf);
	cudaFree(gfsum);
	cudaFree(log_weight);
	cudaFree(log_mk_inverse);
	cudaFree(log_norm_old);
	cudaFree(log_norm);
	cudaFree(log_pk);
	cudaFree(log_nk_inverse);
	cudaFree(log_nk);
	cudaFree(beta_k);
	cudaFree(NkExpBetakU);
	cudaFree(Nk);
	cudaFree(sum_a);
	cudaFree(sum_b);
	cudaFree(factor);

	free(nk_record_cpu);
	free(log_norm_record_cpu);

	fclose(nk_traj_file);
	//fclose(nk_rest_file);
	//fclose(norm_traj_file);
	//fclose(norm_rest_file);
}


void CLASSIC_SITS_INFORMATION::SITS_Record_Ene()
{
    SITS_Record_Ene_CUDA<<< 1, 1 >>>(ene_recorded, sits_controller->pw_select.select_energy[1], sits_controller->pw_select.select_energy[0], pe_a, pe_b, sits_controller->pwwp_enhance_factor);
	//cudaDeviceSynchronize();
	//getchar();
}

void CLASSIC_SITS_INFORMATION::SITS_Update_gf()
{
    SITS_Update_gf_CUDA<<< ceilf((float)k_numbers / 32.0f), 32 >>>(k_numbers, gf, ene_recorded, log_nk, beta_k);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_gfsum()
{
    SITS_Update_gfsum_CUDA << <1, 1 >> >(k_numbers, gfsum, gf);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_log_pk()
{
    SITS_Update_log_pk_CUDA << <ceilf((float)k_numbers / 32.), 32 >> >(k_numbers, log_pk, gf, gfsum, reset);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_log_mk_inverse()
{
    SITS_Update_log_mk_inverse_CUDA << <ceilf((float)k_numbers / 32.), 32 >> >(k_numbers, log_weight, log_mk_inverse, log_norm_old, log_norm, log_pk, log_nk);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_log_nk_inverse()
{
    SITS_Update_log_nk_inverse_CUDA << <1, 1 >> >(k_numbers,
        log_nk_inverse, log_mk_inverse);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_nk()
{
    SITS_Update_nk_CUDA << <ceilf((float)k_numbers / 32.), 32 >> >(k_numbers,
        log_nk, Nk, log_nk_inverse);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_Fb(float beta_0)
{
	//printf("Update!\n");
	//getchar();
	SITS_Get_Current_Fb << <1, 1 >> >
			(sits_controller->atom_numbers, sits_controller->atom_sys_mark, 
			 sits_controller->pw_select.select_energy[0],sits_controller->pw_select.select_energy[1],
			k_numbers, NkExpBetakU,
			beta_k, Nk,
			sum_a, sum_b, factor,
			beta_0, pe_a, pe_b, fb_bias, sits_controller->pwwp_enhance_factor);
	cudaMemcpy(&sits_controller->h_factor, factor, sizeof(float), cudaMemcpyDeviceToHost);
}

void CLASSIC_SITS_INFORMATION::SITS_Update_Common()
{
	SITS_Record_Ene();
	SITS_Update_gf();
	SITS_Update_gfsum();
	SITS_Update_log_pk();

	reset = 0;
	record_count++;
}


void CLASSIC_SITS_INFORMATION::SITS_Update_Nk()
{
	SITS_Update_log_mk_inverse();
	SITS_Update_log_nk_inverse();
	SITS_Update_nk();

	//printf("Update done\n");
	record_count = 0;
	reset = 1;

	SITS_Write_Nk_Norm();
	//printf("Write traj!\n");
}


void CLASSIC_SITS_INFORMATION::SITS_Write_Nk_Norm()
{
	cudaMemcpy(nk_record_cpu, Nk, sizeof(float)*k_numbers, cudaMemcpyDeviceToHost);
	//cudaMemcpy(log_norm_record_cpu, log_norm, sizeof(float)*k_numbers, cudaMemcpyDeviceToHost);
	fwrite(nk_record_cpu, sizeof(float), k_numbers, nk_traj_file);
	//fwrite(log_norm_record_cpu, sizeof(float), k_numbers, norm_traj_file);

	Open_File_Safely(&nk_rest_file, nk_rest_file_name, "w");
	//Open_File_Safely(&norm_rest_file, norm_rest_file_name, "w");
	for (int i = 0; i < k_numbers; ++i)
	{
		fprintf(nk_rest_file, "%e ", nk_record_cpu[i]);
		//fprintf(norm_rest_file, "%e ", log_norm_record_cpu[i]);
	}
	fclose(nk_rest_file);
	//fclose(norm_rest_file);
}

float CLASSIC_SITS_INFORMATION::SITS_Get_Fb()
{
	if (is_initialized)
	{
		cudaMemcpy(&sits_controller->h_factor, factor, sizeof(float), cudaMemcpyDeviceToHost);
		return sits_controller->h_factor;
	}
	else
	{
		return 0.0;
	}
}

void SITS_INFORMATION::Initial(CONTROLLER * controller, int atom_numbers_)
{
	if (controller[0].Command_Exist("SITS_mode"))
	{
		controller[0].printf("START INITIALIZING SITS\n");
		is_initialized = 1;
		sits_mode = atoi(controller[0].Command("SITS_mode"));
		if (sits_mode != 0)
		{
			controller[0].printf("\tError: unsupported SITS mode %d\n", sits_mode);
			getchar();
			exit(0);
		}
		atom_numbers = atom_numbers_;
		controller[0].printf("\tAtom numbers is %d\n", atom_numbers);
		Memory_Allocate();

		// 不 enhance 的能量 (ww 和部分 pp) 存在 md_info.d_atom_energy 里
		// enhance 的 pp 和 pw 分别存储
		// 力同理
		pw_select.Add_One_Energy(atom_numbers);
		pw_select.Add_One_Energy(atom_numbers);
		pw_select.Add_One_Force(atom_numbers);
		pw_select.Add_One_Force(atom_numbers);
		controller[0].printf("\tAdd auxiliary energy and force arrays.\n");
		controller[0].printf("\tAuxiliary energy array: %d, force array: %d\n", pw_select.select_energy.size(), pw_select.select_force.size());
		//!Remark: How to deal with virial?

		if (controller[0].Command_Exist("pwwp_enhance_factor"))
		{
			pwwp_enhance_factor = atof(controller[0].Command("pwwp_enhance_factor"));
		}
		else
		{
			pwwp_enhance_factor = 0.5;
		}
		controller[0].printf("\tpwwp enhance factor set to %f\n", pwwp_enhance_factor);


		if (controller[0].Command_Exist("atom_atribution_in_file") || controller[0].Command_Exist("SITS_protein_numbers"))
		{
			controller[0].printf("\tSet atom atribution information.\n");
			int * atom_sys_mark_cpu;
			Malloc_Safely((void**)&atom_sys_mark_cpu, sizeof(int)*atom_numbers);
			if (controller[0].Command_Exist("atom_atribution_in_file"))
			{
				int atom_numbers_in_file;
				FILE * mark_file;
				Open_File_Safely(&mark_file, controller[0].Command("atom_atribution_in_file"), "r");
				fscanf(mark_file, "%d", &atom_numbers_in_file);
				if (atom_numbers != atom_numbers_in_file)
				{
					printf("Error: Atom numbers unequal %d %d\n", atom_numbers, atom_numbers_in_file);
					getchar();
					exit(0);
				}
				for (int i = 0; i < atom_numbers; ++i)
				{
					fscanf(mark_file, "%d", atom_sys_mark_cpu + i);
				}
				fclose(mark_file);
			}
			else
			{
				int protein_numbers = atoi(controller[0].Command("SITS_protein_numbers"));
				for (int i = 0; i < protein_numbers; ++i)
				{
					atom_sys_mark_cpu[i] = 0;
				}
				for (int i = protein_numbers; i < atom_numbers; ++i)
				{
					atom_sys_mark_cpu[i] = 1;
				}
			}
			cudaMemcpy(atom_sys_mark, atom_sys_mark_cpu, sizeof(int)*atom_numbers, cudaMemcpyHostToDevice);
			free(atom_sys_mark_cpu);
		}
		else
		{
			printf("\tError: Atom atribution information must be given in the form of atom_atribution_in_file or SITS_protein_numbers\n");
			getchar();
			exit(0);
		}

		if (sits_mode == CLASSIC)
		{
			//cudaError_t cuerr = cudaGetLastError();
			//printf("Before: %s\n", cudaGetErrorString(cuerr));
			classic_sits.Initial(controller, this);
			//cuerr = cudaGetLastError();
			//printf("After: %s\n", cudaGetErrorString(cuerr));
		}

		need_potential = 0;
		h_factor = 1.0f;

		controller[0].Step_Print_Initial("SITS_pw", "%.2f");
		controller[0].Step_Print_Initial("SITS_pp", "%.2f");
		controller[0].Step_Print_Initial("SITS_fb", "%.2f");

		controller[0].printf("END INTIALIZING SITS\n\n");
	}
	else
	{
		is_initialized = 0;
		return ;
	}
}

void SITS_INFORMATION::Memory_Allocate()
{
	Cuda_Malloc_Safely((void**)&atom_sys_mark, sizeof(float)*atom_numbers);
}

void SITS_INFORMATION::Update(int frame_numbers)
{
	if (sits_mode == CLASSIC)
	{
		if (!classic_sits.nk_fix && frame_numbers % classic_sits.record_interval == 0)
		{
			classic_sits.SITS_Update_Common();
			if (classic_sits.record_count % classic_sits.update_interval == 0)
			{
				classic_sits.SITS_Update_Nk();
			}
		}
	}
}

void SITS_INFORMATION::Clear()
{
	cudaFree(atom_sys_mark);
	pw_select.Clear();
	
	classic_sits.Clear();
}

void SITS_INFORMATION::Reset_Force_Energy(int md_need_potential)
{
	if (sits_mode < 1 || md_need_potential)
		need_potential = 1;

	if (need_potential)
	{
		cudaMemset(pw_select.select_atom_energy[0], 0, sizeof(float)*atom_numbers);
		cudaMemset(pw_select.select_atom_energy[1], 0, sizeof(float)*atom_numbers);
		cudaMemset(pw_select.select_energy[0], 0, sizeof(float));
		cudaMemset(pw_select.select_energy[1], 0, sizeof(float));
	}
	cudaMemset(pw_select.select_force[0], 0, sizeof(VECTOR) * atom_numbers);
	cudaMemset(pw_select.select_force[1], 0, sizeof(VECTOR) * atom_numbers);
}

float SITS_INFORMATION::Get_Potential(int is_download)
{
	if (is_initialized && need_potential)
	{
		Sum_Of_List(pw_select.select_atom_energy[0], pw_select.select_energy[0], atom_numbers);
		Sum_Of_List(pw_select.select_atom_energy[1], pw_select.select_energy[1], atom_numbers);
		cudaMemcpy(&h_pp_energy, pw_select.select_energy[0], sizeof(float), cudaMemcpyDeviceToHost);
		cudaMemcpy(&h_pw_energy, pw_select.select_energy[1], sizeof(float), cudaMemcpyDeviceToHost);

		if (is_download)
		{
			//debug
			//printf("h_pp_energy: %f, h_pw_energy: %f\n",  h_pp_energy, h_pw_energy);
			//getchar();
			return h_pp_energy + h_pw_energy;
		}
		else
		{
			return 0.0;
		}
	}
	else
	{
		return 0.0;
	}
}

void SITS_INFORMATION::SITS_LJ_Force_With_Direct_CF(const UNSIGNED_INT_VECTOR *uint_crd, float * charge, LENNARD_JONES_INFORMATION * lj_info, VECTOR *md_frc,
	const ATOM_GROUP *nl, const float cutoff, const float pme_beta)
{
	if (is_initialized)
	{
		Copy_Crd_And_Charge_To_New_Crd << <(unsigned int)ceilf((float)atom_numbers / 1024), 1024 >> >(atom_numbers, uint_crd, lj_info->uint_crd_with_LJ, charge);
		SITS_LJ_Force_With_Direct_CF_CUDA << <{1, (unsigned int)ceilf((float)atom_numbers / 32.0f)}, dim3(32u, 32u) >> >
			(atom_numbers, nl,
			lj_info->uint_crd_with_LJ, lj_info->uint_dr_to_dr_cof,
			lj_info->d_LJ_A, lj_info->d_LJ_B, atom_sys_mark, cutoff,
		md_frc, pw_select.select_force[0], pw_select.select_force[1], pme_beta, TWO_DIVIDED_BY_SQRT_PI);
	}
}

void SITS_INFORMATION::SITS_LJ_Direct_CF_Force_With_Atom_Energy(const UNSIGNED_INT_VECTOR *uint_crd, const float * charge,LENNARD_JONES_INFORMATION * lj_info, VECTOR *md_frc,
	const ATOM_GROUP *nl, const float cutoff, const float pme_beta,float *atom_energy_ww)
{
	if (is_initialized)
	{
		if (need_potential)
		{
			Copy_Crd_And_Charge_To_New_Crd << <(unsigned int)ceilf((float)atom_numbers / 1024), 1024 >> >(atom_numbers, uint_crd, lj_info->uint_crd_with_LJ, charge);
			SITS_LJ_Direct_CF_Force_With_Atom_Energy_CUDA << <{1, (unsigned int)ceilf((float)atom_numbers / 32.0)}, dim3(32u, 32u) >> >
			(atom_numbers, nl,
			lj_info->uint_crd_with_LJ
			, lj_info->uint_dr_to_dr_cof,
			lj_info->d_LJ_A, lj_info->d_LJ_B, atom_sys_mark, cutoff,
				md_frc, pw_select.select_force[0], pw_select.select_force[1], pme_beta, TWO_DIVIDED_BY_SQRT_PI,atom_energy_ww, pw_select.select_atom_energy[0], pw_select.select_atom_energy[1]);
		}
		else
		{
			Copy_Crd_And_Charge_To_New_Crd << <(unsigned int)ceilf((float)atom_numbers / 1024), 1024 >> >(atom_numbers, uint_crd, lj_info->uint_crd_with_LJ, charge);
			SITS_LJ_Force_With_Direct_CF_CUDA << <{1, (unsigned int)ceilf((float)atom_numbers / 32.0f)}, dim3(32u, 32u) >> >
			(atom_numbers, nl,
			lj_info->uint_crd_with_LJ, lj_info->uint_dr_to_dr_cof,
			lj_info->d_LJ_A, lj_info->d_LJ_B, atom_sys_mark, cutoff,
				md_frc, pw_select.select_force[0], pw_select.select_force[1], pme_beta, TWO_DIVIDED_BY_SQRT_PI);
		}
	}
}

float SITS_INFORMATION::Get_Fb()
{
	return h_factor;
}

void SITS_INFORMATION::Enhance_Force(VECTOR *md_frc, float beta_0)
{
	if (sits_mode == CLASSIC)
	{
		classic_sits.SITS_Update_Fb(beta_0);
	}

	SITS_For_Enhanced_Force_Protein_Water_CUDA << <1, 128 >> >
		(atom_numbers, atom_sys_mark, md_frc, pw_select.select_force[0], pw_select.select_force[1], h_factor, pwwp_enhance_factor);
}
