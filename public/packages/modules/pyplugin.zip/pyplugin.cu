#include "pyplugin.cuh"


extern MD_INFORMATION md_info;
extern CONTROLLER controller;

//the construction of Python module "SPONGE" 
//sponge.get_atom_numbers()
//return int atom_numbers
static PyObject* Sponge_Get_Atom_Numbers(PyObject* self, PyObject*args)
{
	if (!PyArg_ParseTuple(args, ""))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	return Py_BuildValue("l", md_info.atom_numbers);
}


//sponge.get_step()
//return int step
static PyObject* Sponge_Get_Step(PyObject* self, PyObject*args)
{
	if (!PyArg_ParseTuple(args,""))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	return Py_BuildValue("l", md_info.sys.steps);
}

//sponge.get_potential_energy()
//return float potential_energy
static PyObject* Sponge_Get_Potential_Energy(PyObject* self, PyObject*args)
{
	if (!PyArg_ParseTuple(args, ""))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	return Py_BuildValue("f", md_info.sys.h_potential);
}

//sponge.get_box_length()
//return numpy.ndarray box_length
static PyObject* Sponge_Get_Box_Length(PyObject* self, PyObject*args)
{
	if (!PyArg_ParseTuple(args,""))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	npy_intp temp_dim[1] = { 3 };
	return PyArray_SimpleNewFromData(1, temp_dim, NPY_FLOAT32, &md_info.sys.box_length);
}

//sponge.get_mass(int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return numpy.ndarray mass
static PyObject* Sponge_Get_Mass(PyObject* self, PyObject* args, PyObject* kw)
{
	static char *kwlist[] = {"start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|iii",kwlist, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	npy_intp temp_dim[1] = { length };
	if (cuda_memcpy)
		cudaMemcpy(md_info.h_mass + start, md_info.d_mass + start, sizeof(float) * length, cudaMemcpyDeviceToHost);
	return PyArray_SimpleNewFromData(1, temp_dim, NPY_FLOAT32, md_info.h_mass + start);
}



//sponge.get_charge(int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return numpy.ndarray charge
static PyObject* Sponge_Get_Charge(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|iii",kwlist, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	npy_intp temp_dim[1] = { length };
	if (cuda_memcpy)
		cudaMemcpy(md_info.h_charge + start, md_info.d_charge + start, sizeof(float)*length, cudaMemcpyDeviceToHost);
	return PyArray_SimpleNewFromData(1, temp_dim, NPY_FLOAT32, md_info.h_charge + start);
}

//sponge.set_charge(numpy.ndarray charge, int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return None
static PyObject* Sponge_Set_Charge(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"charge","start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	PyArrayObject* pArrayTemp = NULL;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "O!|iii", kwlist, &PyArray_Type, &pArrayTemp, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	if (pArrayTemp->strides[1] != 4 || !PyArray_ISFLOAT(pArrayTemp))
	{
		PyErr_SetString(PyExc_Exception, "float32 needed");		
		return NULL;
	}
	if (pArrayTemp->nd != 1 || pArrayTemp->dimensions[0] != length)
	{
		PyErr_SetString(PyExc_Exception, "array shape is not right");
		return NULL;
	}
	cudaMemcpy(md_info.h_charge + start, pArrayTemp->data, sizeof(float)*length, cudaMemcpyHostToHost);
	if (cuda_memcpy)
		cudaMemcpy(md_info.d_charge + start, md_info.h_charge + start, sizeof(float)*length, cudaMemcpyHostToDevice);
	return Py_BuildValue("");
}

//sponge.get_coordinate(int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return numpy.ndarray coordinate
static PyObject* Sponge_Get_Coordinate(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|iii",kwlist, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	npy_intp temp_dim[2] = { length, 3 };
	if (cuda_memcpy)
		cudaMemcpy(md_info.coordinate + start, md_info.crd + start, sizeof(VECTOR)*length, cudaMemcpyDeviceToHost);
	return PyArray_SimpleNewFromData(2, temp_dim, NPY_FLOAT32, md_info.coordinate + start);
}

//sponge.set_coordinate(numpy.array coordinate, int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return None
static PyObject* Sponge_Set_Coordinate(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"coordinate","start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	PyArrayObject* pArrayTemp = NULL;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "O!|iii", kwlist, &PyArray_Type, &pArrayTemp, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	if (pArrayTemp->strides[1] != 4 || !PyArray_ISFLOAT(pArrayTemp))
	{
		PyErr_SetString(PyExc_Exception, "float32 needed");		
		return NULL;
	}
	if (pArrayTemp->nd != 2 || pArrayTemp->dimensions[0] != length || pArrayTemp->dimensions[1] != 3)
	{
		PyErr_SetString(PyExc_Exception, "array shape is not right");
		return NULL;
	}
	cudaMemcpy(md_info.coordinate + start, pArrayTemp->data, sizeof(VECTOR)*length, cudaMemcpyHostToHost);
	if (cuda_memcpy)
		cudaMemcpy(md_info.crd + start, md_info.coordinate + start, sizeof(VECTOR)* length, cudaMemcpyHostToDevice);
	return Py_BuildValue("");
}

//sponge.get_force(int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return numpy.ndarray force
static PyObject* Sponge_Get_Force(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|iii",kwlist, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	npy_intp temp_dim[2] = { length, 3 };
	if (cuda_memcpy)
		cudaMemcpy(md_info.force + start, md_info.frc + start, sizeof(VECTOR)*length, cudaMemcpyDeviceToHost);
	return PyArray_SimpleNewFromData(2, temp_dim, NPY_FLOAT32, md_info.force + start);
}

//sponge.set_force(numpy.ndarray force, int start = 0, int length = atom_numbers, bool cuda_memcpy = True)
//return None
static PyObject* Sponge_Set_Force(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"force","start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	PyArrayObject* pArrayTemp = NULL;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "O!|iii", kwlist, &PyArray_Type, &pArrayTemp, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	if (pArrayTemp->strides[1] != 4 || !PyArray_ISFLOAT(pArrayTemp))
	{
		PyErr_SetString(PyExc_Exception, "float32 needed");		
		return NULL;
	}
	if (pArrayTemp->nd != 2 || pArrayTemp->dimensions[0] != length || pArrayTemp->dimensions[1] != 3)
	{
		PyErr_SetString(PyExc_Exception, "array shape is not right");
		return NULL;
	}
	cudaMemcpy(md_info.force + start, pArrayTemp->data, sizeof(VECTOR)*length, cudaMemcpyHostToHost);
	if (cuda_memcpy)
		cudaMemcpy(md_info.frc + start, md_info.force + start, sizeof(VECTOR)* length, cudaMemcpyHostToDevice);
	return Py_BuildValue("");
}

//sponge.command_exist(str command)
//return bool existance
static PyObject* Sponge_Command_Exist(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"command", NULL};
	char *buffer;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "s",kwlist, &buffer))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (controller.Command_Exist(buffer))
		Py_RETURN_TRUE;
	else
		Py_RETURN_FALSE;
}

//sponge.command(str command)
//return str value
static PyObject* Sponge_Command(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"command", NULL};
	char *buffer;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "s",kwlist, &buffer))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	return Py_BuildValue("s", controller.Command(buffer));
}

//sponge.original_command(str command)
//return str value
static PyObject* Sponge_Original_Command(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"command", NULL};
	char *buffer;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "s",kwlist, &buffer))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	return Py_BuildValue("s", controller.Original_Command(buffer));
}

//sponge.need_potential()
//return bool need
static PyObject* Sponge_Need_Potential(PyObject* self, PyObject* args)
{
	if (!PyArg_ParseTuple(args, ""))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (md_info.need_potential)
		Py_RETURN_TRUE;
	else
		Py_RETURN_FALSE;
}

//sponge.need_pressure()
//return bool need
static PyObject* Sponge_Need_Pressure(PyObject* self, PyObject* args)
{
	if (!PyArg_ParseTuple(args, ""))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (md_info.need_pressure)
		Py_RETURN_TRUE;
	else
		Py_RETURN_FALSE;
}

//sponge.get_atom_energy(int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return numpy.ndarray atom_energy
static PyObject* Sponge_Get_Atom_Energy(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|iii",kwlist, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	npy_intp temp_dim[1] = { length };
	if (cuda_memcpy)
		cudaMemcpy(md_info.h_atom_energy + start, md_info.d_atom_energy + start, sizeof(float)*length, cudaMemcpyDeviceToHost);
	return PyArray_SimpleNewFromData(1, temp_dim, NPY_FLOAT32, md_info.h_atom_energy + start);
}

//sponge.set_atom_energy(numpy.ndarray atom_energy, int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return None
static PyObject* Sponge_Set_Atom_Energy(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"atom_energy","start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	PyArrayObject* pArrayTemp = NULL;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "O!|iii", kwlist, &PyArray_Type, &pArrayTemp, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	if (pArrayTemp->strides[1] != 4 || !PyArray_ISFLOAT(pArrayTemp))
	{
		PyErr_SetString(PyExc_Exception, "float32 needed");		
		return NULL;
	}
	if (pArrayTemp->nd != 1 || pArrayTemp->dimensions[0] != length)
	{
		PyErr_SetString(PyExc_Exception, "array shape is not right");
		return NULL;
	}
	cudaMemcpy(md_info.h_atom_energy + start, pArrayTemp->data, sizeof(float)*length, cudaMemcpyHostToHost);
	if (cuda_memcpy)
		cudaMemcpy(md_info.d_atom_energy + start, md_info.h_atom_energy + start, sizeof(float)* length, cudaMemcpyHostToDevice);
	return Py_BuildValue("");
}


//sponge.get_atom_virial(int start = 0, int length = atom_numbers, bool cuda_memcpy = True)
//return numpy.ndarray atom_virial
static PyObject* Sponge_Get_Atom_Virial(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|iii",kwlist, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	npy_intp temp_dim[1] = { length };
	if (cuda_memcpy)
		cudaMemcpy(md_info.h_atom_virial + start, md_info.d_atom_virial + start, sizeof(float)*length, cudaMemcpyDeviceToHost);
	return PyArray_SimpleNewFromData(1, temp_dim, NPY_FLOAT32, md_info.h_atom_virial + start);
}

//sponge.set_atom_virial(numpy.ndarray atom_virial, int start = 0, int length = atom_numbers - start, bool cuda_memcpy = True)
//return None
static PyObject* Sponge_Set_Atom_Virial(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"atom_virial","start","length","cuda_memcpy", NULL};
	int length = -1;
	int start = 0;
	int cuda_memcpy = 1;
	PyArrayObject* pArrayTemp = NULL;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "O!|iii", kwlist, &PyArray_Type, &pArrayTemp, &start, &length, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (length == -1)
	{
		length = md_info.atom_numbers - start;
	}
	if (pArrayTemp->strides[1] != 4 || !PyArray_ISFLOAT(pArrayTemp))
	{
		PyErr_SetString(PyExc_Exception, "float32 needed");		
		return NULL;
	}
	if (pArrayTemp->nd != 1 || pArrayTemp->dimensions[0] != length)
	{
		PyErr_SetString(PyExc_Exception, "array shape is not right");
		return NULL;
	}
	cudaMemcpy(md_info.h_atom_virial + start, pArrayTemp->data, sizeof(float)*length, cudaMemcpyHostToHost);
	if (cuda_memcpy)
		cudaMemcpy(md_info.d_atom_virial + start, md_info.h_atom_virial + start, sizeof(float)* length, cudaMemcpyHostToDevice);
	return Py_BuildValue("");
}

//sponge.get_virial(cuda_memcpy = True)
//return float virial
static PyObject* Sponge_Get_Virial(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"cuda_memcpy", NULL};
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|i", kwlist, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (cuda_memcpy)
		cudaMemcpy(&md_info.sys.h_virial, md_info.sys.d_virial, sizeof(float), cudaMemcpyDeviceToHost);
	return Py_BuildValue("f", md_info.sys.h_virial);
}

//sponge.set_virial(float virial, cuda_memcpy = True)
//return None
static PyObject* Sponge_Set_Virial(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"virial", "cuda_memcpy", NULL};
	int cuda_memcpy = 1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "f|i", kwlist, &md_info.sys.h_virial, &cuda_memcpy))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	if (cuda_memcpy)
		cudaMemcpy(md_info.sys.d_virial, &md_info.sys.h_virial, sizeof(float), cudaMemcpyHostToDevice);

	return Py_BuildValue("");
}

//sponge.step_print_initial(str head, str format)
//return None
static PyObject* Sponge_Step_Print_Initial(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"head", "format", NULL};
	char *head;
	char *format;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "ss", kwlist, &head, &format))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	controller.Step_Print_Initial(head, format);
	return Py_BuildValue("");
}

//sponge.step_print(str head, str content)
//return None
static PyObject* Sponge_Step_Print(PyObject* self, PyObject* args, PyObject* kw)
{
	static char* kwlist[] = {"head", "content", NULL};
	char *head;
	char *content;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "ss", kwlist, &head, &content))
	{
		PyErr_SetString(PyExc_Exception, "arguments are not right.");
		return NULL;
	}
	controller.Step_Print(head, content);
	return Py_BuildValue("");
}

static PyMethodDef SpongeMethod[] =
{
  {"get_step", (PyCFunction)Sponge_Get_Step, METH_VARARGS, "get the md step"},
  {"get_atom_numbers", (PyCFunction)Sponge_Get_Atom_Numbers, METH_VARARGS, "get the total atom number"},
  {"get_potential_energy", (PyCFunction)Sponge_Get_Potential_Energy, METH_VARARGS, "get the total potential energy"},
  {"get_box_length", (PyCFunction)Sponge_Get_Box_Length, METH_VARARGS, "get the box length"},
  {"get_mass", (PyCFunction)Sponge_Get_Mass, METH_VARARGS|METH_KEYWORDS, "get the md mass" },
  {"get_charge", (PyCFunction)Sponge_Get_Charge, METH_VARARGS|METH_KEYWORDS, "get the md charge" },
  {"set_charge", (PyCFunction)Sponge_Set_Charge, METH_VARARGS|METH_KEYWORDS, "set the md charge" },
  {"get_coordinate", (PyCFunction)Sponge_Get_Coordinate, METH_VARARGS|METH_KEYWORDS, "get the md coordinate" },
  {"set_coordinate", (PyCFunction)Sponge_Set_Coordinate, METH_VARARGS|METH_KEYWORDS, "set the md coordinate" },
  {"get_force", (PyCFunction)Sponge_Get_Force, METH_VARARGS|METH_KEYWORDS, "get the md force" },
  {"set_force", (PyCFunction)Sponge_Set_Force, METH_VARARGS|METH_KEYWORDS, "set the md force" },
  {"command_exist", (PyCFunction)Sponge_Command_Exist, METH_VARARGS|METH_KEYWORDS, "check if the command exist" },
  {"command", (PyCFunction)Sponge_Command, METH_VARARGS|METH_KEYWORDS, "get the value of the command"},
  {"original_command", (PyCFunction)Sponge_Original_Command, METH_VARARGS|METH_KEYWORDS, "get the original value of the command"},
  {"need_potential", (PyCFunction)Sponge_Need_Potential, METH_VARARGS, "check if need to calculate potential"},
  {"need_pressure", (PyCFunction)Sponge_Need_Pressure, METH_VARARGS, "check if need to calculate pressure"},
  {"get_atom_energy", (PyCFunction)Sponge_Get_Atom_Energy, METH_VARARGS|METH_KEYWORDS, "get the atom energy" },
  {"set_atom_energy", (PyCFunction)Sponge_Set_Atom_Energy, METH_VARARGS|METH_KEYWORDS, "set the atom energy" },
  {"get_atom_virial", (PyCFunction)Sponge_Get_Atom_Virial, METH_VARARGS|METH_KEYWORDS, "get the atom virial" },
  {"set_atom_virial", (PyCFunction)Sponge_Set_Atom_Virial, METH_VARARGS|METH_KEYWORDS, "set the atom virial" },
  {"get_virial", (PyCFunction)Sponge_Get_Virial, METH_VARARGS|METH_KEYWORDS, "get the scaler total virial" },
  {"set_virial", (PyCFunction)Sponge_Set_Virial, METH_VARARGS|METH_KEYWORDS, "set the scaler total virial" },
  { "step_print_initial", (PyCFunction)Sponge_Step_Print_Initial, METH_VARARGS | METH_KEYWORDS, "add some contents to the print head" },
  { "step_print", (PyCFunction)Sponge_Step_Print, METH_VARARGS | METH_KEYWORDS, "add some contents to the every-step print" },
  {NULL,NULL,0,NULL}
};

static PyModuleDef SpongeModule = 
{
  PyModuleDef_HEAD_INIT, "sponge",NULL,-1,SpongeMethod,
  NULL,NULL,NULL,NULL
};

static PyObject* PyInit_sponge(void)
{
  return PyModule_Create(&SpongeModule);
}
///////////////////////////////

///////numpy init////
int init_numpy()
{
    import_array();
    return 0;
}


//class method
void PYTHON_INFORMATION::Initial()
{
	if (!controller.Command_Exist("py"))
		return;
	

    printf("START INITIALIZING PYTHON INTERFACE:\n");
    char buffer[256];
    
    PyImport_AppendInittab("sponge",&PyInit_sponge);
    Py_Initialize();
    if (!Py_IsInitialized())
    {
        printf("    Python Initialize Failed.\n");
		getchar();
		exit(1);
    }
	else
	{
		PyRun_SimpleString("print('    Python Initialized')");
	}
    wchar_t *temp_args[1] = {L"SPONGE"};
    PySys_SetArgv(1,temp_args); 
    init_numpy();
    //初始化python系统文件路径，保证可以访问到 .py文件  
    PyRun_SimpleString("import sys");
    PyRun_SimpleString("sys.dont_write_bytecode = True");
    PyRun_SimpleString("import os");
    PyRun_SimpleString("import sponge");
 

    PyRun_SimpleString("sponge.plugin_funcs={}");
    PyRun_SimpleString("sponge.plugin_funcs['Before_Calculate_Force']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Calculate_Force']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Calculate_Energy']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['After_Calculate_Energy']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['After_Calculate_Force']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Before_Iteration']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['After_Iteration']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Iteration_1']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Iteration_2']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Volume_Change']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Print']=[]");
    PyRun_SimpleString("sponge.plugin_funcs['Destroy']=[]");
    PyRun_SimpleString("def register(place):\n"\
                       "  def decorator(func):\n"\
                       "     sponge.plugin_funcs[place].append(func)\n"\
                       "     return func\n"\
                       "  return decorator\n");
    PyRun_SimpleString("sponge.register = register");

    if (controller.Command_Exist("py"))
    {
        sprintf(buffer, "sponge.fname = '%s'", controller.Command("py")); 
        PyRun_SimpleString(buffer);  
        PyRun_SimpleString( "sys.path.append( os.path.dirname( os.path.abspath( sponge.fname ) ) )" );
        PyRun_SimpleString("sponge_pyplugin = __import__(os.path.splitext(os.path.basename(sponge.fname))[0])");
        PyRun_SimpleString("if 'sponge_pyplugin' not in dir():\n"\
		               "    print('''    Import Module '%s' Failed.'''%(os.path.splitext(os.path.basename(sponge.fname))[0]))\n"\
					   "    input()\n"\
					   "    exit(1)\n"\
					   "else:\n"\
					   "    print('''    Import Module '%s' Success.'''%(os.path.splitext(os.path.basename(sponge.fname))[0]))\n"
					   );
    }

	this->is_initialized = 1;
    printf("END INITIALIZING PYTHON INTERFACE\n\n");

}

void PYTHON_INFORMATION::Before_Calculate_Force()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Before_Calculate_Force']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}


void PYTHON_INFORMATION::Calculate_Force()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Calculate_Force']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::Calculate_Energy()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Calculate_Energy']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::After_Calculate_Energy()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['After_Calculate_Energy']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");

}

void PYTHON_INFORMATION::After_Calculate_Force()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['After_Calculate_Force']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::Iteration_1()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Iteration_1']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::Iteration_2()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Iteration_2']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::Before_Iteration()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Before_Iteration']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::After_Iteration()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['After_Iteration']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::Volume_Change(double factor)
{
	if (!is_initialized)
		return;
    char buffer[256];
	sprintf(buffer, R"XYJ(
try:
  for func in sponge.plugin_funcs['Volume_Change']:
    func(%lf)
except:
  import traceback
  traceback.print_exc()
  exit(1))XYJ", factor);
    PyRun_SimpleString(buffer);
}

void PYTHON_INFORMATION::Print()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Print']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
}

void PYTHON_INFORMATION::Destroy()
{
	if (!is_initialized)
		return;
    PyRun_SimpleString(R"XYJ(
try:
  for func in sponge.plugin_funcs['Destroy']:
    func()
except:
  import traceback
  traceback.print_exc()
  exit(1)
)XYJ");
    Py_Finalize();
}
