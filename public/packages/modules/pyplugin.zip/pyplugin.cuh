﻿/*
* Copyright 2021 Gao's lab, Peking University, CCME. All rights reserved.
*
* NOTICE TO LICENSEE:
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* http://www.apache.org/licenses/LICENSE-2.0
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/


#ifndef PYPLUGIN_CUH
#define PYPLUGIN_CUH
#include <Python.h>
#include <numpy/arrayobject.h>
#include "../common.cuh"
#include "../control.cuh"
#include "../MD_core/MD_core.cuh"
#include "../main.cuh"

struct PYTHON_INFORMATION
{
	int is_initialized = 0;
	int last_modify_date = 20210513;

	PyArrayObject* pArrayTemp = NULL;

    void Initial();
    void Before_Calculate_Force();
    void Calculate_Force();
    void Calculate_Energy();
    void After_Calculate_Energy();
    void After_Calculate_Force();
    void Iteration_1();
    void Iteration_2();
    void Before_Iteration();
    void After_Iteration();
    void Volume_Change(double factor);
    void Print();
    void Destroy();
};

/*
关于编译变量在windows上的设置：下面是夏义杰的例子
PYTHON=python37
PYTHON_INCLUDE=C:\Users\xyj\AppData\Local\Programs\Python\Python37\include
NUMPY_INCLUDE=C:\Users\xyj\AppData\Local\Programs\Python\Python37\Lib\site-packages\numpy\core\include
PYTHON_LIBRARY=C:\Users\xyj\AppData\Local\Programs\Python\Python37\libs
*/

#endif
