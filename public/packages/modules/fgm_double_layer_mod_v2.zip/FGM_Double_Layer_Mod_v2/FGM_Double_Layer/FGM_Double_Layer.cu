#include "FGM_Double_Layer.cuh"
__global__ void SOR_Iteration_Full(const int grid_numbers, const INT_VECTOR grid_dimension, const int layer_numbers,
	const float *rho, const VECTOR grid_length_inverse_square, const float gamma1, const float gamma2, float *phi, float *phi2);
__global__ void Distribute_Charge_To_Vertex
(const int ion_numbers, const int ion_serial_start, const float *atom_charge, const float charge_density_scaler, const UNSIGNED_INT_VECTOR *ion_uint_crd,
const VECTOR scaler, const INT_VECTOR grid_dimension, const int layer_numbers, float *rho
);
__global__ void Crd_To_Uint_Crd_Partial_And_Z_Move
(const int ion_numbers, const int ion_serial_start, const VECTOR scale_factor, const VECTOR *atom_crd,
const float z_move, UNSIGNED_INT_VECTOR *ion_uint_crd);
__global__ void Calculate_Phi_Convergence(const int element_numbers, const float *phi1, const float *phi2, float *sum);
__global__ void SOR_Iteration_Mean(const int grid_numbers, float *phi, float *phi2);
__global__ void Set_Frozen_Phi(const int grid_serial_start, const int grid_serial_end, const float ep_phi, float *phi);
__global__ void Green_Force_Near_Plane
(const int ion_numbers, const int ion_serial_start, const UNSIGNED_INT_VECTOR *ion_uint_crd, const float *atom_charge,
const int point_numbers, const INT_VECTOR *sphere_point_int_crd, const VECTOR *sphere_crd, const VECTOR scaler_uint_crd_to_1,
const VECTOR half_grid_lenth_devide_box_length,
const cudaTextureObject_t EF_with_phi, VECTOR *ion_frc,
const float scaler_uint_crdz_to_crd,
const float sphere_factor, const float plane_factor);
__global__ void FG_Electric_Field(
	const int grid_numbers, const INT_VECTOR grid_dimension,
	const int layer_numbers, const VECTOR grid_length_inverse2,
	const float *phi, float4 *ef);
__global__ void FG_Electric_Field_Plane_Mode
(const int grid_serial_start, const int grid_serial_end, const int layer_numbers,
const float *phi, const VECTOR grid_length_inverse, float4 *ef);
__global__ void Add_Green_Force(
	const int ion_serial_start, const int ion_serial_end, VECTOR *ion_green_frc, VECTOR *atom_frc);

__global__ void Green_Energy_Near_Plane
(const int ion_numbers, const int ion_serial_start, const UNSIGNED_INT_VECTOR *ion_uint_crd, const float *atom_charge,
const int point_numbers, const INT_VECTOR *sphere_point_int_crd, const VECTOR *sphere_crd, const VECTOR scaler_uint_crd_to_1,
const VECTOR half_grid_lenth_devide_box_length,
const cudaTextureObject_t EF_with_phi, float *ion_atom_energy,
const float scaler_uint_crdz_to_crd,
const float sphere_factor, const float plane_factor);
__global__ void FGM_DL_Direct_Energy_CUDA(
const int ion_numbers, const int ion_serial_start,
const ATOM_GROUP *atom_nl, const UNSIGNED_INT_VECTOR *atom_uint_crd, const float *atom_charge,
const VECTOR boxlength, const float g,
const float cutoff, const float B, const float C, const float small_cutoff,
float *ion_atom_energy);

void FGM_DOUBLE_LAYER::Initial(CONTROLLER *controller, const int atom_numbers, const float cutoff, const VECTOR box_length, char *module_name)
{
	controller[0].printf("START INITIALIZING FGM_DOUBLE_LAYER:\n");
	this->box_length = box_length;
	this->cutoff = cutoff;
	origin_cutoff = cutoff;

	//module name initial
	if (module_name == NULL)
	{
		strcpy(this->module_name, "FGM_Double_Layer");
	}
	else
	{
		strcpy(this->module_name, module_name);
	}

	//ion selection initial
	if (controller[0].Command_Exist(this->module_name, "ion_serial_start"))
	{
		sscanf(controller[0].Command(this->module_name, "ion_serial_start"), "%d", &(this->ion_serial_start));
		if (ion_serial_start > atom_numbers)
		{
			controller[0].printf("    Error:ion_serial_start %d is larger than atom_numbers %d\n", ion_serial_start, atom_numbers);
			getchar();
			exit(1);
		}
	}
	else
	{
		ion_serial_start = 0;
	}
	if (controller[0].Command_Exist(this->module_name, "ion_numbers"))
	{
		sscanf(controller[0].Command(this->module_name, "ion_numbers"), "%d", &(this->ion_numbers));
		ion_serial_end = ion_serial_start + ion_numbers;
		if (ion_serial_end > atom_numbers)
		{
			controller[0].printf("    Error:ion_serial_end %d is larger than atom_numbers %d\n", ion_serial_end, atom_numbers);
			getchar();
			exit(1);
		}
	}
	else
	{
		ion_serial_end = atom_numbers;
		ion_numbers = ion_serial_end - ion_serial_start;
	}
	Cuda_Malloc_Safely((void**)&ion_uint_crd, sizeof(UNSIGNED_INT_VECTOR)*ion_numbers);
	Cuda_Malloc_Safely((void**)&ion_green_force, sizeof(VECTOR)*ion_numbers);
	Cuda_Malloc_Safely((void**)&ion_atom_energy, sizeof(float)*ion_numbers);
	Cuda_Malloc_Safely((void**)&total_energy, sizeof(float)* 1);
	controller[0].printf("    ion_serial_start %d, ion_numbers %d\n", ion_serial_start, ion_numbers);

	//boundary information initial
	if (controller[0].Command_Exist(this->module_name, "z1"))
	{
		sscanf(controller[0].Command(this->module_name, "z1"), "%f", &(this->z1));
	}
	else
	{
		z1 = 0.;
	}
	if (controller[0].Command_Exist(this->module_name, "z2"))
	{
		sscanf(controller[0].Command(this->module_name, "z2"), "%f", &(this->z2));
	}
	else
	{
		z2 = box_length.z;
	}
	if (controller[0].Command_Exist(this->module_name, "ep1"))
	{
		sscanf(controller[0].Command(this->module_name, "ep1"), "%f", &(this->ep1));
	}
	else
	{
		ep1 = 0.;
	}
	if (controller[0].Command_Exist(this->module_name, "ep2"))
	{
		sscanf(controller[0].Command(this->module_name, "ep2"), "%f", &(this->ep2));
	}
	else
	{
		ep2 = 0.;
	}
	z_surface_length = z2 - z1;
	controller[0].printf("    z1    z2    ep1    ep2:\n");
	controller[0].printf("    %4.2f %4.2f %4.2f %4.2f\n", z1, z2, ep1, ep2);


	//grid information initial
	//default grid length is 1.0
	if (controller[0].Command_Exist(this->module_name, "Nx"))
	{
		sscanf(controller[0].Command(this->module_name, "Nx"), "%d", &(this->grid_dimension.int_x));
	}
	else
	{
		grid_dimension.int_x = (int)box_length.x;
	}
	if (controller[0].Command_Exist(this->module_name, "Ny"))
	{
		sscanf(controller[0].Command(this->module_name, "Ny"), "%d", &(this->grid_dimension.int_y));
	}
	else
	{
		grid_dimension.int_y = (int)box_length.y;
	}
	if (controller[0].Command_Exist(this->module_name, "Nz"))
	{
		sscanf(controller[0].Command(this->module_name, "Nz"), "%d", &(this->grid_dimension.int_z));
	}
	else
	{
		grid_dimension.int_z = (int)z_surface_length;
	}
	grid_length.x = (float)box_length.x / grid_dimension.int_x;
	grid_length.y = (float)box_length.y / grid_dimension.int_y;
	grid_length.z = (float)z_surface_length / grid_dimension.int_z;
	grid_length_inverse.x = (float)1. / grid_length.x;
	grid_length_inverse.y = (float)1. / grid_length.y;
	grid_length_inverse.z = (float)1. / grid_length.z;
	grid_length_inverse_square.x = (float)1. / grid_length.x / grid_length.x;
	grid_length_inverse_square.y = (float)1. / grid_length.y / grid_length.y;
	grid_length_inverse_square.z = (float)1. / grid_length.z / grid_length.z;
	layer_numbers = grid_dimension.int_x*grid_dimension.int_y;
	grid_numbers = layer_numbers*grid_dimension.int_z;
	charge_density_scaler = 1. / (grid_length.x * grid_length.y * grid_length.z);
	controller[0].printf("    Nx    Ny    Nz    Ngrid:\n");
	controller[0].printf("    %4d  %4d  %4d  %4d\n",
		grid_dimension.int_x, grid_dimension.int_y,
		grid_dimension.int_z, grid_numbers);

	//may change��Ϊ������plane mode�е糡���ֻ��ֵľ��ȣ���Ҫ�����������cutoff��������dl���ȣ����Ҫ��dl������������ȳ���
	this->cutoff = this->cutoff - grid_length.z;
	cutoff_1 = 1. / this->cutoff;
	cutoff_3 = cutoff_1*cutoff_1*cutoff_1;

	//SOR information initial
	if (controller[0].Command_Exist(this->module_name, "first_gamma"))
	{
		sscanf(controller[0].Command(this->module_name, "first_gamma"), "%f", &(this->first_gamma));
	}
	if (controller[0].Command_Exist(this->module_name, "second_gamma"))
	{
		sscanf(controller[0].Command(this->module_name, "second_gamma"), "%f", &(this->second_gamma));
	}
	if (controller[0].Command_Exist(this->module_name, "first_iteration_steps"))
	{
		sscanf(controller[0].Command(this->module_name, "first_iteration_steps"), "%d", &(this->first_iteration_steps));
	}
	if (controller[0].Command_Exist(this->module_name, "second_iteration_steps"))
	{
		sscanf(controller[0].Command(this->module_name, "second_iteration_steps"), "%d", &(this->second_iteration_steps));
	}
	controller[0].printf("    first_gamma:%f\n    second_gamma:%f\n    first_iteration_steps:%d\n    second_iteration_steps:%d\n",
		first_gamma, second_gamma, first_iteration_steps, second_iteration_steps);
	if (controller[0].Command_Exist(this->module_name, "green_force_refresh_interval"))
	{
		sscanf(controller[0].Command(this->module_name, "green_force_refresh_interval"), "%d", &(this->green_force_refresh_interval));
	}
	current_step = green_force_refresh_interval;
	controller[0].printf("    green_force_refresh_interval:%d\n", green_force_refresh_interval);

	//Green Sphere information initial
	char temp_file_name[CHAR_LENGTH_MAX];
	if (controller[0].Command_Exist(this->module_name, "sphere_pos_file_name"))
	{
		sscanf(controller[0].Command(this->module_name, "sphere_pos_file_name"), "%s", temp_file_name);
	}
	else
	{
		controller[0].printf("    Error:Green Force Need Green Sphere Sampling File!\n");
		getchar();
		exit(1);
	}
	FILE *temp_file_ptr = NULL;
	Open_File_Safely(&temp_file_ptr, temp_file_name, "rb");
	sphere_point_numbers = 0;
	while (true)
	{
		VECTOR temp_vec;
		int pan = fread(&temp_vec, sizeof(VECTOR), 1, temp_file_ptr);
		if (pan == 0)
		{
			break;
		}
		sphere_point_numbers = sphere_point_numbers + 1;
	}
	fclose(temp_file_ptr);
	Malloc_Safely((void**)&h_sphere_sampling_pos, sizeof(VECTOR)*sphere_point_numbers);
	Cuda_Malloc_Safely((void**)&d_sphere_sampling_pos, sizeof(VECTOR)*sphere_point_numbers);
	Cuda_Malloc_Safely((void**)&d_sphere_sampling_pos_with_ds, sizeof(VECTOR)*sphere_point_numbers);
	Cuda_Malloc_Safely((void**)&d_int_sphere_sampling_pos, sizeof(INT_VECTOR)*sphere_point_numbers);
	Open_File_Safely(&temp_file_ptr, temp_file_name, "rb");
	fread(h_sphere_sampling_pos, sizeof(VECTOR), sphere_point_numbers, temp_file_ptr);
	fclose(temp_file_ptr);
	sphere_radius = this->cutoff;
	ds = (float)4.*3.141592654 * 3. / sphere_radius / sphere_radius / sphere_point_numbers;
	sphere_factor = (float)4.*const_parameter.pi / sphere_point_numbers / sphere_radius / sphere_radius;
	plane_factor = (float)4.*const_parameter.pi / sphere_point_numbers*sphere_radius;
	for (int i = 0; i < sphere_point_numbers; i = i + 1)
	{
		h_sphere_sampling_pos[i] = sphere_radius*h_sphere_sampling_pos[i];
	}
	cudaMemcpy(d_sphere_sampling_pos, h_sphere_sampling_pos, sizeof(VECTOR)*sphere_point_numbers, cudaMemcpyHostToDevice);
	for (int i = 0; i < sphere_point_numbers; i = i + 1)
	{
		h_sphere_sampling_pos[i] = ds*h_sphere_sampling_pos[i];
	}
	cudaMemcpy(d_sphere_sampling_pos_with_ds, h_sphere_sampling_pos, sizeof(VECTOR)*sphere_point_numbers, cudaMemcpyHostToDevice);
	for (int i = 0; i < sphere_point_numbers; i = i + 1)
	{
		h_sphere_sampling_pos[i] = (1. / ds)*h_sphere_sampling_pos[i];
	}
	crd_to_int_crd_cof = { const_parameter.uint_max_float / box_length.x, const_parameter.uint_max_float / box_length.y, const_parameter.uint_max_float / z_surface_length };
	Crd_To_Int_Crd << <ceilf((float)sphere_point_numbers / 32), 32 >> >(sphere_point_numbers, crd_to_int_crd_cof, d_sphere_sampling_pos, d_int_sphere_sampling_pos);
	uint_crd_to_crd = 1. / crd_to_int_crd_cof;
	controller[0].printf("    sphere_point_numbers is %d\n", sphere_point_numbers);

	uint_crd_to_grid_serial.x = box_length.x / const_parameter.uint_max_float / grid_length.x;
	uint_crd_to_grid_serial.y = box_length.y / const_parameter.uint_max_float / grid_length.y;
	uint_crd_to_grid_serial.z = z_surface_length / const_parameter.uint_max_float / grid_length.z;
	quarter_crd_to_uint_crd_cof = 0.25*crd_to_int_crd_cof;

	//Grid �ϵı�����ʼ��
	Cuda_Malloc_Safely((void**)&rho, sizeof(float)*grid_numbers);
	Cuda_Malloc_Safely((void**)&phi1, sizeof(float)*grid_numbers);
	Cuda_Malloc_Safely((void**)&phi2, sizeof(float)*grid_numbers);
	Cuda_Malloc_Safely((void**)&phi_ref, sizeof(float)*grid_numbers);
	Malloc_Safely((void**)&h_phi, sizeof(float)*grid_numbers);
	Cuda_Malloc_Safely((void**)&phi_distance, sizeof(float)* 1);

	//initial texture memory
	Initial_TextureObj_EF();

	//initial FFT
	fft.Initial(controller,this);
	//�ж��Ƿ�ʹ��fft
	fft.is_use_FFT = 1;
	if (controller[0].Command_Exist(this->module_name, "FFT"))
	{
		sscanf(controller[0].Command(this->module_name, "FFT"), "%d", &fft.is_use_FFT);
	}
	if (fft.is_use_FFT == 0)
	{
		controller[0].printf("    Use SOR instead of FFT solving Poisson Equation\n");
	}
	else
	{
		controller[0].printf("    Use FFT solving Poisson Equation\n");
	}

	is_initialized = 1;
	if (is_initialized && !is_controller_printf_initialized)
	{
		controller[0].Step_Print_Initial(this->module_name, "%.2f");
		is_controller_printf_initialized = 1;
		controller[0].printf("    structure last modify date is %d\n", last_modify_date);
	}
	controller[0].printf("END INITIALIZING FGM_DOUBLE_LAYER\n\n");
}
void FGM_DOUBLE_LAYER::Initial_TextureObj_EF()
{
	Cuda_Malloc_Safely((void**)&electric_field_with_phi, sizeof(float4)*grid_numbers);

	uint_crd_scale_to_1.x = (float)uint_crd_to_grid_serial.x / grid_dimension.int_x;
	uint_crd_scale_to_1.y = (float)uint_crd_to_grid_serial.y / grid_dimension.int_y;
	uint_crd_scale_to_1.z = (float)uint_crd_to_grid_serial.z / grid_dimension.int_z;

	half_grid_lenth_scale_to_1.x = 0.5*grid_length.x / box_length.x;
	half_grid_lenth_scale_to_1.y = 0.5*grid_length.y / box_length.y;
	half_grid_lenth_scale_to_1.z = 0.5*grid_length.z / z_surface_length;

	// Allocate CUDA array in device memory
	cudaChannelFormatDesc channelDesc =
		cudaCreateChannelDesc(32, 32, 32, 32,
		cudaChannelFormatKindFloat);
	cudaExtent cuEx;
	cuEx.depth = grid_dimension.int_z;
	cuEx.height = grid_dimension.int_y;
	cuEx.width = grid_dimension.int_x;
	cudaMalloc3DArray(&cuArray_EF, &channelDesc, cuEx);
	// copy data to 3D array
	copyParams_EF = { 0 };
	copyParams_EF.srcPtr = make_cudaPitchedPtr((void *)electric_field_with_phi, cuEx.width*sizeof(float4), cuEx.width, cuEx.height);
	copyParams_EF.dstArray = cuArray_EF;
	copyParams_EF.extent = cuEx;
	copyParams_EF.kind = cudaMemcpyDeviceToDevice;
	cudaMemcpy3D(&copyParams_EF);

	// Specify texture
	struct cudaResourceDesc resDesc;
	memset(&resDesc, 0, sizeof(resDesc));
	resDesc.resType = cudaResourceTypeArray;
	resDesc.res.array.array = cuArray_EF;

	// Specify texture object parameters
	struct cudaTextureDesc texDesc;
	memset(&texDesc, 0, sizeof(texDesc));
	texDesc.addressMode[0] = cudaAddressModeWrap;
	texDesc.addressMode[1] = cudaAddressModeWrap;
	texDesc.addressMode[2] = cudaAddressModeWrap;
	texDesc.filterMode = cudaFilterModeLinear;
	texDesc.readMode = cudaReadModeElementType;
	texDesc.normalizedCoords = 1;

	// Create texture object
	cudaCreateTextureObject(&texObj_EF, &resDesc, &texDesc, NULL);
}

void FGM_DOUBLE_LAYER::Refresh_SOR_gamma(float gamma)
{
	SOR_gamma = gamma;
	SOR_gamma_1 = 1. - gamma;
	SOR_gamma_2 = 0.5*gamma /
		((float)1. / grid_length.x / grid_length.x
		+ (float)1. / grid_length.y / grid_length.y
		+ (float)1. / grid_length.z / grid_length.z);
}
void FGM_DOUBLE_LAYER::Solving_Phi_Once(const float *atom_charge, const VECTOR *crd)
{
	Crd_To_Uint_Crd_Partial_And_Z_Move << <ceilf((float)ion_numbers / 128), 128 >> >
		(ion_numbers, ion_serial_start, quarter_crd_to_uint_crd_cof, crd,
		-z1, ion_uint_crd);
	Reset_List << <ceilf((float)grid_numbers / 128), 128 >> >
		(grid_numbers, rho, 0.);
	Distribute_Charge_To_Vertex << <ceilf((float)ion_numbers / 128), 128 >> >
		(ion_numbers, ion_serial_start, atom_charge, charge_density_scaler, ion_uint_crd,
		uint_crd_to_grid_serial, grid_dimension, layer_numbers, rho);
	if (fft.is_use_FFT==0)
	{

		Reset_List << <ceilf((float)grid_numbers / 128), 128 >> >
			(grid_numbers, phi1, 0.);
		Reset_List << <ceilf((float)grid_numbers / 128), 128 >> >
			(grid_numbers, phi2, 0.);

		Refresh_SOR_gamma(first_gamma);
		for (int SOR_step = 0; SOR_step < first_iteration_steps; SOR_step = SOR_step + 1)
		{
			SOR_Iteration_Full << <ceilf((float)grid_numbers / 32), 32 >> >(grid_numbers, grid_dimension, layer_numbers,
				rho, grid_length_inverse_square, SOR_gamma_1, SOR_gamma_2, phi1, phi2);
			Set_Frozen_Phi << <1, 512 >> >(0, layer_numbers, ep1, phi2);
			Set_Frozen_Phi << <1, 512 >> >(grid_numbers - layer_numbers, grid_numbers, ep2, phi2);
			SOR_Iteration_Full << <ceilf((float)grid_numbers / 32), 32 >> >(grid_numbers, grid_dimension, layer_numbers,
				rho, grid_length_inverse_square, SOR_gamma_1, SOR_gamma_2, phi2, phi1);
			Set_Frozen_Phi << <1, 512 >> >(0, layer_numbers, ep1, phi1);
			Set_Frozen_Phi << <1, 512 >> >(grid_numbers - layer_numbers, grid_numbers, ep2, phi1);
		}
		Refresh_SOR_gamma(second_gamma);
		for (int SOR_step = 0; SOR_step < second_iteration_steps; SOR_step = SOR_step + 1)
		{
			SOR_Iteration_Full << <ceilf((float)grid_numbers / 32), 32 >> >(grid_numbers, grid_dimension, layer_numbers,
				rho, grid_length_inverse_square, SOR_gamma_1, SOR_gamma_2, phi1, phi2);
			Set_Frozen_Phi << <1, 512 >> >(grid_numbers - layer_numbers, grid_numbers, ep2, phi2);
			Set_Frozen_Phi << <1, 512 >> >(0, layer_numbers, ep1, phi2);
			SOR_Iteration_Full << <ceilf((float)grid_numbers / 32), 32 >> >(grid_numbers, grid_dimension, layer_numbers,
				rho, grid_length_inverse_square, SOR_gamma_1, SOR_gamma_2, phi2, phi1);
			Set_Frozen_Phi << <1, 512 >> >(0, layer_numbers, ep1, phi1);
			Set_Frozen_Phi << <1, 512 >> >(grid_numbers - layer_numbers, grid_numbers, ep2, phi1);
			/*if (SOR_step % 1 == 0)
			{

			Calculate_Phi_Convergence << <1, 256 >> >
			(grid_numbers, phi1, phi_ref, phi_distance);
			Copy_List << <ceilf((float)grid_numbers / 32), 32 >> >
			(grid_numbers, phi1, phi_ref);
			cudaMemcpy(&h_phi_distance, phi_distance, sizeof(float), cudaMemcpyDeviceToHost);
			printf("	    %8d %8E\n", SOR_step, (float)h_phi_distance / grid_numbers);
			}*/
		}
		SOR_Iteration_Mean << <ceilf((float)grid_numbers / 32), 32 >> >
			(grid_numbers, phi1, phi2);
	}
	else
	{
		fft.Fix_Induced_Charge();
		fft.Solve_Phi();
	}
	FG_Electric_Field << <1, 512 >> >(
		grid_numbers, grid_dimension, layer_numbers,
		0.5*grid_length_inverse, phi1, electric_field_with_phi);
	FG_Electric_Field_Plane_Mode << <1, 512 >> >
		(0, layer_numbers, layer_numbers,
		phi1, grid_length_inverse, electric_field_with_phi);

}
void FGM_DOUBLE_LAYER::Green_Force(const float *atom_charge, const VECTOR *crd, VECTOR *frc)
{
	if (current_step%green_force_refresh_interval == 0)
	{
		Solving_Phi_Once(atom_charge, crd);

		cudaMemcpy3D(&copyParams_EF);
		Green_Force_Near_Plane << <ceilf((float)ion_numbers / 32), 32 >> >
			(ion_numbers, ion_serial_start, ion_uint_crd, atom_charge,
			sphere_point_numbers, d_int_sphere_sampling_pos, d_sphere_sampling_pos,
			uint_crd_scale_to_1,
			half_grid_lenth_scale_to_1,
			texObj_EF, ion_green_force,
			uint_crd_to_crd.z,
			sphere_factor, plane_factor);
		current_step = 0;
	}
	Add_Green_Force << <1, 512 >> >(
		ion_serial_start, ion_serial_end, ion_green_force, frc);
	current_step = current_step + 1;
}
__global__ void SOR_Iteration_Full(const int grid_numbers, const INT_VECTOR grid_dimension, const int layer_numbers,
	const float *rho, const VECTOR grid_length_inverse_square, const float gamma1, const float gamma2, float *phi, float *phi2)
{
	int grid_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (grid_i < grid_numbers)
	{
		INT_VECTOR grid_pos;
		int dx, dx_;
		int dy, dy_;
		int dz, dz_;
		float phi_lin = 0.;

		grid_pos.int_x = grid_i%grid_dimension.int_x;
		grid_pos.int_y = (grid_i % layer_numbers) / grid_dimension.int_x;
		grid_pos.int_z = grid_i / layer_numbers;

		dx = grid_pos.int_x + 1;
		dx = dx&((dx - grid_dimension.int_x) >> 31);
		dy = grid_pos.int_y + 1;
		dy = dy&((dy - grid_dimension.int_y) >> 31);

		dx_ = grid_pos.int_x - 1;
		dx_ = dx_ + (grid_dimension.int_x&((dx_) >> 31));
		dy_ = grid_pos.int_y - 1;
		dy_ = dy_ + (grid_dimension.int_y&((dy_) >> 31));

		dz = grid_pos.int_z + 1;
		dz = dz&((dz - grid_dimension.int_z) >> 31);
		dz_ = grid_pos.int_z - 1;
		dz_ = dz_ + (grid_dimension.int_z&((dz_) >> 31));

		phi_lin = grid_length_inverse_square.x*
			(phi[grid_i - grid_pos.int_x + dx]
			+ phi[grid_i - grid_pos.int_x + dx_]);
		phi_lin = phi_lin + grid_length_inverse_square.y*
			(phi[grid_i - grid_dimension.int_x*(grid_pos.int_y - dy)]
			+ phi[grid_i - grid_dimension.int_x*(grid_pos.int_y - dy_)]);
		phi_lin = phi_lin + grid_length_inverse_square.z*
			(phi[grid_i - layer_numbers*(grid_pos.int_z - dz)]
			+ phi[grid_i - layer_numbers*(grid_pos.int_z - dz_)]);

		phi_lin = phi_lin + rho[grid_i];

		phi2[grid_i] = gamma1*phi2[grid_i] + gamma2*phi_lin;
	}
}
__global__ void Distribute_Charge_To_Vertex
(const int ion_numbers, const int ion_serial_start, const float *atom_charge, const float charge_density_scaler, const UNSIGNED_INT_VECTOR *ion_uint_crd,
const VECTOR scaler, const INT_VECTOR grid_dimension, const int layer_numbers, float *rho
)
{
	int ion_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (ion_i < ion_numbers)
	{

		float charge = atom_charge[ion_i + ion_serial_start] * charge_density_scaler;
		VECTOR lin;
		lin.x = (float)ion_uint_crd[ion_i].uint_x*scaler.x;
		lin.y = (float)ion_uint_crd[ion_i].uint_y*scaler.y;
		lin.z = (float)ion_uint_crd[ion_i].uint_z*scaler.z;

		int grid_x = lin.x;
		int grid_y = lin.y;
		int grid_z = lin.z;
		int dx, dy;


		grid_x = grid_x&((grid_x - grid_dimension.int_x) >> 31);//can opt
		grid_y = grid_y&((grid_y - grid_dimension.int_y) >> 31);
		grid_z = grid_z&((grid_z - grid_dimension.int_z) >> 31);
		int grid_serial = grid_z*layer_numbers + grid_y*grid_dimension.int_x + grid_x;

		lin.x = lin.x - (float)grid_x;
		lin.y = lin.y - (float)grid_y;
		lin.z = lin.z - (float)grid_z;

		float x = 1. - lin.x;
		float y = 1. - lin.y;
		float z = 1. - lin.z;

		float q0 = x*y*z*charge;//need opt
		float qx = lin.x*y*z*charge;
		float qy = x*lin.y*z*charge;
		float qz = x*y*lin.z*charge;
		float qxy = lin.x*lin.y*z*charge;
		float qxz = lin.x*y*lin.z*charge;
		float qyz = x*lin.y*lin.z*charge;
		float qxyz = lin.x*lin.y*lin.z*charge;

		dx = grid_x + 1;
		dx = dx&((dx - grid_dimension.int_x) >> 31);
		dx = dx - grid_x;
		dy = grid_y + 1;
		dy = dy&((dy - grid_dimension.int_y) >> 31);
		dy = dy - grid_y;

		atomicAdd(&rho[grid_serial], q0);
		atomicAdd(&rho[grid_serial + dx], qx);
		atomicAdd(&rho[grid_serial + grid_dimension.int_x*dy], qy);
		atomicAdd(&rho[grid_serial + grid_dimension.int_x*dy + dx], qxy);
		atomicAdd(&rho[grid_serial + layer_numbers], qz);
		atomicAdd(&rho[grid_serial + dx + layer_numbers], qxz);
		atomicAdd(&rho[grid_serial + grid_dimension.int_x*dy + layer_numbers], qyz);
		atomicAdd(&rho[grid_serial + grid_dimension.int_x*dy + dx + layer_numbers], qxyz);
	}
}

__global__ void Crd_To_Uint_Crd_Partial_And_Z_Move
(const int ion_numbers, const int ion_serial_start, const VECTOR scale_factor, const VECTOR *atom_crd,
const float z_move, UNSIGNED_INT_VECTOR *ion_uint_crd)
{
	int ion_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (ion_i < ion_numbers)
	{
		INT_VECTOR tempi;
		VECTOR temp = atom_crd[ion_i + ion_serial_start];
		temp.z = temp.z + z_move;

		temp.x *= scale_factor.x;
		temp.y *= scale_factor.y;
		temp.z *= scale_factor.z;

		tempi.int_x = temp.x;
		tempi.int_y = temp.y;
		tempi.int_z = temp.z;

		ion_uint_crd[ion_i].uint_x = (tempi.int_x << 2);
		ion_uint_crd[ion_i].uint_y = (tempi.int_y << 2);
		ion_uint_crd[ion_i].uint_z = (tempi.int_z << 2);
	}
}
__global__ void Calculate_Phi_Convergence(const int element_numbers, const float *phi1, const float *phi2, float *sum)
{
	if (threadIdx.x == 0)
	{
		sum[0] = 0;
	}
	__syncthreads();
	float lin = 0;
	for (int i = threadIdx.x; i < element_numbers; i = i + blockDim.x)
	{
		lin = lin + (phi1[i] - phi2[i])*(phi1[i] - phi2[i]);
	}
	atomicAdd(sum, lin);
}
__global__ void SOR_Iteration_Mean(const int grid_numbers, float *phi, float *phi2)
{
	int grid_i = (blockDim.x*blockIdx.x + threadIdx.x);
	if (grid_i < grid_numbers)
	{
		phi[grid_i] = 0.5*(phi[grid_i] + phi2[grid_i]);
		phi2[grid_i] = phi[grid_i];
	}
}
__global__ void Set_Frozen_Phi(const int grid_serial_start, const int grid_serial_end, const float ep_phi, float *phi)
{
	for (int i = threadIdx.x + grid_serial_start; i < grid_serial_end; i = i + blockDim.x)
	{
		phi[i] = ep_phi;
	}
}

__global__ void Green_Force_Near_Plane
(const int ion_numbers, const int ion_serial_start, const UNSIGNED_INT_VECTOR *ion_uint_crd, const float *atom_charge,
const int point_numbers, const INT_VECTOR *sphere_point_int_crd, const VECTOR *sphere_crd, const VECTOR scaler_uint_crd_to_1,
const VECTOR half_grid_lenth_devide_box_length,
const cudaTextureObject_t EF_with_phi, VECTOR *ion_frc,
const float scaler_uint_crdz_to_crd,
const float sphere_factor, const float plane_factor)
{
	int ion_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (ion_i < ion_numbers)
	{
		float charge = atom_charge[ion_i + ion_serial_start];
		UNSIGNED_INT_VECTOR crd_i = ion_uint_crd[ion_i];
		UNSIGNED_INT_VECTOR point_j;
		VECTOR r;

		VECTOR frc_lin = { 0., 0., 0. };


		//plane mode 
		int int_z = crd_i.uint_z;
		int_z = -int_z;
		bool is_not_on_plane = true;
		VECTOR integrate_r;
		float float_z = (float)scaler_uint_crdz_to_crd*(crd_i.uint_z);
		float float_lin;
		float4 ef_lin;
		for (int j = 0; j < point_numbers; j = j + 1)
		{
			point_j.uint_x = crd_i.uint_x + sphere_point_int_crd[j].int_x;
			point_j.uint_y = crd_i.uint_y + sphere_point_int_crd[j].int_y;
			point_j.uint_z = crd_i.uint_z + sphere_point_int_crd[j].int_z;
			integrate_r = sphere_crd[j];
			r.x = (float)scaler_uint_crd_to_1.x*point_j.uint_x;
			r.y = (float)scaler_uint_crd_to_1.y*point_j.uint_y;//0~1 ����

			r.x = r.x + half_grid_lenth_devide_box_length.x;
			r.y = r.y + half_grid_lenth_devide_box_length.y;



			is_not_on_plane = true;
			if (sphere_point_int_crd[j].int_z > int_z)
			{
				r.z = (float)scaler_uint_crd_to_1.z*point_j.uint_z;
				r.z = r.z + half_grid_lenth_devide_box_length.z;
			}
			else
			{
				r.z = half_grid_lenth_devide_box_length.z;
				is_not_on_plane = false;
			}
			ef_lin = tex3D<float4>(EF_with_phi, r.x, r.y, r.z);


			if (is_not_on_plane)
			{
				float_lin = integrate_r.x*ef_lin.x;
				float_lin = float_lin + integrate_r.y*ef_lin.y;
				float_lin = float_lin + integrate_r.z*ef_lin.z;

				float_lin = sphere_factor*(2.*ef_lin.w - float_lin);
			}
			else
			{
				float_lin = rnorm3df(integrate_r.x, integrate_r.y, float_z);
				float_lin = plane_factor*ef_lin.z*float_lin*float_lin*float_lin;
				float_lin = -integrate_r.z*float_lin;
				integrate_r.z = -float_z;
			}
			frc_lin.x = frc_lin.x - float_lin*integrate_r.x;
			frc_lin.y = frc_lin.y - float_lin*integrate_r.y;
			frc_lin.z = frc_lin.z - float_lin*integrate_r.z;
		}//green sphere j cycle
		frc_lin.x = frc_lin.x*charge;
		frc_lin.y = frc_lin.y*charge;
		frc_lin.z = frc_lin.z*charge;

		ion_frc[ion_i] = frc_lin;

		//debug
		/*if (ion_i == 0)
		{
			printf("%f %f %f\n", frc_lin.x, frc_lin.y, frc_lin.z);
		}*/

	}//atom_i<atom_numbers
}
__global__ void FG_Electric_Field(
	const int grid_numbers, const INT_VECTOR grid_dimension,
	const int layer_numbers, const VECTOR grid_length_inverse2,
	const float *phi, float4 *ef)
{
	for (int grid_i = threadIdx.x; grid_i < grid_numbers; grid_i = grid_i + blockDim.x)
	{
		INT_VECTOR grid_pos;
		int dx, dx_;
		int dy, dy_;
		int dz, dz_;
		float phi_lin = 0.;

		grid_pos.int_x = grid_i%grid_dimension.int_x;
		grid_pos.int_y = (grid_i % layer_numbers) / grid_dimension.int_x;
		grid_pos.int_z = grid_i / layer_numbers;

		dx = grid_pos.int_x + 1;
		dx = dx&((dx - grid_dimension.int_x) >> 31);
		dy = grid_pos.int_y + 1;
		dy = dy&((dy - grid_dimension.int_y) >> 31);

		dx_ = grid_pos.int_x - 1;
		dx_ = dx_ + (grid_dimension.int_x&((dx_) >> 31));
		dy_ = grid_pos.int_y - 1;
		dy_ = dy_ + (grid_dimension.int_y&((dy_) >> 31));

		dz = grid_pos.int_z + 1;
		dz = dz&((dz - grid_dimension.int_z) >> 31);
		dz_ = grid_pos.int_z - 1;
		dz_ = dz_ + (grid_dimension.int_z&((dz_) >> 31));

		ef[grid_i].x = grid_length_inverse2.x*(phi[grid_i - grid_pos.int_x + dx_] - phi[grid_i - grid_pos.int_x + dx]);
		ef[grid_i].y = grid_length_inverse2.y*(phi[grid_i - grid_dimension.int_x*(grid_pos.int_y - dy_)] - phi[grid_i - grid_dimension.int_x*(grid_pos.int_y - dy)]);
		ef[grid_i].z = grid_length_inverse2.z*(phi[grid_i - layer_numbers*(grid_pos.int_z - dz_)] - phi[grid_i - layer_numbers*(grid_pos.int_z - dz)]);
		ef[grid_i].w = phi[grid_i];
	}
}
__global__ void FG_Electric_Field_Plane_Mode
(const int grid_serial_start, const int grid_serial_end, const int layer_numbers,
const float *phi, const VECTOR grid_length_inverse, float4 *ef)
{
	for (int grid_i = threadIdx.x + grid_serial_start; grid_i < grid_serial_end; grid_i = grid_i + blockDim.x)
	{
		ef[grid_i].z = grid_length_inverse.z*(phi[grid_i] - phi[grid_i + layer_numbers]);
	}
}


__global__ void Add_Green_Force(
	const int ion_serial_start, const int ion_serial_end, VECTOR *ion_green_frc, VECTOR *atom_frc)
{
	for (int atom_i = threadIdx.x + ion_serial_start; atom_i < ion_serial_end; atom_i = atom_i + blockDim.x)
	{
		atom_frc[atom_i] = atom_frc[atom_i] + ion_green_frc[atom_i - ion_serial_start];
	}
}
__global__ void FG_Excluded_Coulomb_Force
(const int atom_numbers, const UNSIGNED_INT_VECTOR *uint_crd, const VECTOR sacler,
const float *charge, const int *excluded_list_start, const int *excluded_list, const int *excluded_atom_numbers,
const float cutoff_3,
VECTOR* frc)
{
	int atom_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (atom_i < atom_numbers)
	{
		int list_start = excluded_list_start[atom_i];
		int atom_min = excluded_list[list_start];
		int e_atom_numbers = excluded_atom_numbers[atom_i];
		if (e_atom_numbers>0)
		{
			int list_end = list_start + e_atom_numbers;
			int atom_j;
			int int_x;
			int int_y;
			int int_z;

			float charge_i = charge[atom_i];
			float charge_j;
			float dr_abs;
			float beta_dr;

			UNSIGNED_INT_VECTOR r1 = uint_crd[atom_i], r2;
			VECTOR dr;


			float frc_abs = 0.;
			VECTOR frc_lin;
			VECTOR frc_record = { 0., 0., 0. };

			for (int i = list_start; i < list_end; i = i + 1)
			{
				atom_j = excluded_list[i];
				r2 = uint_crd[atom_j];
				charge_j = charge[atom_j];

				int_x = r2.uint_x - r1.uint_x;
				int_y = r2.uint_y - r1.uint_y;
				int_z = r2.uint_z - r1.uint_z;
				dr.x = sacler.x*int_x;
				dr.y = sacler.y*int_y;
				dr.z = sacler.z*int_z;

				//�����޳����е�ԭ�ӶԾ�������С��cutoff�ģ�������ϵ

				frc_abs = cutoff_3*charge_i*charge_j;

				frc_lin.x = frc_abs*dr.x;
				frc_lin.y = frc_abs*dr.y;
				frc_lin.z = frc_abs*dr.z;

				frc_record.x = frc_record.x + frc_lin.x;
				frc_record.y = frc_record.y + frc_lin.y;
				frc_record.z = frc_record.z + frc_lin.z;

				atomicAdd(&frc[atom_j].x, -frc_lin.x);
				atomicAdd(&frc[atom_j].y, -frc_lin.y);
				atomicAdd(&frc[atom_j].z, -frc_lin.z);
			}//atom_j cycle
			atomicAdd(&frc[atom_i].x, frc_record.x);
			atomicAdd(&frc[atom_i].y, frc_record.y);
			atomicAdd(&frc[atom_i].z, frc_record.z);
		}//if need excluded
	}
}
__global__ void LJ_Force_With_FGM_DL_CUDA(
	const int atom_numbers, const ATOM_GROUP *nl,
	const UINT_VECTOR_LJ_TYPE *uint_crd, const VECTOR boxlength,
	const float *LJ_type_A, const float *LJ_type_B, const float cutoff,
	VECTOR *frc, VECTOR grid_length_inverse2)
{
	int atom_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (atom_i < atom_numbers)
	{
		int N = nl[atom_i].atom_numbers;
		//int B = ceilf((float)N / blockDim.y);
		int atom_j;
		int int_x;
		int int_y;
		int int_z;
		UINT_VECTOR_LJ_TYPE r1 = uint_crd[atom_i], r2;
		VECTOR dr;
		float dr2;
		float dr_2;
		float dr_4;
		float dr_8;
		float dr_14;
		float frc_abs = 0.;
		VECTOR frc_lin;
		VECTOR frc_record = { 0., 0., 0. };

		//CF
		float charge_ij;
		float dr_1;
		//

		int x, y;
		int atom_pair_LJ_type;

		//plane mode
		float dr_abs;
		float charge_frc_abs = 0.;


		for (int j = threadIdx.y; j < N; j = j + blockDim.y)
		{

			atom_j = nl[atom_i].atom_serial[j];
			r2 = uint_crd[atom_j];
			//CF
			charge_ij = r2.charge*r1.charge;

			int_x = r2.uint_x - r1.uint_x;
			int_y = r2.uint_y - r1.uint_y;
			int_z = r2.uint_z - r1.uint_z;
			dr.x = boxlength.x*int_x;
			dr.y = boxlength.y*int_y;
			dr.z = boxlength.z*int_z;
			dr_abs = norm3df(dr.x, dr.y, dr.z);
			if (dr_abs < cutoff)
			{
				dr_1 = 1. / dr_abs;
				dr_2 = dr_1*dr_1;
				dr_4 = dr_2*dr_2;
				dr_8 = dr_4*dr_4;
				dr_14 = dr_8*dr_4*dr_2;

				y = (r2.LJ_type - r1.LJ_type);
				x = y >> 31;
				y = (y^x) - x;
				x = r2.LJ_type + r1.LJ_type;
				r2.LJ_type = (x + y) >> 1;
				x = (x - y) >> 1;
				atom_pair_LJ_type = (r2.LJ_type*(r2.LJ_type + 1) >> 1) + x;

				frc_abs = -LJ_type_A[atom_pair_LJ_type] * dr_14
					+ LJ_type_B[atom_pair_LJ_type] * dr_8;

				charge_frc_abs = charge_ij*dr_1*dr_2*fminf(1., grid_length_inverse2.z*(cutoff - dr_abs));
				frc_abs = frc_abs - charge_frc_abs;

				frc_lin.x = frc_abs*dr.x;
				frc_lin.y = frc_abs*dr.y;
				frc_lin.z = frc_abs*dr.z;

				frc_record.x = frc_record.x + frc_lin.x;
				frc_record.y = frc_record.y + frc_lin.y;
				frc_record.z = frc_record.z + frc_lin.z;

				atomicAdd(&frc[atom_j].x, -frc_lin.x);
				atomicAdd(&frc[atom_j].y, -frc_lin.y);
				atomicAdd(&frc[atom_j].z, -frc_lin.z);
			}

		}//atom_j cycle
		atomicAdd(&frc[atom_i].x, frc_record.x);
		atomicAdd(&frc[atom_i].y, frc_record.y);
		atomicAdd(&frc[atom_i].z, frc_record.z);
	}
}

//sphere_factor=4.*Pi/N
//plane_factor=4.*Pi*R/N
__global__ void Green_Energy_Near_Plane
(const int ion_numbers, const int ion_serial_start, const UNSIGNED_INT_VECTOR *ion_uint_crd, const float *atom_charge,
const int point_numbers, const INT_VECTOR *sphere_point_int_crd, const VECTOR *sphere_crd, const VECTOR scaler_uint_crd_to_1,
const VECTOR half_grid_lenth_devide_box_length,
const cudaTextureObject_t EF_with_phi, float *ion_atom_energy,
const float scaler_uint_crdz_to_crd,
const float sphere_factor, const float plane_factor)
{
	int ion_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (ion_i < ion_numbers)
	{
		float charge = atom_charge[ion_i + ion_serial_start];
		UNSIGNED_INT_VECTOR crd_i = ion_uint_crd[ion_i];
		UNSIGNED_INT_VECTOR point_j;
		VECTOR r;

		float ene_lin = 0.;


		//plane mode
		int int_z = crd_i.uint_z;
		int_z = -int_z;
		bool is_not_on_plane = true;
		VECTOR integrate_r;
		float float_z = (float)scaler_uint_crdz_to_crd*(crd_i.uint_z);
		float float_lin;
		float4 ef_lin;
		for (int j = 0; j < point_numbers; j = j + 1)
		{
			point_j.uint_x = crd_i.uint_x + sphere_point_int_crd[j].int_x;
			point_j.uint_y = crd_i.uint_y + sphere_point_int_crd[j].int_y;
			point_j.uint_z = crd_i.uint_z + sphere_point_int_crd[j].int_z;
			integrate_r = sphere_crd[j];
			r.x = (float)scaler_uint_crd_to_1.x*point_j.uint_x;
			r.y = (float)scaler_uint_crd_to_1.y*point_j.uint_y;//0~1 ����

			r.x = r.x + half_grid_lenth_devide_box_length.x;
			r.y = r.y + half_grid_lenth_devide_box_length.y;



			is_not_on_plane = true;
			if (sphere_point_int_crd[j].int_z > int_z)
			{
				r.z = (float)scaler_uint_crd_to_1.z*point_j.uint_z;
				r.z = r.z + half_grid_lenth_devide_box_length.z;
			}
			else
			{
				r.z = half_grid_lenth_devide_box_length.z;
				is_not_on_plane = false;
			}
			ef_lin = tex3D<float4>(EF_with_phi, r.x, r.y, r.z);


			if (is_not_on_plane)
			{
				float_lin = integrate_r.x*ef_lin.x;
				float_lin = float_lin + integrate_r.y*ef_lin.y;
				float_lin = float_lin + integrate_r.z*ef_lin.z;

				float_lin = sphere_factor*(float_lin + ef_lin.w);// sphere_factor*(2.*ef_lin.w - float_lin);
			}
			else
			{
				float_lin = rnorm3df(integrate_r.x, integrate_r.y, float_z);
				float_lin = ef_lin.z*float_lin;
				float_lin = -plane_factor*fabsf(integrate_r.z)*float_lin;//fabsf(integrate_r.z)�ǻ�����Ԫϵ��
			}
			ene_lin = ene_lin + float_lin;
		}//green sphere j cycle
		ion_atom_energy[ion_i] = charge*ene_lin;

	}//atom_i<atom_numbers
}

//B=-grid_length_inverse2.x*(1.+logf(-1./grid_length_inverse2.x+cutoff))
//C=grid_length_inverse2.x*logf((cutoff-1/grid_length_inverse2.x)/cutoff)
//g=grid_length_inverse2.x
//small_cutoff=R-1/grid_length_inverse2.x
//Energy=1/r+C if r<R-1/grid_length_inverse2.x
//=grid_length_inverse2.x*(R/r+logf(r))+B+C else
__global__ void FGM_DL_Direct_Energy_CUDA(
	const int ion_numbers, const int ion_serial_start,
	const ATOM_GROUP *atom_nl, const UNSIGNED_INT_VECTOR *atom_uint_crd, const float *atom_charge,
	const VECTOR boxlength, const float g,
	const float cutoff, const float B, const float C, const float small_cutoff,
	float *ion_atom_energy)
{
	int ion_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (ion_i < ion_numbers)
	{
		int atom_i = ion_i + ion_serial_start;
		int N = atom_nl[atom_i].atom_numbers;
		//int B = ceilf((float)N / blockDim.y);
		int atom_j;
		int int_x;
		int int_y;
		int int_z;
		UNSIGNED_INT_VECTOR r1 = atom_uint_crd[atom_i], r2;
		float charge1 = atom_charge[atom_i], charge2;
		VECTOR dr;

		//CF
		float dr_1;
		float dr_abs;
		float ene_lin = 0.;
		float energy = 0.;

		for (int j = threadIdx.y; j < N; j = j + blockDim.y)
		{

			atom_j = atom_nl[atom_i].atom_serial[j];
			r2 = atom_uint_crd[atom_j];
			charge2 = atom_charge[atom_j];

			int_x = r2.uint_x - r1.uint_x;
			int_y = r2.uint_y - r1.uint_y;
			int_z = r2.uint_z - r1.uint_z;
			dr.x = boxlength.x*int_x;
			dr.y = boxlength.y*int_y;
			dr.z = boxlength.z*int_z;

			dr_abs = norm3df(dr.x, dr.y, dr.z);
			if (dr_abs < cutoff)
			{
				dr_1 = 1. / dr_abs;
				if (dr_abs < small_cutoff)
				{
					ene_lin = (dr_1 + C);
				}
				else
				{
					ene_lin = g*(cutoff*dr_1 + logf(dr_abs)) + B + C;
				}
				energy = energy + charge1*charge2*ene_lin;
			}

		}//atom_j cycle
		atomicAdd(&ion_atom_energy[ion_i], energy);
	}
}

float FGM_DOUBLE_LAYER::Green_Energy(const dim3 thread, const ATOM_GROUP *atom_nl, const VECTOR *crd, const UNSIGNED_INT_VECTOR *uint_crd, const VECTOR box_scalor, const float *atom_charge, int is_download)
{
	Solving_Phi_Once(atom_charge, crd);
	cudaMemcpy3D(&copyParams_EF);
	Green_Energy_Near_Plane << <ceilf((float)ion_numbers / 32), 32 >> >
		(ion_numbers, ion_serial_start, ion_uint_crd, atom_charge,
		sphere_point_numbers, d_int_sphere_sampling_pos, d_sphere_sampling_pos,
		uint_crd_scale_to_1, half_grid_lenth_scale_to_1,
		texObj_EF, ion_atom_energy,
		uint_crd_to_crd.z,
		sphere_factor*sphere_radius*sphere_radius, plane_factor);

	VECTOR grid_length_inverse2 = 0.5*grid_length_inverse;
	FGM_DL_Direct_Energy_CUDA << <ceilf((float)ion_numbers / thread.x), thread >> >
		(
		ion_numbers, ion_serial_start,
		atom_nl, uint_crd, atom_charge,
		box_scalor, grid_length_inverse2.z,
		origin_cutoff, -grid_length_inverse2.z*(1. + logf(-1. / grid_length_inverse2.z + origin_cutoff)),
		grid_length_inverse2.z*logf((origin_cutoff - 1 / grid_length_inverse2.z) / origin_cutoff),
		origin_cutoff - 1. / grid_length_inverse2.z,
		ion_atom_energy);

	Sum_Of_List(ion_atom_energy, total_energy, ion_numbers);
	if (is_download == 1)
	{
		cudaMemcpy(&h_total_energy, total_energy, sizeof(float), cudaMemcpyDeviceToHost);
		return h_total_energy;
	}
	else
	{
		return 0.;
	}
}