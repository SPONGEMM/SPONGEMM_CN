#include "FGM_Double_Layer.cuh"
__global__ void Build_fijk_inverse_List(const int grid_numbers, const INT_VECTOR grid_dimension,
	const INT_VECTOR grid_dimension_upper_half,
	const VECTOR box_length_inverse_square, float *fijk_inverse_list)
{
	int gpu_grid_layer_numbers = gridDim.x*blockDim.x;

	//ע�⣬����������б���for NyNxNz������ģ����ڶ���һά����Ҷ�任
	int xz_layer_numbers = grid_dimension.int_x*grid_dimension.int_z;
	INT_VECTOR grid_pos;
	INT_VECTOR grid_fft_serial;
	int temp;
	for (int grid_i = blockIdx.x*blockDim.x+threadIdx.x; grid_i < grid_numbers; grid_i = grid_i + gpu_grid_layer_numbers)
	{
		grid_pos.int_z = grid_i%grid_dimension.int_z;
		grid_pos.int_x = (grid_i % xz_layer_numbers) / grid_dimension.int_z;
		grid_pos.int_y = grid_i / xz_layer_numbers;

		temp = grid_pos.int_x - grid_dimension_upper_half.int_x;
		temp = temp >> 31;
		grid_fft_serial.int_x = (temp& grid_pos.int_x) + ((~temp)&(grid_dimension.int_x - grid_pos.int_x));

		temp = grid_pos.int_y - grid_dimension_upper_half.int_y;
		temp = temp >> 31;
		grid_fft_serial.int_y = (temp& grid_pos.int_y) + ((~temp)&(grid_dimension.int_y - grid_pos.int_y));

		temp = grid_pos.int_z - grid_dimension_upper_half.int_z;
		temp = temp >> 31;
		grid_fft_serial.int_z = (temp& grid_pos.int_z) + ((~temp)&(grid_dimension.int_z - grid_pos.int_z));

		//(1. / 4. / CONSTANT_Pi / CONSTANT_Pi) constant folding?
		fijk_inverse_list[grid_i] = (1. / 4. / CONSTANT_Pi / CONSTANT_Pi) / ((float)
			grid_fft_serial.int_x*grid_fft_serial.int_x*box_length_inverse_square.x
			+ grid_fft_serial.int_y*grid_fft_serial.int_y*box_length_inverse_square.y
			+ grid_fft_serial.int_z*grid_fft_serial.int_z*box_length_inverse_square.z);
		/*if (grid_i > 105 * 40 * 50-10)
		{
			printf("%d %d %d %d %f\n",grid_i, grid_pos.int_x, grid_pos.int_y, grid_pos.int_z, fijk_inverse_list[grid_i]);
		}*/
	}
	fijk_inverse_list[0] = 0.;//���Խ�000��Ϊ0
}
__global__ void Build_periodic_3d_fator_List(const int NzNy_Nx21_numbers, const INT_VECTOR grid_dimension,
	const float grid_numbers_inverse,
	const INT_VECTOR grid_dimension_upper_half, const INT_VECTOR grid_dimension_lower_half_plus_one,
	const VECTOR box_length_inverse_square, float *periodic_3d_fator_list)
{
	int gpu_grid_layer_numbers = gridDim.x*blockDim.x;
	int layer_numbers = grid_dimension.int_y*grid_dimension_lower_half_plus_one.int_x;

	INT_VECTOR grid_pos;
	INT_VECTOR grid_fft_serial;
	int temp;
	for (int grid_i = blockIdx.x*blockDim.x + threadIdx.x; grid_i < NzNy_Nx21_numbers; grid_i = grid_i + gpu_grid_layer_numbers)
	{
		grid_pos.int_x = grid_i%grid_dimension_lower_half_plus_one.int_x;
		grid_pos.int_y = (grid_i % layer_numbers) / grid_dimension_lower_half_plus_one.int_x;
		grid_pos.int_z = grid_i / layer_numbers;

		temp = grid_pos.int_x - grid_dimension_upper_half.int_x;
		temp = temp >> 31;
		grid_fft_serial.int_x = (temp& grid_pos.int_x) + ((~temp)&(grid_dimension.int_x - grid_pos.int_x));

		temp = grid_pos.int_y - grid_dimension_upper_half.int_y;
		temp = temp >> 31;
		grid_fft_serial.int_y = (temp& grid_pos.int_y) + ((~temp)&(grid_dimension.int_y - grid_pos.int_y));

		temp = grid_pos.int_z - grid_dimension_upper_half.int_z;
		temp = temp >> 31;
		grid_fft_serial.int_z = (temp& grid_pos.int_z) + ((~temp)&(grid_dimension.int_z - grid_pos.int_z));

		//(1. / 4. / CONSTANT_Pi / CONSTANT_Pi) constant folding?
		periodic_3d_fator_list[grid_i] = (1. / 4. / CONSTANT_Pi / CONSTANT_Pi) / ((float)
			grid_fft_serial.int_x*grid_fft_serial.int_x*box_length_inverse_square.x
			+ grid_fft_serial.int_y*grid_fft_serial.int_y*box_length_inverse_square.y
			+ grid_fft_serial.int_z*grid_fft_serial.int_z*box_length_inverse_square.z)*grid_numbers_inverse;
		/*if (grid_i > 105 * 40 * 50-10)
		{
		printf("%d %d %d %d %f\n",grid_i, grid_pos.int_x, grid_pos.int_y, grid_pos.int_z, fijk_inverse_list[grid_i]);
		}*/
	}
	periodic_3d_fator_list[0] = 0.;//���Խ�000��Ϊ0
}
__global__ void Build_fstarijn0_List(const int NzNy_Nx21_numbers, const INT_VECTOR grid_dimension,
	const INT_VECTOR grid_dimension_upper_half, const INT_VECTOR grid_dimension_lower_half_plus_one,
	const cufftComplex *fft_fijk_inverse_list, float *fstarijn0_list, const float NxNy_fft_scalor)
{
	int gpu_grid_layer_numbers = gridDim.x*blockDim.x;

	INT_VECTOR grid_pos_of_fstarijn0;
	int layer_numbers_of_fstarijn0 = grid_dimension.int_y*grid_dimension_lower_half_plus_one.int_x;

	int grid_i_of_fft_fijk_inverse;
	int layer_numbers_of_fft_fjik_inverse = grid_dimension.int_x*grid_dimension_lower_half_plus_one.int_z;
	int z_serial;

	int temp;
	for (int grid_i = blockIdx.x*blockDim.x + threadIdx.x; grid_i < NzNy_Nx21_numbers; grid_i = grid_i + gpu_grid_layer_numbers)
	{
		grid_pos_of_fstarijn0.int_x = grid_i%grid_dimension_lower_half_plus_one.int_x;
		grid_pos_of_fstarijn0.int_y = (grid_i % layer_numbers_of_fstarijn0) / grid_dimension_lower_half_plus_one.int_x;
		grid_pos_of_fstarijn0.int_z = grid_i / layer_numbers_of_fstarijn0;

		grid_i_of_fft_fijk_inverse = grid_pos_of_fstarijn0.int_y*layer_numbers_of_fft_fjik_inverse
			+ grid_pos_of_fstarijn0.int_x*grid_dimension_lower_half_plus_one.int_z;//ʵ�ʻ�Ӧ�ü���z_serial

		temp = grid_pos_of_fstarijn0.int_z - grid_dimension_upper_half.int_z;
		temp = temp >> 31;
		z_serial = (temp& grid_pos_of_fstarijn0.int_z) + ((~temp)&(grid_dimension.int_z - grid_pos_of_fstarijn0.int_z));

		fstarijn0_list[grid_i] = fft_fijk_inverse_list[grid_i_of_fft_fijk_inverse + z_serial].x / fft_fijk_inverse_list[grid_i_of_fft_fijk_inverse].x*NxNy_fft_scalor;
		/*if (grid_pos_of_fstarijn0.int_x < 2 && grid_pos_of_fstarijn0.int_y < 2 && grid_pos_of_fstarijn0.int_z < 2)
		{
			printf("%d %d %d %d %f %f %f\n",
				grid_i,
				grid_pos_of_fstarijn0.int_x,
				grid_pos_of_fstarijn0.int_y,
				grid_pos_of_fstarijn0.int_z,
				fstarijn0_list[grid_i],
				fft_fijk_inverse_list[grid_i_of_fft_fijk_inverse + z_serial].x,
				fft_fijk_inverse_list[grid_i_of_fft_fijk_inverse].x);
		}*/
	}
}
__global__ void Map_Induced_Charge_Density_Cuda(const int NxNy_layer_numbers,const int Nz,const float *plane_P,float *rho)
{
	int gpu_grid_layer_numbers = gridDim.x*blockDim.x;
	float temp_record = 0.;
	int grid_i;
	for (int column_i = blockIdx.x*blockDim.x + threadIdx.x; column_i < NxNy_layer_numbers; column_i = column_i + gpu_grid_layer_numbers)
	{
		temp_record = 0.;
		grid_i = column_i;
		for (int z = 0; z < Nz; z = z + 1)
		{
			temp_record = temp_record - plane_P[grid_i];
			grid_i = grid_i + NxNy_layer_numbers;
		}
		atomicAdd(&rho[column_i], temp_record);
		/*if (true||column_i < 200)
		{
			printf("%d %f\n", column_i, temp_record);
		}*/
	}
}
__global__ void Array_float_Multiply_cufftComplex(const int array_numbers, const float *f, cufftComplex *c)
{
	int gpu_grid_layer_numbers = gridDim.x*blockDim.x;
	for (int i = blockIdx.x*blockDim.x + threadIdx.x; i < array_numbers; i = i + gpu_grid_layer_numbers)
	{
		c[i].x = f[i] * c[i].x;
		c[i].y = f[i] * c[i].y;
	}
}
void FGM_DOUBLE_LAYER::FFT::Initial(CONTROLLER *controller, FGM_DOUBLE_LAYER *fgm)
{
	//�������������Ԥ����
	this->fgm = fgm;

	this->box_length = fgm->box_length;
	this->box_length.z = fgm->z_surface_length;
	box_length_inverse_square.x = 1. / box_length.x / box_length.x;
	box_length_inverse_square.y = 1. / box_length.y / box_length.y;
	box_length_inverse_square.z = 1. / box_length.z / box_length.z;

	this->grid_dimension = fgm->grid_dimension;
	grid_dimension_upper_half.int_x = (grid_dimension.int_x + 1) >> 1;
	grid_dimension_upper_half.int_y = (grid_dimension.int_y + 1) >> 1;
	grid_dimension_upper_half.int_z = (grid_dimension.int_z + 1) >> 1;

	grid_dimension_lower_half_plus_one.int_x = (grid_dimension.int_x >> 1) + 1;
	grid_dimension_lower_half_plus_one.int_y = (grid_dimension.int_y >> 1) + 1;
	grid_dimension_lower_half_plus_one.int_z = (grid_dimension.int_z >> 1) + 1;

	NzNy_Nx21_numbers = grid_dimension.int_y*(grid_dimension.int_x / 2 + 1)*grid_dimension.int_z;

	//����fijk_inverse��ά���飬������˳��Ϊfor NyNxNz
	Cuda_Malloc_Safely((void**)&fijk_inverse, sizeof(float)*fgm->grid_numbers);
	Build_fijk_inverse_List << <20, 32 >> >(fgm->grid_numbers, grid_dimension,
		grid_dimension_upper_half,
		box_length_inverse_square, fijk_inverse);

	//��fijk_inverse��ά�����Nz������һάr2c����Ҷ�任����ÿ��ij�����У���NyNx�Σ���Ϊfft_fijk_inverse��ʵΪNyNx(Nz/2+1)��ά����
	int n1d[1] = { grid_dimension.int_z };
	cuda_result = cufftPlanMany(&plan_1d_many_r2c, 1, n1d, NULL, 0, 0, NULL, 0, 0, CUFFT_R2C, fgm->layer_numbers);
	if (cuda_result != CUFFT_SUCCESS)
	{
		controller[0].printf("    FFT initial failed, cuda_result %d\n", cuda_result);
		getchar();
	}
	Cuda_Malloc_Safely((void**)&fft_fijk_inverse, sizeof(cufftComplex)*fgm->layer_numbers*(fgm->grid_dimension.int_z / 2 + 1));
	cufftExecR2C(plan_1d_many_r2c, fijk_inverse, fft_fijk_inverse);
	
	//����fft_fijk_inverse��NyNx(Nz/2+1)������õ�fstartijn0��NzNy(Nx/2+1)����ά���顣fstartijn0[i,j,n]=fft_fijk_inverse[i,j,n]/fft_fijk_inverse[i,j,0];
	Cuda_Malloc_Safely((void**)&fstartijn0, sizeof(float)*grid_dimension.int_z*grid_dimension.int_y*grid_dimension_lower_half_plus_one.int_x);
	Build_fstarijn0_List << <20, 32 >> >(grid_dimension.int_z*grid_dimension.int_y*grid_dimension_lower_half_plus_one.int_x,
		grid_dimension,
		grid_dimension_upper_half, grid_dimension_lower_half_plus_one,
		fft_fijk_inverse, fstartijn0,(float)1./fgm->layer_numbers);

	//��ʼ����ά����ܶȷֲ�P��xy��ά��z����Ҷ�任r2c��c2r��
	int n2d[2] = { grid_dimension.int_y, grid_dimension.int_x };
	cuda_result = cufftPlanMany(&plan_2d_many_r2c, 2, n2d, NULL, 0, 0, NULL, 0, 0, CUFFT_R2C, grid_dimension.int_z);
	cuda_result = cufftPlanMany(&plan_2d_many_c2r, 2, n2d, NULL, 0, 0, NULL, 0, 0, CUFFT_C2R, grid_dimension.int_z);
	if (cuda_result != CUFFT_SUCCESS)
	{
		controller[0].printf("    FFT initial failed, cuda_result %d\n", cuda_result);
		getchar();
	}
	Cuda_Malloc_Safely((void**)&fft2d_many_P, sizeof(cufftComplex)*grid_dimension.int_y*(grid_dimension.int_x / 2 + 1)*grid_dimension.int_z);
	Cuda_Malloc_Safely((void**)&plane_P, sizeof(float)*fgm->grid_numbers);

	//�����ʼ��������xyz������ȫ�����Ա߽�������Ⲵ�ɷ���һģһ��
	cufftPlan3d(&plan_3d_r2c, grid_dimension.int_z, grid_dimension.int_y, grid_dimension.int_x, CUFFT_R2C);
	cufftPlan3d(&plan_3d_c2r, grid_dimension.int_z, grid_dimension.int_y, grid_dimension.int_x, CUFFT_C2R);
	Cuda_Malloc_Safely((void**)&fft3d_rho, sizeof(cufftComplex)*NzNy_Nx21_numbers);
	Cuda_Malloc_Safely((void**)&periodic_3d_fator, sizeof(float)*NzNy_Nx21_numbers);
	Build_periodic_3d_fator_List << <20, 32 >> >
		(NzNy_Nx21_numbers, grid_dimension, (float)1./fgm->grid_numbers,
		grid_dimension_upper_half, grid_dimension_lower_half_plus_one,
		box_length_inverse_square, periodic_3d_fator);
}
void FGM_DOUBLE_LAYER::FFT::Fix_Induced_Charge()
{
	cufftExecR2C(plan_2d_many_r2c, fgm->rho, fft2d_many_P);
	Array_float_Multiply_cufftComplex << <20, 32 >> >
		(NzNy_Nx21_numbers, fstartijn0, fft2d_many_P);
	cufftExecC2R(plan_2d_many_c2r, fft2d_many_P, plane_P);
	Map_Induced_Charge_Density_Cuda << <20, 32 >> >
		(fgm->layer_numbers, grid_dimension.int_z, plane_P, fgm->rho);
}
void FGM_DOUBLE_LAYER::FFT::Solve_Phi()
{
	cufftExecR2C(plan_3d_r2c, fgm->rho, fft3d_rho);
	Array_float_Multiply_cufftComplex << <20, 32 >> >
		(NzNy_Nx21_numbers, periodic_3d_fator, fft3d_rho);
	cufftExecC2R(plan_3d_c2r, fft3d_rho, fgm->phi1);
	//20210529���ⲽû����
}
int FGM_DOUBLE_LAYER::FFT::min(int a, int b)
{
	if (a < b)
	{
		return a;
	}
	else
	{
		return b;
	}
}
__global__ void temp20210528_cuda(const int grid_numbers, const float *phi, const float *x, const float *y, const float *z, float4 *ef_wi_phi)
{
	for (int grid_i = threadIdx.x; grid_i < grid_numbers; grid_i = grid_i + blockDim.x)
	{
		ef_wi_phi[grid_i].x = x[grid_i];
		ef_wi_phi[grid_i].y = y[grid_i];
		ef_wi_phi[grid_i].z = z[grid_i];
		ef_wi_phi[grid_i].w = phi[grid_i];
	}
}
void FGM_DOUBLE_LAYER::FFT::temp20210528()
{
	printf("in temp function initial\n");
	float *h_f_inverse = NULL;//f[i,j,k]=4Pi^2*(i^2/a^2+j^2/b^2+k^2/c^2);
	float *d_f_inverse = NULL;
	cufftComplex *d_fft_f_inverse = NULL;
	cufftComplex *h_fft_f_inverse = NULL;

	float *h_f_star_0 = NULL;
	float *d_f_star_0 = NULL;
	cufftComplex *d_P2d = NULL;
	cufftComplex *h_P2d = NULL;
	float *d_fft_fft_P2d = NULL;
	float *h_fft_fft_P2d = NULL;


	cufftResult temp_cuda_result;
	cufftHandle plan_1d_many_r2c;
	cufftHandle plan_2d_many_r2c;
	cufftHandle plan_2d_many_c2r;

	cufftComplex *d_fft_rho = NULL;
	cufftComplex *h_fft_rho = NULL;

	cufftHandle plan_3d_r2c;
	cufftHandle plan_3d_c2r;

	float *ef_x = NULL;
	float *ef_y = NULL;
	float *ef_z = NULL;
	float4 *h_ef_phi = NULL;

	Malloc_Safely((void**)&h_f_inverse, sizeof(float)*fgm->grid_numbers);
	Cuda_Malloc_Safely((void**)&d_f_inverse, sizeof(float)*fgm->grid_numbers);
	Cuda_Malloc_Safely((void**)&d_fft_f_inverse, sizeof(cufftComplex)*fgm->layer_numbers*(fgm->grid_dimension.int_z / 2 + 1));
	Malloc_Safely((void**)&h_fft_f_inverse, sizeof(cufftComplex)*fgm->layer_numbers*(fgm->grid_dimension.int_z / 2 + 1));

	for (int j = 0; j < fgm->grid_dimension.int_y; j = j + 1)
	{
		for (int i = 0; i < fgm->grid_dimension.int_x; i = i + 1)
		{
			for (int k = 0; k < fgm->grid_dimension.int_z; k = k + 1)
			{
				int grid_serial = j*fgm->grid_dimension.int_x*fgm->grid_dimension.int_z + i*fgm->grid_dimension.int_z + k;
				int ii = min(i, fgm->grid_dimension.int_x - i);
				int jj = min(j, fgm->grid_dimension.int_y - j);
				int kk = min(k, fgm->grid_dimension.int_z - k);

				h_f_inverse[grid_serial] = (float)1. / (4.*CONSTANT_Pi*CONSTANT_Pi*(ii*ii / fgm->box_length.x / fgm->box_length.x + jj*jj / fgm->box_length.y / fgm->box_length.y + kk*kk / fgm->z_surface_length / fgm->z_surface_length));
			}
		}
	}
	h_f_inverse[0] = 0.;
	cudaMemcpy(d_f_inverse, h_f_inverse, sizeof(float)*fgm->grid_numbers, cudaMemcpyHostToDevice);

	int n[1] = { fgm->grid_dimension.int_z };
	temp_cuda_result = cufftPlanMany(&plan_1d_many_r2c, 1, n, NULL, 0, 0, NULL, 0, 0, CUFFT_R2C, fgm->layer_numbers);
	if (temp_cuda_result != CUFFT_SUCCESS)
	{
		printf("    FFT initial failed, %d\n", temp_cuda_result);
		getchar();
	}
	cufftExecR2C(plan_1d_many_r2c, d_f_inverse, d_fft_f_inverse);
	cudaMemcpy(h_fft_f_inverse, d_fft_f_inverse, sizeof(cufftComplex)*fgm->layer_numbers*(fgm->grid_dimension.int_z / 2 + 1), cudaMemcpyDeviceToHost);
	/*for (int j = 49; j < fgm->grid_dimension.int_y; j = j + 1)
	{
	for (int i = 104; i < fgm->grid_dimension.int_x; i = i + 1)
	{
	for (int k = 0; k <(fgm->grid_dimension.int_z / 2 + 1); k = k + 1)
	{
	int grid_serial = j*fgm->grid_dimension.int_x*(fgm->grid_dimension.int_z / 2 + 1) + i*(fgm->grid_dimension.int_z / 2 + 1) + k;
	printf("%d %d %d %f %f\n", i, j, k, h_fft_f_inverse[grid_serial].x, h_fft_f_inverse[grid_serial].y);
	getchar();
	}
	}
	}*/

	Cuda_Malloc_Safely((void**)&d_f_star_0, sizeof(float)*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1)*fgm->grid_dimension.int_z);
	Malloc_Safely((void**)&h_f_star_0, sizeof(float)*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1)*fgm->grid_dimension.int_z);

	for (int z = 0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < (fgm->grid_dimension.int_x / 2 + 1); x = x + 1)
			{
				int f_star_0_grid_serial = z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1) + y*(fgm->grid_dimension.int_x / 2 + 1) + x;
				int fft_f_inverse_grid_serial = y*fgm->grid_dimension.int_x*(fgm->grid_dimension.int_z / 2 + 1) + x*(fgm->grid_dimension.int_z / 2 + 1) + min(z, fgm->grid_dimension.int_z - z);
				int fft_f_inverse_0grid_serial = y*fgm->grid_dimension.int_x*(fgm->grid_dimension.int_z / 2 + 1) + x*(fgm->grid_dimension.int_z / 2 + 1) + 0;
				h_f_star_0[f_star_0_grid_serial] = h_fft_f_inverse[fft_f_inverse_grid_serial].x / h_fft_f_inverse[fft_f_inverse_0grid_serial].x;
				/*if (x < 2 && y < 2 && z < 2)
				{
					printf("%d %d %d %d %f %f %f\n", f_star_0_grid_serial, x, y, z, h_f_star_0[f_star_0_grid_serial],
						h_fft_f_inverse[fft_f_inverse_grid_serial].x , h_fft_f_inverse[fft_f_inverse_0grid_serial].x);
					//getchar();
				}*/
			}
		}
	}
	//getchar();

	int n2d[2] = { fgm->grid_dimension.int_y, fgm->grid_dimension.int_x };
	temp_cuda_result = cufftPlanMany(&plan_2d_many_r2c, 2, n2d, NULL, 0, 0, NULL, 0, 0, CUFFT_R2C, fgm->grid_dimension.int_z);
	temp_cuda_result = cufftPlanMany(&plan_2d_many_c2r, 2, n2d, NULL, 0, 0, NULL, 0, 0, CUFFT_C2R, fgm->grid_dimension.int_z);
	if (temp_cuda_result != CUFFT_SUCCESS)
	{
		printf("    FFT initial failed, %d\n", temp_cuda_result);
		getchar();
	}

	Cuda_Malloc_Safely((void**)&d_P2d, sizeof(cufftComplex)*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1)*fgm->grid_dimension.int_z);
	Malloc_Safely((void**)&h_P2d, sizeof(cufftComplex)*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1)*fgm->grid_dimension.int_z);

	Cuda_Malloc_Safely((void**)&d_fft_fft_P2d, sizeof(float)*fgm->grid_numbers);
	Malloc_Safely((void**)&h_fft_fft_P2d, sizeof(float)*fgm->grid_numbers);

	printf("in temp function\n");
	cufftExecR2C(plan_2d_many_r2c, fgm->rho, d_P2d);
	cudaMemcpy(h_P2d, d_P2d, sizeof(cufftComplex)*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1)*fgm->grid_dimension.int_z, cudaMemcpyDeviceToHost);
	for (int z = 0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < (fgm->grid_dimension.int_x / 2 + 1); x = x + 1)
			{
				int f_star_0_grid_serial = z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1) + y*(fgm->grid_dimension.int_x / 2 + 1) + x;
				h_P2d[f_star_0_grid_serial].x = h_f_star_0[f_star_0_grid_serial] * h_P2d[f_star_0_grid_serial].x;
				h_P2d[f_star_0_grid_serial].y = h_f_star_0[f_star_0_grid_serial] * h_P2d[f_star_0_grid_serial].y;
				//printf("%d %d %d %e %e\n", x, y, z, h_P2d[f_star_0_grid_serial].x, h_P2d[f_star_0_grid_serial].y);
				//getchar();
			}
		}
	}
	cudaMemcpy(d_P2d,h_P2d, sizeof(cufftComplex)*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1)*fgm->grid_dimension.int_z, cudaMemcpyHostToDevice);
	cufftExecC2R(plan_2d_many_c2r, d_P2d, d_fft_fft_P2d);
	cudaMemcpy(h_fft_fft_P2d, d_fft_fft_P2d, sizeof(float)*fgm->grid_numbers, cudaMemcpyDeviceToHost);

	float *h_rho = NULL;
	Malloc_Safely((void**)&h_rho, sizeof(float)*fgm->grid_numbers);
	cudaMemcpy(h_rho, fgm->rho, sizeof(float)*fgm->grid_numbers, cudaMemcpyDeviceToHost);
	FILE *out = fopen("..\\origin_rho.dat", "wb");
	fwrite(h_rho, sizeof(float), fgm->grid_numbers, out);
	fclose(out);

	for (int z =0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < fgm->grid_dimension.int_x ; x = x + 1)
			{
				int grid_serial = z*fgm->layer_numbers + y*fgm->grid_dimension.int_x + x;
				int grid_serial2 = y*fgm->grid_dimension.int_x + x;
				h_rho[grid_serial2] = h_rho[grid_serial2] - h_fft_fft_P2d[grid_serial] / fgm->grid_dimension.int_x / fgm->grid_dimension.int_y;
				//printf("%d %d %d %f %f\n", x, y, z, h_rho[grid_serial2], h_fft_fft_P2d[grid_serial]);
				//getchar();
			}
		}
	}

	out = fopen("..\\plane_rho.dat", "wb");
	fwrite(&h_rho[0], sizeof(float), fgm->layer_numbers, out);
	fclose(out);



	cudaMemcpy(fgm->rho,h_rho, sizeof(float)*fgm->grid_numbers, cudaMemcpyHostToDevice);

	cufftPlan3d(&plan_3d_r2c, fgm->grid_dimension.int_z, fgm->grid_dimension.int_y, fgm->grid_dimension.int_x, CUFFT_R2C);
	cufftPlan3d(&plan_3d_c2r, fgm->grid_dimension.int_z, fgm->grid_dimension.int_y, fgm->grid_dimension.int_x, CUFFT_C2R);
	Cuda_Malloc_Safely((void**)&d_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1));
	Malloc_Safely((void**)&h_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1));
	cufftExecR2C(plan_3d_r2c, fgm->rho, d_fft_rho);
	cudaMemcpy(h_fft_rho, d_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyDeviceToHost);
	for (int z = 0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < (fgm->grid_dimension.int_x / 2 + 1); x = x + 1)
			{
				int f_star_0_grid_serial = z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1) + y*(fgm->grid_dimension.int_x / 2 + 1) + x;
				int grid_serial = y*fgm->grid_dimension.int_x*fgm->grid_dimension.int_z + x*fgm->grid_dimension.int_z + z;
				/*printf("%d %d %d %f %f\n", x, y, z, h_fft_rho[f_star_0_grid_serial].x, h_fft_rho[f_star_0_grid_serial].y);
				printf("%d %d %d %f\n", x, y, z, 1./ 4. / CONSTANT_Pi / CONSTANT_Pi / (
					min(x, fgm->grid_dimension.int_x - x)*min(x, fgm->grid_dimension.int_x - x) / fgm->box_length.x / fgm->box_length.x
					+ min(y, fgm->grid_dimension.int_y - y)*min(y, fgm->grid_dimension.int_y - y) / fgm->box_length.y / fgm->box_length.y
					+ min(z, fgm->grid_dimension.int_z - z)*min(z, fgm->grid_dimension.int_z - z) / fgm->z_surface_length / fgm->z_surface_length
					));
				getchar();*/
				h_fft_rho[f_star_0_grid_serial].x = h_fft_rho[f_star_0_grid_serial].x*h_f_inverse[grid_serial] / fgm->grid_numbers;
				h_fft_rho[f_star_0_grid_serial].y = h_fft_rho[f_star_0_grid_serial].y*h_f_inverse[grid_serial] / fgm->grid_numbers;
				/*h_fft_rho[f_star_0_grid_serial].x = h_fft_rho[f_star_0_grid_serial].x / 4. / CONSTANT_Pi / CONSTANT_Pi / (
					min(x, fgm->grid_dimension.int_x - x)*min(x, fgm->grid_dimension.int_x - x) / fgm->box_length.x / fgm->box_length.x
					+ min(y, fgm->grid_dimension.int_y - y)*min(y, fgm->grid_dimension.int_y - y) / fgm->box_length.y / fgm->box_length.y
					+ min(z, fgm->grid_dimension.int_z - z)*min(z, fgm->grid_dimension.int_z - z) / fgm->z_surface_length / fgm->z_surface_length
					);
				h_fft_rho[f_star_0_grid_serial].y = h_fft_rho[f_star_0_grid_serial].y / 4. / CONSTANT_Pi / CONSTANT_Pi / (
					min(x, fgm->grid_dimension.int_x - x)*min(x, fgm->grid_dimension.int_x - x) / fgm->box_length.x / fgm->box_length.x
					+ min(y, fgm->grid_dimension.int_y - y)*min(y, fgm->grid_dimension.int_y - y) / fgm->box_length.y / fgm->box_length.y
					+ min(z, fgm->grid_dimension.int_z - z)*min(z, fgm->grid_dimension.int_z - z) / fgm->z_surface_length / fgm->z_surface_length
					);*/
			}
		}
	}

	cudaMemcpy(d_fft_rho,h_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyHostToDevice);
	
	cufftExecC2R(plan_3d_c2r,d_fft_rho,fgm->phi1);
	cudaMemcpy(fgm->h_phi, fgm->phi1, sizeof(float)*fgm->grid_numbers, cudaMemcpyDeviceToHost);

	for (int z = 1; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < fgm->grid_dimension.int_x; x = x + 1)
			{
				int grid_serial = z*fgm->layer_numbers + y*fgm->grid_dimension.int_x + x;
				//printf("%d %d %d %f\n", x, y, z, fgm->h_phi[grid_serial] / fgm->box_length.x / fgm->box_length.y/fgm->z_surface_length);
				//printf("%d %d %d %f\n", x, y, z, fgm->h_phi[grid_serial]);
				//getchar();
			}
		}
	}
	out = fopen("..\\phi.dat", "wb");
	fwrite(fgm->h_phi, sizeof(float), fgm->grid_numbers, out);
	fclose(out);

////////////////////////////EF/////////////////////////////////////////
	//20210528Ŀǰ���������ԣ������ַ�����õĵ糡���������
	//���Բ��ø���Ҷ�任�����޲�ֽ�ϵķ�ʽ����ģ��
	//����֤������temp���Եĵ��Ʒֲ��Ƿ���Ԥ�ڵ�
	//�����SOR�ĸ����ȶ���֮�����������Դ�ڸ��ֻ��ֲ���
	cufftExecR2C(plan_3d_r2c, fgm->rho, d_fft_rho);
	cudaMemcpy(h_fft_rho, d_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyDeviceToHost);
	for (int z = 0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < (fgm->grid_dimension.int_x / 2 + 1); x = x + 1)
			{
				int f_star_0_grid_serial = z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1) + y*(fgm->grid_dimension.int_x / 2 + 1) + x;
				int grid_serial = y*fgm->grid_dimension.int_x*fgm->grid_dimension.int_z + x*fgm->grid_dimension.int_z + z;

				float re = -2.*CONSTANT_Pi*min(x, fgm->grid_dimension.int_x - x) / fgm->box_length.x*h_fft_rho[f_star_0_grid_serial].y*h_f_inverse[grid_serial] / fgm->grid_numbers;
				float im = 2.*CONSTANT_Pi*min(x, fgm->grid_dimension.int_x - x) / fgm->box_length.x*h_fft_rho[f_star_0_grid_serial].x*h_f_inverse[grid_serial] / fgm->grid_numbers;
				h_fft_rho[f_star_0_grid_serial].x = re;
				h_fft_rho[f_star_0_grid_serial].y = im;

			}
		}
	}
	cudaMemcpy(d_fft_rho, h_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyHostToDevice);
	Cuda_Malloc_Safely((void**)&ef_x, sizeof(float)*fgm->grid_numbers);
	Cuda_Malloc_Safely((void**)&ef_y, sizeof(float)*fgm->grid_numbers);
	Cuda_Malloc_Safely((void**)&ef_z, sizeof(float)*fgm->grid_numbers);
	cufftExecC2R(plan_3d_c2r, d_fft_rho, ef_x);

	cufftExecR2C(plan_3d_r2c, fgm->rho, d_fft_rho);
	cudaMemcpy(h_fft_rho, d_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyDeviceToHost);
	for (int z = 0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < (fgm->grid_dimension.int_x / 2 + 1); x = x + 1)
			{
				int f_star_0_grid_serial = z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1) + y*(fgm->grid_dimension.int_x / 2 + 1) + x;
				int grid_serial = y*fgm->grid_dimension.int_x*fgm->grid_dimension.int_z + x*fgm->grid_dimension.int_z + z;

				float re = -2.*CONSTANT_Pi*min(y, fgm->grid_dimension.int_y - y) / fgm->box_length.y*h_fft_rho[f_star_0_grid_serial].y*h_f_inverse[grid_serial] / fgm->grid_numbers;
				float im = 2.*CONSTANT_Pi*min(y, fgm->grid_dimension.int_y - y) / fgm->box_length.y*h_fft_rho[f_star_0_grid_serial].x*h_f_inverse[grid_serial] / fgm->grid_numbers;
				h_fft_rho[f_star_0_grid_serial].x = re;
				h_fft_rho[f_star_0_grid_serial].y = im;

			}
		}
	}
	cudaMemcpy(d_fft_rho, h_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyHostToDevice);
	cufftExecC2R(plan_3d_c2r, d_fft_rho, ef_y);

	cufftExecR2C(plan_3d_r2c, fgm->rho, d_fft_rho);
	cudaMemcpy(h_fft_rho, d_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyDeviceToHost);
	for (int z = 0; z < fgm->grid_dimension.int_z; z = z + 1)
	{
		for (int y = 0; y < fgm->grid_dimension.int_y; y = y + 1)
		{
			for (int x = 0; x < (fgm->grid_dimension.int_x / 2 + 1); x = x + 1)
			{
				int f_star_0_grid_serial = z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1) + y*(fgm->grid_dimension.int_x / 2 + 1) + x;
				int grid_serial = y*fgm->grid_dimension.int_x*fgm->grid_dimension.int_z + x*fgm->grid_dimension.int_z + z;

				float re = -2.*CONSTANT_Pi*min(z,fgm->grid_dimension.int_z-z) / fgm->z_surface_length*h_fft_rho[f_star_0_grid_serial].y*h_f_inverse[grid_serial] / fgm->grid_numbers;
				float im = 2.*CONSTANT_Pi*min(z, fgm->grid_dimension.int_z - z) / fgm->z_surface_length*h_fft_rho[f_star_0_grid_serial].x*h_f_inverse[grid_serial] / fgm->grid_numbers;
				h_fft_rho[f_star_0_grid_serial].x = re;
				h_fft_rho[f_star_0_grid_serial].y = im;

			}
		}
	}
	cudaMemcpy(d_fft_rho, h_fft_rho, sizeof(cufftComplex)*fgm->grid_dimension.int_z*fgm->grid_dimension.int_y*(fgm->grid_dimension.int_x / 2 + 1), cudaMemcpyHostToDevice);
	cufftExecC2R(plan_3d_c2r, d_fft_rho, ef_z);
	temp20210528_cuda << <1, 256 >> >
		(fgm->grid_numbers, fgm->phi1, ef_x, ef_y, ef_z, fgm->electric_field_with_phi);


	Malloc_Safely((void**)&h_ef_phi, sizeof(float4)*fgm->grid_numbers);
	cudaMemcpy(h_ef_phi, fgm->electric_field_with_phi, sizeof(float4)*fgm->grid_numbers, cudaMemcpyDeviceToHost);
	cudaDeviceSynchronize();

	out = fopen("..\\ef_phi.dat", "wb");
	fwrite(h_ef_phi, sizeof(float4), fgm->grid_numbers, out);
	fclose(out);

	//getchar();
}
