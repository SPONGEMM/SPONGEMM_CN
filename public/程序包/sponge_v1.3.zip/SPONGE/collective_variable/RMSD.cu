#include "RMSD.cuh"

REGISTER_CV_STRUCTURE(CV_RMSD, "rmsd", 0);

static __global__ void get_center_of_atoms(int atom_numbers, int *atoms, VECTOR* crd, VECTOR *points)
{
    __shared__ VECTOR crd_sum[1024];
    crd_sum[threadIdx.x] = { 0, 0, 0 };
    VECTOR tempc;
    for (int i = threadIdx.x; i < atom_numbers; i += blockDim.x)
    {
        tempc = crd[atoms[i]];
        points[i] = tempc;
        crd_sum[threadIdx.x] = crd_sum[threadIdx.x] + tempc;
    }
    __syncthreads();
    for (int i = 512; i > 0; i >>= 1)
    {
        if (threadIdx.x < i)
        {
            crd_sum[threadIdx.x] = crd_sum[threadIdx.x] + crd_sum[i + threadIdx.x];
        }
        __syncthreads();
    }
    tempc = 1.0f / atom_numbers * crd_sum[0];
    for (int i = threadIdx.x; i < atom_numbers; i += blockDim.x)
    {
        points[i] = points[i] - tempc;
    }
}

//Reference: Eigenvalues and Eigenvectors for 3x3 Symmetric Matrices: An Analytical Approach
static __device__ __host__ __forceinline__ void get_single_eigen_vector(const float* m, const float eigen_value, float* eigen_vector)
{
    float b11 = m[0] - eigen_value;
#define b12 m[1]
#define b13 m[2]
    float b22 = m[3] - eigen_value;
#define b23 m[4]
    float b33 = m[5] - eigen_value;
    float Q, P, n;
    if (fabsf(b12 * b12 - b11 * b22) > 1e-6 && fabsf(b13) > 1e-6f)
    {
        Q = (b11 * b23 - b13 * b12) / (b12 * b12 - b11 * b22);
        P = -(b23 * Q + b33) / b13;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = Q * n;
        eigen_vector[2] = n;
    }
    else if (fabsf(b12 * b13 - b11 * b23) > 1e-6 && fabsf(b12) > 1e-6f)
    {
        Q = (b11 * b33 - b13 * b13) / (b12 * b13 - b11 * b23);
        P = -(b22 * Q + b23) / b12;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = Q * n;
        eigen_vector[2] = n;
    }
    else if (fabsf(b22 * b13 - b12 * b23) > 1e-6 && fabsf(b11) > 1e-6f)
    {
        Q = (b12 * b33 - b23 * b13) / (b22 * b13 - b12 * b23);
        P = -(b12 * Q + b13) / b11;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = Q * n;
        eigen_vector[2] = n;
    }
    else if (fabsf(b11 * b22 - b12 * b12) > 1e-6 && fabsf(b23) > 1e-6f)
    {
        P = (b12 * b23 - b13 * b22) / (b11 * b22 - b12 * b12);
        Q = -(b13 * P + b33) / b23;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = Q * n;
        eigen_vector[2] = n;
    }
    else if (fabsf(b11 * b23 - b12 * b13) > 1e-6 && fabsf(b22) > 1e-6f)
    {
        P = (b12 * b33 - b13 * b23) / (b11 * b23 - b12 * b13);
        Q = -(b12 * P + b23) / b22;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = Q * n;
        eigen_vector[2] = n;
    }
    else if (fabsf(b12 * b23 - b22 * b13) > 1e-6 && fabsf(b12) > 1e-6f)
    {
        P = (b22 * b33 - b23 * b23) / (b12 * b23 - b22 * b13);
        Q = -(b11 * P + b13) / b12;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = Q * n;
        eigen_vector[2] = n;
    }
    else if (fabsf(b11 * b23 - b13 * b12) > 1e-6 && fabsf(b33) > 1e-6f)
    {
        P = (b13 * b22 - b12 * b23) / (b11 * b23 - b13 * b12);
        Q = -(b13 * P + b23) / b33;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = n;
        eigen_vector[2] = Q * n;
    }
    else if (fabsf(b11 * b33 - b13 * b13) > 1e-6 && fabsf(b23) > 1e-6f)
    {
        P = (b13 * b23 - b12 * b33) / (b11 * b33 - b13 * b13);
        Q = -(b12 * P + b22) / b23;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = n;
        eigen_vector[2] = Q * n;
    }
    else
    {
        P = (b23 * b23 - b22 * b33) / (b12 * b33 - b23 * b13);
        Q = -(b11 * P + b12) / b13;
        n = 1.0f / sqrtf(P * P + Q * Q + 1);
        eigen_vector[0] = P * n;
        eigen_vector[1] = n;
        eigen_vector[2] = Q * n;
    }
#undef b12
#undef b13
#undef b23
}


//Reference: 1. Eigenvalues and Eigenvectors for 3x3 Symmetric Matrices: An Analytical Approach
//Reference: 2. github: svd_3x3_cuda
static __device__ __host__ __forceinline__ void get_eigen(const float* m, float *eigen_values, float *eigen_vector)
{
    float t1, t2;
    if (m[1] == 0 && m[2] == 0 && m[4] == 0)
    {
        eigen_values[0] = m[0];
        eigen_values[1] = m[3];
        eigen_values[2] = m[5];
        eigen_vector[0] = 1;
        eigen_vector[1] = 0;
        eigen_vector[2] = 0;
        eigen_vector[3] = 0;
        eigen_vector[4] = 1;
        eigen_vector[5] = 0;
    }
    else if (m[1] == 0 && m[2] == 0)
    {
        t1 = m[3] - m[5];
        t1 = sqrtf(t1 * t1 / 4 + m[4] * m[4]);
        t2 = (m[3] + m[5]) / 2;
        eigen_values[0] = m[0];
        eigen_values[1] = t2 + t1;
        eigen_values[2] = t2 - t1;
        eigen_vector[0] = 1;
        eigen_vector[1] = 0;
        eigen_vector[2] = 0;
        t1 = m[3] - eigen_values[2];
        t1 = sqrtf(t1 * t1 + m[4] * m[4]);
        eigen_vector[3] = 0;
        eigen_vector[4] = -m[4] / t1;
        eigen_vector[5] = (m[3] - eigen_values[2]) / t1;
    }
    else if (m[1] == 0 && m[4] == 0)
    {
        t1 = m[0] - m[5];
        t1 = sqrtf(t1 * t1 / 4 + m[2] * m[2]);
        t2 = (m[0] + m[5]) / 2;
        eigen_values[0] = t2 + t1;
        eigen_values[1] = m[3];
        eigen_values[2] = t2 - t1;

        eigen_vector[3] = 0;
        eigen_vector[4] = 1;
        eigen_vector[5] = 0;
        t1 = m[0] - eigen_values[0];
        t1 = sqrtf(t1 * t1 + m[2] * m[2]);
        eigen_vector[0] = -m[2] / t1;
        eigen_vector[1] = 0;
        eigen_vector[2] = (m[0] - eigen_values[0]) / t1;
    }
    else if (m[2] == 0 && m[4] == 0)
    {
        t1 = m[3] - m[0];
        t1 = sqrtf(t1 * t1 / 4 + m[1] * m[1]);
        t2 = (m[3] + m[0]) / 2;
        eigen_values[0] = t2 + t1;
        eigen_values[1] = t2 - t1;
        eigen_values[2] = m[5];
        t1 = m[0] - eigen_values[0];
        t1 = sqrtf(t1 * t1 + m[1] * m[1]);
        eigen_vector[0] = -m[1] / t1;
        eigen_vector[1] = (m[0] - eigen_values[0]) / t1;
        eigen_vector[2] = 0;
        eigen_vector[3] = -(m[0] - eigen_values[0]) / t1;
        eigen_vector[4] = -m[1] / t1;
        eigen_vector[5] = 0;
    }
    else
    {
        float m_ = 1.0f / 3.0f * (m[0] + m[3] + m[5]);
        float a11 = m[0] - m_;
        float a22 = m[3] - m_;
        float a33 = m[5] - m_;
        float a12_sqr = m[1] * m[1];
        float a13_sqr = m[2] * m[2];
        float a23_sqr = m[4] * m[4];
        float p = 1.0f / 6.0f * (a11 * a11 + a22 * a22 + a33 * a33 + 2 * (a12_sqr + a13_sqr + a23_sqr));
        float q = 0.5f * (a11 * (a22 * a33 - a23_sqr) - a22 * a13_sqr - a33 * a12_sqr) + m[1] * m[2] * m[4];
        float sqrt_p = sqrtf(p);
        float disc = p * p * p - q * q;
        float phi = 1.0f / 3.0f * atan2f(sqrtf(fmaxf(0.0f, disc)), q);
        float c = cosf(phi);
        float s = sinf(phi);
        float sqrt_p_cos = sqrt_p * c;
        float root_three_sqrt_p_sin = sqrtf(3.0f) * sqrt_p * s;
        eigen_values[0] = m_ + 2.0f * sqrt_p;
        eigen_values[1] = m_ - sqrt_p_cos - root_three_sqrt_p_sin;
        eigen_values[2] = m_ - sqrt_p_cos + root_three_sqrt_p_sin;
        get_single_eigen_vector(m, eigen_values[0], eigen_vector);
        get_single_eigen_vector(m, eigen_values[1], eigen_vector + 3);
    }
    eigen_vector[6] = eigen_vector[2] * eigen_vector[4] - eigen_vector[1] * eigen_vector[5];
    eigen_vector[7] = eigen_vector[0] * eigen_vector[5] - eigen_vector[2] * eigen_vector[3];
    eigen_vector[8] = eigen_vector[1] * eigen_vector[3] - eigen_vector[0] * eigen_vector[4];
    if (eigen_values[0] < eigen_values[1])
    {
        t1 = eigen_values[0];
        eigen_values[0] = eigen_values[1];
        eigen_values[1] = t1;
        t1 = eigen_vector[0];
        eigen_vector[0] = eigen_vector[3];
        eigen_vector[3] = t1;
        t1 = eigen_vector[1];
        eigen_vector[1] = eigen_vector[4];
        eigen_vector[4] = t1;
        t1 = eigen_vector[2];
        eigen_vector[2] = eigen_vector[5];
        eigen_vector[5] = t1;
    }
    if (eigen_values[0] < eigen_values[2])
    {
        t1 = eigen_values[0];
        eigen_values[0] = eigen_values[2];
        eigen_values[2] = t1;
        t1 = eigen_vector[0];
        eigen_vector[0] = eigen_vector[6];
        eigen_vector[6] = t1;
        t1 = eigen_vector[1];
        eigen_vector[1] = eigen_vector[7];
        eigen_vector[7] = t1;
        t1 = eigen_vector[2];
        eigen_vector[2] = eigen_vector[8];
        eigen_vector[8] = t1;
    }
    if (eigen_values[1] < eigen_values[2])
    {
        t1 = eigen_values[1];
        eigen_values[1] = eigen_values[2];
        eigen_values[2] = t1;
        t1 = eigen_vector[3];
        eigen_vector[3] = eigen_vector[6];
        eigen_vector[6] = t1;
        t1 = eigen_vector[4];
        eigen_vector[4] = eigen_vector[7];
        eigen_vector[7] = t1;
        t1 = eigen_vector[5];
        eigen_vector[5] = eigen_vector[8];
        eigen_vector[8] = t1;
    }
}

static __global__ void get_Rotation_matrix(float *m, float *R)
{
    __shared__ float mDmT[6], UT[9], S[3], VT[9];
    //float determinant =  m[0] * m[4] * m[8] + m[1] * m[5] * m[6] + m[2] * m[3] * m[7]
    //                     - m[0] * m[5] * m[7] - m[1] * m[3] * m[8] - m[2] * m[4] * m[6];
    //determinant = copysignf(1, determinant);
    float norm_factor = fabsf(m[2] * m[0] + m[5] * m[3] + m[8] * m[6]);
    norm_factor = 1.0F / sqrtf(norm_factor);
    for (int i = 0; i < 9; i++)
    {
        m[i] *= norm_factor;
    }
    mDmT[0] = (m[0] * m[0] + m[3] * m[3] + m[6] * m[6]);
    mDmT[1] = (m[1] * m[0] + m[4] * m[3] + m[7] * m[6]);
    mDmT[2] = (m[2] * m[0] + m[5] * m[3] + m[8] * m[6]);
    mDmT[3] = (m[1] * m[1] + m[4] * m[4] + m[7] * m[7]);
    mDmT[4] = (m[2] * m[1] + m[5] * m[4] + m[8] * m[7]);
    mDmT[5] = (m[2] * m[2] + m[5] * m[5] + m[8] * m[8]);
    get_eigen(mDmT, S, VT);

    UT[0] = (m[0] * VT[0] + m[1] * VT[1] + m[2] * VT[2]);
    UT[1] = (m[3] * VT[0] + m[4] * VT[1] + m[5] * VT[2]);
    UT[2] = (m[6] * VT[0] + m[7] * VT[1] + m[8] * VT[2]);
    norm_factor = rnorm3df(UT[0], UT[1], UT[2]);
    UT[0] *= norm_factor;
    UT[1] *= norm_factor;
    UT[2] *= norm_factor;

    UT[3] = (m[0] * VT[3] + m[1] * VT[4] + m[2] * VT[5]);
    UT[4] = (m[3] * VT[3] + m[4] * VT[4] + m[5] * VT[5]);
    UT[5] = (m[6] * VT[3] + m[7] * VT[4] + m[8] * VT[5]);
    norm_factor = rnorm3df(UT[3], UT[4], UT[5]);
    UT[3] *= norm_factor;
    UT[4] *= norm_factor;
    UT[5] *= norm_factor;

    UT[6] = UT[1] * UT[5] - UT[2] * UT[4];
    UT[7] = UT[2] * UT[3] - UT[0] * UT[5];
    UT[8] = UT[0] * UT[4] - UT[1] * UT[3];

    R[0] = UT[0] * VT[0] + UT[3] * VT[3] + UT[6] * VT[6];
    R[3] = UT[0] * VT[1] + UT[3] * VT[4] + UT[6] * VT[7];
    R[6] = UT[0] * VT[2] + UT[3] * VT[5] + UT[6] * VT[8];
    R[1] = UT[1] * VT[0] + UT[4] * VT[3] + UT[7] * VT[6];
    R[4] = UT[1] * VT[1] + UT[4] * VT[4] + UT[7] * VT[7];
    R[7] = UT[1] * VT[2] + UT[4] * VT[5] + UT[7] * VT[8];
    R[2] = UT[2] * VT[0] + UT[5] * VT[3] + UT[8] * VT[6];
    R[5] = UT[2] * VT[1] + UT[5] * VT[4] + UT[8] * VT[7];
    R[8] = UT[2] * VT[2] + UT[5] * VT[5] + UT[8] * VT[8];
}

static __global__ void get_diff_and_rmsd(int atom_numbers, const VECTOR* points, const VECTOR* rotated_reference, 
    float *d_value, int *atom, VECTOR *crd_grads, VECTOR *box_grads, VECTOR box_length)
{
    __shared__ float rmsd[1024];
    rmsd[threadIdx.x] = 0;
    __shared__ VECTOR drmsd_dx[1024];
    drmsd_dx[threadIdx.x] = { 0, 0, 0 };
    VECTOR diff;
    float rmsd0;
    int atom_i;
    for (int i = threadIdx.x; i < atom_numbers; i += 1024)
    {
        diff = points[i] - rotated_reference[i];
        rmsd[threadIdx.x] += diff.x * diff.x + diff.y * diff.y + diff.z * diff.z;
    }
    __syncthreads();
    for (int i = 512; i > 0; i >>= 1)
    {
        if (threadIdx.x < i)
        {
            rmsd[threadIdx.x] += rmsd[i + threadIdx.x];
        }
        __syncthreads();
    }
    rmsd0 = sqrtf(rmsd[0] / atom_numbers);
    *d_value = rmsd0;
    __syncthreads();
    rmsd0 *= atom_numbers;
    for (int i = threadIdx.x; i < atom_numbers; i += 1024)
    {
        atom_i = atom[i];
        diff = points[i] - rotated_reference[i];
        diff.x /= rmsd0;
        diff.y /= rmsd0;
        diff.z /= rmsd0;
        drmsd_dx[threadIdx.x].x += diff.x * points[i].x / box_length.x;
        drmsd_dx[threadIdx.x].y += diff.y * points[i].y / box_length.y;
        drmsd_dx[threadIdx.x].z += diff.z * points[i].z / box_length.z;
        crd_grads[atom_i] = diff;
    }
    __syncthreads();
    for (int i = 512; i > 0; i >>= 1)
    {
        if (threadIdx.x < i)
        {
            drmsd_dx[threadIdx.x] = drmsd_dx[threadIdx.x] + drmsd_dx[i + threadIdx.x];
        }
        __syncthreads();
    }
    box_grads[0] = drmsd_dx[0];
}

void CV_RMSD::Initial(COLLECTIVE_VARIABLE_CONTROLLER* manager, int atom_numbers, const char* module_name)
{
    std::vector<int> cpu_atom = manager->Ask_For_Indefinite_Length_Int_Parameter(module_name, "atom");
    if (cpu_atom.size() == 0)
    {
        std::string error_reason = "Reason:\n\tatoms are required for the CV ";
        error_reason += module_name;
        error_reason += " (atom or atom_in_file)\n";
        manager->Throw_SPONGE_Error(spongeErrorMissingCommand, "CV_RMSD::Initial", error_reason.c_str());
    }
    this->atom_numbers = cpu_atom.size();
    manager->printf("        atom_numbers is %d\n", this->atom_numbers);
    std::vector<float> cpu_reference = manager->Ask_For_Indefinite_Length_Float_Parameter(module_name, "coordinate");
    if (cpu_reference.size() == 0)
    {
        std::string error_reason = "Reason:\n\tcoordinates are required for the CV ";
        error_reason += module_name;
        error_reason += " (coordinate or coordinate_in_file)\n";
        manager->Throw_SPONGE_Error(spongeErrorMissingCommand, "CV_RMSD::Initial", error_reason.c_str());
    }
    if (3 * this->atom_numbers != cpu_reference.size())
    {
        std::string error_reason = "Reason:\n\tthe number of coordinates (";
        error_reason += cpu_reference.size();
        error_reason += ") != 3 * the number of atoms (";
        error_reason += this->atom_numbers;
        error_reason += ")for the CV ";
        error_reason += module_name;
        error_reason += "\n";
        manager->Throw_SPONGE_Error(spongeErrorConflictingCommand, "CV_RMSD::Initial", error_reason.c_str());
    }
    Cuda_Malloc_And_Copy_Safely((void**)&atom, &cpu_atom[0], sizeof(int) * this->atom_numbers);
    Cuda_Malloc_Safely((void**)&points, sizeof(VECTOR) * this->atom_numbers);
    Cuda_Malloc_Safely((void**)&temp_matrix, sizeof(float) * 9);
    Cuda_Malloc_Safely((void**)&rotated_ref, sizeof(VECTOR) * this->atom_numbers);
    Cuda_Malloc_Safely((void**)&R, sizeof(float) * 9);
    VECTOR center = {0, 0, 0};
    for (int i = 0; i < 3 * this->atom_numbers; i += 3)
    {
        center.x += cpu_reference[i];
        center.y += cpu_reference[i + 1];
        center.z += cpu_reference[i + 2];
    }
    center = 1.0f / this->atom_numbers * center;
    for (int i = 0; i < 3 * this->atom_numbers; i += 3)
    {
        cpu_reference[i] -= center.x;
        cpu_reference[i + 1] -= center.y;
        cpu_reference[i + 2] -= center.z;
    }
    Cuda_Malloc_And_Copy_Safely((void**)&references, &cpu_reference[0], sizeof(VECTOR) * this->atom_numbers);
    handle = NULL;
    cublasCreate(&handle);
    if (handle == NULL)
    {
        manager->Throw_SPONGE_Error(spongeErrorMallocFailed, "CV_RMSD::Initial", "Reason:\n\tFail to create the cublas handle\n");
    }
    Super_Initial(manager, atom_numbers, module_name);
}

void CV_RMSD::Compute(int atom_numbers, UNSIGNED_INT_VECTOR* uint_crd, VECTOR scaler, VECTOR* crd, VECTOR box_length, int need, int step)
{
    need = Check_Whether_Computed_At_This_Step(step, need);
    if (need)
    {
        const float one = 1;
        const float beta = 0.0f;

        get_center_of_atoms << <1, 1024 >> >(this->atom_numbers, this->atom, crd, this->points);

        cublasSgemm(this->handle, CUBLAS_OP_N, CUBLAS_OP_T, 3, 3, this->atom_numbers,
            &one, (float*)this->references, 3, (float*)this->points, 3, &beta, temp_matrix, 3);

        get_Rotation_matrix << <1, 1 >> >(temp_matrix, R);

        cublasSgemm(this->handle, CUBLAS_OP_N, CUBLAS_OP_N, 3, this->atom_numbers, 3,
            &one, this->R, 3, (float*)this->references, 3, &beta, (float*)rotated_ref, 3);

        get_diff_and_rmsd << <1, 1024 >> >(this->atom_numbers, this->points, this->rotated_ref, d_value, atom, crd_grads, box_grads, box_length);
        cudaMemcpy(&value, d_value, sizeof(float), cudaMemcpyDeviceToHost);
    }
    Record_Update_Step_Of_Fast_Computing_CV(step, need);
}
