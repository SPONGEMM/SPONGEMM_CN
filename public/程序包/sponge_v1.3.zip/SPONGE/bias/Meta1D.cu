#include "Meta1D.cuh"

static float BSpline_Interpolation_4(int i, float x)// in fact need 1.-x
{
    if (i == -1)
    {
        return 1. / 6.*x*x*x;
    }
    else if (i == 0)
    {
        return -0.5*x*x*x + 0.5*x*x + 0.5*x + 1. / 6.;
    }
    else if (i == 1)
    {
        return 0.5*x*x*x - x*x + 2. / 3.;
    }
    else if (i == 2)
    {
        return -1. / 6.*x*x*x + 0.5*x*x - 0.5*x + 1. / 6.;
    }
    else
    {
        extern CONTROLLER controller;
        controller.Throw_SPONGE_Error(spongeErrorOverflow, "BSpline_Interpolation_4", "Reason:\n\tThe input of the BSpline overflowed\n");
        return 0.;
    }
}

static float DBSpline_Interpolation_4(int i, float x)// in fact need 1.-x, and is -D
{
    if (i == -1)
    {
        return 3. / 6.*x*x;
    }
    else if (i == 0)
    {
        return -0.5*3.*x*x + 0.5*2.*x + 0.5;
    }
    else if (i == 1)
    {
        return 0.5*3.*x*x - 2.*x;
    }
    else if (i == 2)
    {
        return -3. / 6.*x*x + 0.5*2.*x - 0.5;
    }
    else
    {
        extern CONTROLLER controller;
        controller.Throw_SPONGE_Error(spongeErrorOverflow, "BSpline_Interpolation_4", "Reason:\n\tThe input of the BSpline overflowed\n");
        return 0.;
    }
}

void META1D::Initial(CONTROLLER *controller, COLLECTIVE_VARIABLE_CONTROLLER *cv_controller, char * module_name)
{
    if (module_name == NULL)
    {
        strcpy(this->module_name, "meta1d");
    }
    else
    {
        strcpy(this->module_name, module_name);
    }
    if (!cv_controller->Command_Exist(this->module_name, "CV"))
    {
        controller->printf("META1D IS NOT INITIALIZED\n\n");
        return;
    }
    controller->printf("START INITIALIZING META1D:\n");
    cv = cv_controller->Ask_For_CV(this->module_name, 1)[0];

    sprintf(read_potential_file_name, "meta1d_potential.txt");
    sprintf(write_potential_file_name, "meta1d_potential.txt");

    cv_period = 0;
    if (cv_controller->Command_Exist(this->module_name, "CV_period"))
    {
        cv_controller->Check_Float(this->module_name, "CV_period", "META1D::Initial");
        cv_period = atof(cv_controller->Command(this->module_name, "CV_period"));
    }

    if (is_str_equal(controller->Command("mode"), "npt") && 
        !(cv_controller->Command_Exist(this->module_name, "ignore_virial")
            && cv_controller->Get_Bool(this->module_name, "ignore_virial", "META1D::Initial")))
    {
        std::string error_reason = "Reason:\n\tthe process of virial is not implemented for META1D. Set ";
        error_reason += this->module_name;
        error_reason += "_ignore_virial = 1 to ignore this error\n";
        controller->Throw_SPONGE_Error(spongeErrorNotImplemented, "META1D::Initial", error_reason.c_str());
    }

    if (cv_controller->Command_Exist(this->module_name, "potential_in_file"))
    {
        int read_ret = sscanf(cv_controller->Command(this->module_name, "potential_in_file"), "%s", read_potential_file_name);
        controller->printf("    START READING POTENTIAL FILE: %s\n", read_potential_file_name);
        Read_Potential();
    }
    else
    {
        int check_necessary_inpu_exist = 0;
        if (cv_controller->Command_Exist(this->module_name, "CV_minimal"))
        {
            cv_controller->Check_Float(this->module_name, "CV_minimal", "META1D::Initial");
            cv_min = atof(cv_controller->Command(this->module_name, "CV_minimal"));
            check_necessary_inpu_exist += 1;
        }
        if (cv_controller->Command_Exist(this->module_name, "CV_maximum"))
        {
            cv_controller->Check_Float(this->module_name, "CV_maximum", "META1D::Initial");
            cv_max = atof(cv_controller->Command(this->module_name, "CV_maximum"));
            check_necessary_inpu_exist += 1;
        }
        dcv = 0.01;
        if (cv_controller->Command_Exist(this->module_name, "dCV"))
        {
            cv_controller->Check_Float(this->module_name, "dCV", "META1D::Initial");
            dcv = atof(cv_controller->Command(this->module_name, "dCV"));
        }
        if ((float)(cv_max - cv_min) / dcv < 1.0)
        {
            check_necessary_inpu_exist = -1;
        }
        if (check_necessary_inpu_exist != 2)
        {
            char error_reason[CHAR_LENGTH_MAX];
            sprintf(error_reason, "Reason:\n\tthe required inputs are not complete or incorrect \
(potential_in_file or (CV_minimal, CV_maximum))\n");
            controller->Throw_SPONGE_Error(spongeErrorMissingCommand, "META1D::Initial", error_reason);
        }

        grid_numbers = (float)(cv_max - cv_min) / dcv + 1.;
        dcv = (float)(cv_max - cv_min) / (grid_numbers - 1);

        Malloc_Safely((void**)&potential_list, sizeof(float)*grid_numbers);
        for (int i = 0; i < grid_numbers; i = i + 1)
        {
            potential_list[i] = 0;
        }
    }
    if (cv_controller->Command_Exist(this->module_name, "height"))
    {
        cv_controller->Check_Float(this->module_name, "height", "META1D::Initial");
        height = atof(cv_controller->Command(this->module_name, "height"));
    }
    if (cv_controller->Command_Exist(this->module_name, "sigma"))
    {
        cv_controller->Check_Float(this->module_name, "sigma", "META1D::Initial");
        sigma = atof(cv_controller->Command(this->module_name, "sigma"));
    }
    if (cv_controller->Command_Exist(this->module_name, "wall_height"))
    {
        cv_controller->Check_Float(this->module_name, "wall_height", "META1D::Initial");
        border_potential_height = atof(cv_controller->Command(this->module_name, "wall_height"));
    }
    if (cv_controller->Command_Exist(this->module_name, "welltemp_factor"))
    {
        cv_controller->Check_Float(this->module_name, "welltemp_factor", "META1D::Initial");
        welltemp_factor = atof(cv_controller->Command(this->module_name, "welltemp_factor"));
    }
    if (cv_controller->Command_Exist(this->module_name, "potential_out_file"))
    {
        int retval = sscanf(cv_controller->Command(this->module_name, "potential_out_file"), "%s", write_potential_file_name);
    }
    if (cv_controller->Command_Exist(this->module_name, "potential_update_interval"))
    {
        cv_controller->Check_Int(this->module_name, "potential_update_interval", "META1D::Initial");
        potential_update_interval = atoi(cv_controller->Command(this->module_name, "potential_update_interval"));
    }
    else
    {
        controller->printf("    Potential update interval is set to write_information_interval by default\n");
        if (controller->Command_Exist("write_information_interval"))
        {
            potential_update_interval = atoi(controller->Command("write_information_interval"));
        }
        else
        {
            potential_update_interval = 1000;
        }
    }
    controller->Step_Print_Initial("meta1d", "%.2f");

    controller->printf("    potential update interval: %d\n", potential_update_interval);
    controller->printf("    CV minimal: %f\n", cv_min);
    controller->printf("    CV maximum: %f\n", cv_max);
    controller->printf("    dCV: %f\n", dcv);
    controller->printf("    bias height: %f\n", height);
    controller->printf("    bias sigma: %f\n", sigma);
    controller->printf("    bondary height: %f\n", border_potential_height);
    controller->printf("    welltemp factor: %f\n", welltemp_factor);
    controller->printf("    potential output file: %s\n", write_potential_file_name);
    is_initialized = 1;
    controller->printf("END INITIALIZING META1D\n\n");
}

void META1D::Write_Potential()
{
    if (!is_initialized)
    {
        return;
    }
    FILE *temp_file = NULL;
    Open_File_Safely(&temp_file, write_potential_file_name, "w");
    fprintf(temp_file, "system name and description\n");
    fprintf(temp_file, "%f %f %f\n",cv_min,cv_max,dcv);
    fprintf(temp_file, "%d\n", grid_numbers);
    for (int i = 0; i < grid_numbers; i = i + 1)
    {
        fprintf(temp_file, "%f %f\n", (float)dcv*i + cv_min, potential_list[i]);
    }
    fclose(temp_file);
}

void META1D::Read_Potential()
{
    if (!is_initialized)
    {
        return;
    }
    FILE *temp_file = NULL;
    Open_File_Safely(&temp_file, read_potential_file_name, "r");
    char temp_char[256];
    char* get_val = fgets(temp_char, 256, temp_file);
    int scanf_ret = fscanf(temp_file, "%f %f %f\n", &cv_min, &cv_max, &dcv);
    scanf_ret = fscanf(temp_file, "%d\n", &grid_numbers);
    Malloc_Safely((void**)&potential_list, sizeof(float)*grid_numbers);
    float temp_float;
    for (int i = 0; i < grid_numbers; i = i + 1)
    {
        scanf_ret = fscanf(temp_file, "%f %f\n", &temp_float, &potential_list[i]);
    }
    fclose(temp_file);
}

static __global__ void Add_Frc(const int atom_numbers, VECTOR *frc, VECTOR *cv_grad, float dheight_dcv)
{
    for (int i = blockIdx.x + blockDim.x * threadIdx.x; i < atom_numbers; i += gridDim.x * blockDim.x)
    {
        frc[i] = frc[i] - dheight_dcv * cv_grad[i];
    }
}

void META1D::Meta_Force(int atom_numbers, VECTOR *frc)
{
    if (!is_initialized)
    {
        return;
    }
    Add_Frc << <20, 256 >> >(atom_numbers, frc, cv->crd_grads, -DPotential(cv->value) / dcv);
}

float META1D::Potential(float x)
{
    if (!is_initialized)
    {
        return NAN;
    }
    float temp_pos = (float)(x - cv_min) / dcv;
    int pos = (float)temp_pos;
        if (pos >= 1 && pos <= grid_numbers - 3)
    {
        float scale = 1. - temp_pos + (float)pos;
        return BSpline_Interpolation_4(-1, scale)*potential_list[pos - 1]
            + BSpline_Interpolation_4(0, scale)*potential_list[pos]
            + BSpline_Interpolation_4(1, scale)*potential_list[pos + 1]
            + BSpline_Interpolation_4(2, scale)*potential_list[pos + 2];
    }
    else if (pos == 0)
    {
        float scale = 1. - temp_pos + (float)pos;
        return BSpline_Interpolation_4(-1, scale)*border_potential_height
            + BSpline_Interpolation_4(0, scale)*potential_list[0]
            + BSpline_Interpolation_4(1, scale)*potential_list[1]
            + BSpline_Interpolation_4(2, scale)*potential_list[2];
    }
    else if (pos == grid_numbers - 2)
    {
        float scale = 1. - temp_pos + (float)pos;
        return BSpline_Interpolation_4(-1, scale)*potential_list[grid_numbers - 3]
            + BSpline_Interpolation_4(0, scale)*potential_list[grid_numbers - 2]
            + BSpline_Interpolation_4(1, scale)*potential_list[grid_numbers - 1]
            + BSpline_Interpolation_4(2, scale)*border_potential_height;
    }
    else
    {
        printf("POTENTIAL::Potential Warning: Input of x=%f out of range!\n", x);
        return 0.;
    }
}

float META1D::DPotential(float x)
{
    if (!is_initialized)
    {
        return NAN;
    }
    float temp_pos = (float)(x - cv_min) / dcv;
    int pos = (float)temp_pos;
    if (pos >= 1 && pos <= grid_numbers - 3)
    {
        float scale = 1. - temp_pos + (float)pos;
        return DBSpline_Interpolation_4(-1, scale)*potential_list[pos - 1]
            + DBSpline_Interpolation_4(0, scale)*potential_list[pos]
            + DBSpline_Interpolation_4(1, scale)*potential_list[pos + 1]
            + DBSpline_Interpolation_4(2, scale)*potential_list[pos + 2];
    }
    else if (pos == 0)
    {
        float scale = 1. - temp_pos + (float)pos;
        return DBSpline_Interpolation_4(-1, scale)*border_potential_height
            + DBSpline_Interpolation_4(0, scale)*potential_list[0]
            + DBSpline_Interpolation_4(1, scale)*potential_list[1]
            + DBSpline_Interpolation_4(2, scale)*potential_list[2];
    }
    else if (pos == grid_numbers - 2)
    {
        float scale = 1. - temp_pos + (float)pos;
        return DBSpline_Interpolation_4(-1, scale)*potential_list[grid_numbers - 3]
            + DBSpline_Interpolation_4(0, scale)*potential_list[grid_numbers - 2]
            + DBSpline_Interpolation_4(1, scale)*potential_list[grid_numbers - 1]
            + DBSpline_Interpolation_4(2, scale)*border_potential_height;
    }
    else
    {
        printf("POTENTIAL::Potential Warning: Input of x=%f out of range!\n", x);
        return 0.;
    }
}

void META1D::AddPotential(int steps)
{
    if (!is_initialized)
    {
        return;
    }
    if (steps % potential_update_interval == 0)
    {
        for (int i = 0; i < grid_numbers; i = i + 1)
        {
            float pos = (float)i*dcv + cv_min;
            float delta_cv = pos - cv->value;
            if (cv_period > 0)
            {
                delta_cv -= floorf(delta_cv / cv_period + 0.5) * cv_period;
            }
            float add = height *1. / sqrtf(2.*3.141592654) / sigma * expf(-delta_cv * delta_cv / 2. / sigma / sigma);
            potential_list[i] = potential_list[i] + add * expf(-potential_list[i] / welltemp_factor);
        }
    }
}
