﻿#include "exforce.cuh"

static __global__ void Exforce_Get_r_CUDA(const int exforce_numbers, const UNSIGNED_INT_VECTOR* uint_crd, const VECTOR scaler, const int* atom_a, const int* atom_b, float 
*exforce_r)
{
	int exforce_i = blockDim.x * blockIdx.x + threadIdx.x;
	if (exforce_i < exforce_numbers)
	{
		int atom_i = atom_a[exforce_i];
		int atom_j = atom_b[exforce_i];
		VECTOR dr = Get_Periodic_Displacement(uint_crd[atom_i], uint_crd[atom_j], scaler);
		float r0 = norm3df(dr.x, dr.y, dr.z);
		atomicAdd(&exforce_r[exforce_i], r0);
	}
}

static __global__ void Exforce_Force_With_Atom_Energy_And_Virial_CUDA(const int exforce_numbers, const UNSIGNED_INT_VECTOR* uint_crd, const VECTOR scaler, const int* atom_a, const int* atom_b, const float 
*exforce_r, const float* ex_exfrc ,VECTOR* frc, float *atom_energy, float *atom_virial)
{
	int exforce_i = blockDim.x * blockIdx.x + threadIdx.x;
	if (exforce_i < exforce_numbers)
	{
		int atom_i = atom_a[exforce_i];
		int atom_j = atom_b[exforce_i];

		float r0=exforce_r[exforce_i];
		VECTOR dr = Get_Periodic_Displacement(uint_crd[atom_i], uint_crd[atom_j], scaler);
		float abs_r = norm3df(dr.x, dr.y, dr.z);
		float r_1 = 1. / abs_r;

		VECTOR exfrc = r_1*ex_exfrc[exforce_i]*dr;

		//float exfrc_y = ex_exfrc_y[exforce_i];
		//float exfrc_z = ex_exfrc_z[exforce_i];

		atomicAdd(&frc[atom_i].x, exfrc.x);
		atomicAdd(&frc[atom_i].y, exfrc.y);
		atomicAdd(&frc[atom_i].z, exfrc.z);
		
		atomicAdd(&frc[atom_j].x, -exfrc.x);
		atomicAdd(&frc[atom_j].y, -exfrc.y);
		atomicAdd(&frc[atom_j].z, -exfrc.z);

		atomicAdd(&atom_virial[atom_i], norm3df(exfrc.x, exfrc.y, exfrc.z) * abs_r);
		atomicAdd(&atom_energy[atom_i], ex_exfrc[exforce_i]*(abs_r-r0));
	}
}

static __global__ void Exforce_Energy_CUDA(const int exforce_numbers, const UNSIGNED_INT_VECTOR *uint_crd, const VECTOR scaler,
	const int *atom_a, const int *atom_b, const float *exforce_r, const float *ex_exfrc, float *exfrc_ene)
{
	int exforce_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (exforce_i < exforce_numbers)
	{
		int atom_i = atom_a[exforce_i];
		int atom_j = atom_b[exforce_i];

		float exfrc=ex_exfrc[exforce_i];
		float r0=exforce_r[exforce_i];

		VECTOR dr = Get_Periodic_Displacement(uint_crd[atom_i], uint_crd[atom_j], scaler);

		float r1 = norm3df(dr.x, dr.y, dr.z);
		float delta_r = r1 - r0;

		exfrc_ene[exforce_i] = exfrc * delta_r;
	}
}

void EXFORCE::Initial(CONTROLLER* controller, char *module_name)
{
	controller[0].printf("START INITIALIZING EXFORCE:\n");
	if (module_name == NULL)
	{
		strcpy(this->module_name, "exforce");
	}
	else
	{
		strcpy(this->module_name, module_name);
	}
	if (controller[0].Command_Exist(this->module_name, "in_file"))
	{
		FILE *fp = NULL;
		Open_File_Safely(&fp, controller[0].Command(this->module_name, "in_file"), "r");

		fscanf(fp, "%d", &exforce_numbers);
		controller[0].printf("    bond_numbers is %d\n", exforce_numbers);
		Memory_Allocate();
		for (int i = 0; i < exforce_numbers; i++)
		{
			fscanf(fp, "%d %d %f", h_atom_a + i, h_atom_b + i, h_exfrc + i);
			*(h_exfrc + i)=*(h_exfrc + i) * 1000 / 69.4786;
			*(h_exforce_r + i) = 0;
		}
		printf("END (READING EXFORCE)\n");
		fclose(fp);
		Parameter_Host_To_Device();
		is_initialized = 1;

	}
	if (is_initialized && !is_controller_printf_initialized)
	{
		controller[0].Step_Print_Initial(this->module_name, "%.2f");
		is_controller_printf_initialized = 1;
		controller[0].printf("    structure last modify date is %d\n", last_modify_date);
	}
	controller[0].printf("END INITIALIZING EXFORCE\n\n");
}

void EXFORCE::Memory_Allocate()
{
	if (!Malloc_Safely((void**)&(this->h_atom_a), sizeof(int) * this->exforce_numbers))
		printf("        Error occurs when malloc EXFORCE::h_atom_a in EXFORCE::Exforce_Initialize");
	if (!Malloc_Safely((void**)&(this->h_atom_b), sizeof(int) * this->exforce_numbers))
		printf("        Error occurs when malloc EXFORCE::h_atom_b in EXFORCE::Exforce_Initialize");
	if (!Malloc_Safely((void**)&(this->h_exfrc), sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when malloc EXFORCE::h_exfrc in EXFORCE::Exforce_Initialize");
	if (!Malloc_Safely((void**)&(this->h_exfrc_ene), sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when malloc EXFORCE::h_exfrc_ene in EXFORCE::Exforce_Initialize");
	if (!Malloc_Safely((void**)&(this->h_sigma_of_exfrc_ene), sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when malloc EXFORCE::h_sigma_of_exfrc_ene in EXFORCE::Exforce_Initialize");
	if (!Malloc_Safely((void**)&(this->h_exforce_r), sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when malloc EXFORCE::h_exforce_r in EXFORCE::Exforce_Initialize");
	//if (!Malloc_Safely((void**)&(this->h_exfrc_y), sizeof(float) * this->exforce_numbers))
	//	printf("Error occurs when malloc EXFORCE::h_exfrc_y in EXFORCE::Exforce_Initialize");
	//if (!Malloc_Safely((void**)&(this->h_exfrc_z), sizeof(float) * this->exforce_numbers))
	//	printf("Error occurs when malloc EXFORCE::h_exfrc_z in EXFORCE::Exforce_Initialize");
	

	if (!Cuda_Malloc_Safely((void**)&this->d_atom_a, sizeof(int) * this->exforce_numbers))
		printf("        Error occurs when CUDA malloc EXFORCE::d_atom_a in EXFORCE::Exforce_Initialize");
	if (!Cuda_Malloc_Safely((void**)&this->d_atom_b, sizeof(int) * this->exforce_numbers))
		printf("        Error occurs when CUDA malloc EXFORCE::d_atom_b in EXFORCE::Exforce_Initialize");
	if (!Cuda_Malloc_Safely((void**)&this->d_exfrc, sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when CUDA malloc EXFORCE::d_exfrc in EXFORCE::Exforce_Initialize");
	if (!Cuda_Malloc_Safely((void**)&this->d_exfrc_ene, sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when CUDA malloc EXFORCE::d_exfrc_ene in EXFORCE::Exforce_Initialize");
	if (!Cuda_Malloc_Safely((void**)&this->d_sigma_of_exfrc_ene, sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when CUDA malloc EXFORCE::d_sigma_of_exfrc_ene in EXFORCE::Exforce_Initialize");
	if (!Cuda_Malloc_Safely((void**)&this->d_exforce_r, sizeof(float) * this->exforce_numbers))
		printf("        Error occurs when CUDA malloc EXFORCE::d_exforce_r in EXFORCE::Exforce_Initialize");
	//if (!Cuda_Malloc_Safely((void**)&this->d_exfrc_y, sizeof(float) * this->exforce_numbers))
	//	printf("Error occurs when CUDA malloc EXFORCE::d_exfrc_y in EXFORCE::Exforce_Initialize");
	//if (!Cuda_Malloc_Safely((void**)&this->d_exfrc_z, sizeof(float) * this->exforce_numbers))
	//	printf("Error occurs when CUDA malloc EXFORCE::d_exfrc_z in EXFORCE::Exforce_Initialize");
	
}


void EXFORCE::Parameter_Host_To_Device()
{
	cudaMemcpy(this->d_atom_a, this->h_atom_a, sizeof(int) * this->exforce_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(this->d_atom_b, this->h_atom_b, sizeof(int) * this->exforce_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(this->d_exfrc, this->h_exfrc, sizeof(float) * this->exforce_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(this->d_exfrc_ene, this->h_exfrc_ene, sizeof(float) * this->exforce_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(this->d_exforce_r, this->h_exforce_r, sizeof(float) * this->exforce_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(this->d_sigma_of_exfrc_ene, this->h_sigma_of_exfrc_ene, sizeof(float) * this->exforce_numbers, cudaMemcpyHostToDevice);
	//cudaMemcpy(this->d_exfrc_y, this->h_exfrc_y, sizeof(float) * this->exforce_numbers, cudaMemcpyHostToDevice);
	//cudaMemcpy(this->d_exfrc_z, this->h_exfrc_z, sizeof(float) * this->exforce_numbers, cudaMemcpyHostToDevice);
}

void EXFORCE::Clear()
{
	cudaFree(this->d_atom_a);
	cudaFree(this->d_atom_b);
	cudaFree(this->d_exfrc);
	cudaFree(this->d_exfrc_ene);
	cudaFree(this->d_sigma_of_exfrc_ene);
	cudaFree(this->d_exforce_r);
	//cudaFree(this->d_exfrc_y);
	//cudaFree(this->d_exfrc_z);

	free(this->h_atom_a);
	free(this->h_atom_b);
	free(this->h_exfrc);
	free(this->h_exfrc_ene);
	free(this->h_sigma_of_exfrc_ene);
	free(this->h_exforce_r);
	//free(this->h_exfrc_y);
	//free(this->h_exfrc_z);

	d_atom_a = NULL;
	d_atom_b = NULL;
	h_atom_a = NULL;
	h_atom_b = NULL;
	d_exfrc = NULL;
	h_exfrc = NULL;

	h_exfrc_ene = NULL;
	d_exfrc_ene = NULL;

	h_exforce_r = NULL;
	d_exforce_r = NULL;
	
	is_initialized = 0;
}

void EXFORCE::Exforce_Force_With_Atom_Energy_And_Virial(const UNSIGNED_INT_VECTOR* uint_crd, const VECTOR scaler, VECTOR* frc, float *atom_energy, float *atom_virial)
{
	if (is_initialized)
	{
		Exforce_Force_With_Atom_Energy_And_Virial_CUDA << <ceilf((float)this->exforce_numbers / this->threads_per_block), this->threads_per_block >> >
		(this->exforce_numbers, uint_crd, scaler,
			this->d_atom_a, this->d_atom_b, this->d_exforce_r, this->d_exfrc, frc, atom_energy, atom_virial);
	}
}

void EXFORCE::Exforce_Get_r(const UNSIGNED_INT_VECTOR* uint_crd, const VECTOR scaler)
{
	if (is_initialized)
	{
		Exforce_Get_r_CUDA<< <ceilf((float)this->exforce_numbers / this->threads_per_block), this->threads_per_block >> >
		(this->exforce_numbers, uint_crd, scaler,
			this->d_atom_a, this->d_atom_b, this->d_exforce_r);
	}
}

float EXFORCE::Get_Energy(const UNSIGNED_INT_VECTOR *uint_crd, const VECTOR scaler, int is_download)
{
	if (is_initialized)
	{
		Exforce_Energy_CUDA << <(unsigned int)ceilf((float)this->exforce_numbers / this->threads_per_block), this->threads_per_block >> >
			(this->exforce_numbers, uint_crd, scaler,
			this->d_atom_a, this->d_atom_b, this->d_exforce_r, this->d_exfrc,this->d_exfrc_ene);

		Sum_Of_List << <1, 1024 >> >(this->exforce_numbers, this->d_exfrc_ene, this->d_sigma_of_exfrc_ene);
		if (is_download)
		{
			cudaMemcpy(this->h_sigma_of_exfrc_ene, this->d_sigma_of_exfrc_ene, sizeof(float), cudaMemcpyDeviceToHost);
			return h_sigma_of_exfrc_ene[0];
		}
		else
		{
			return 0;
		}
	}
}

void EXFORCE::Energy_Device_To_Host()
{
	cudaMemcpy(this->h_sigma_of_exfrc_ene, this->d_sigma_of_exfrc_ene, sizeof(float), cudaMemcpyDeviceToHost);
}
