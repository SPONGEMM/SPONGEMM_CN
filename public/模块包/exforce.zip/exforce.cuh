﻿#ifndef EXFORCE_CUH
#define EXFORCE_CUH
#include "../common.cuh"
#include "../control.cuh"

struct EXFORCE
{
	char module_name[CHAR_LENGTH_MAX];
	int is_initialized = 0;
	int is_controller_printf_initialized = 0;
	int last_modify_date =20210529;

	int exforce_numbers = 0;
	int* h_atom_a;
	int* d_atom_a;
	int* h_atom_b;
	int* d_atom_b;
	float* h_exfrc;
	//float* h_exfrc_y;
	//float* h_exfrc_z;
	float* d_exfrc;
	//float* d_exfrc_y;
	//float* d_exfrc_z;
	//VECTOR* d_exfrc;
	//VECTOR* h_exfrc;
	float* h_exforce_r;
	float* d_exforce_r;

	float *h_exfrc_ene=NULL;
	float *d_exfrc_ene=NULL;
	float *d_sigma_of_exfrc_ene=NULL;
	float *h_sigma_of_exfrc_ene=NULL;

	int threads_per_block=128;

	//初始化
	void Initial(CONTROLLER* controller, char *module_name = NULL);
	void Memory_Allocate();

	//拷贝cpu中的数据到gpu
	void Parameter_Host_To_Device();

	//清除bond的空间
	void Clear();

	//计算添加外力的两个原子间的距离(整数坐标, 缩放因子)
	void Exforce_Get_r(const UNSIGNED_INT_VECTOR* uint_crd, const VECTOR scaler);
	//添加exfore (整数坐标，缩放因子（将整数坐标变为实数坐标），原子受力）
	void Exforce_Force_With_Atom_Energy_And_Virial(const UNSIGNED_INT_VECTOR* unit_crd, const VECTOR scaler, VECTOR* frc, float *atom_energy, float *atom_virial);
	//获得能量
	float Get_Energy(const UNSIGNED_INT_VECTOR *unit_crd, const VECTOR scaler, int is_download = 1);
	
	//将能量从gpu转移到cpu上
	void Energy_Device_To_Host();
};

#endif //EXFORCE(exforce_packed.cuh)
