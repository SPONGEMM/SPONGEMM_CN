#include "spring_cuboid_boundary_force.cuh"
void SPRING_CUBOID_BOUNDARY_INFORMATION::Initial(CONTROLLER *controller, VECTOR box_length, char *module_name)
{
	controller[0].printf("START INITIALIZING SPRING CUBOID BOUNDARY INFORMATION:\n");
	if (module_name == NULL)
	{
		strcpy(this->module_name, "Spring_Cuboid_Boundary");
	}
	else
	{
		strcpy(this->module_name, module_name);
	}
	if (controller[0].Command_Exist(this->module_name))
	{
		if (atoi(controller[0].Command(this->module_name)) == 1)
		{
			cuboid_vertex_000 = { 0., 0., 0. };
			cuboid_vertex_111 = box_length;

			if (controller[0].Command_Exist(this->module_name, "0x"))
			{
				sscanf(controller[0].Command(this->module_name, "0x"), "%f", &cuboid_vertex_000.x);
			}
			if (controller[0].Command_Exist(this->module_name, "0y"))
			{
				sscanf(controller[0].Command(this->module_name, "0y"), "%f", &cuboid_vertex_000.y);
			}
			if (controller[0].Command_Exist(this->module_name, "0z"))
			{
				sscanf(controller[0].Command(this->module_name, "0z"), "%f", &cuboid_vertex_000.z);
			}

			if (controller[0].Command_Exist(this->module_name, "1x"))
			{
				sscanf(controller[0].Command(this->module_name, "1x"), "%f", &cuboid_vertex_111.x);
			}
			if (controller[0].Command_Exist(this->module_name, "1y"))
			{
				sscanf(controller[0].Command(this->module_name, "1y"), "%f", &cuboid_vertex_111.y);
			}
			if (controller[0].Command_Exist(this->module_name, "1z"))
			{
				sscanf(controller[0].Command(this->module_name, "1z"), "%f", &cuboid_vertex_111.z);
			}
			controller[0].printf("    cuboid 000 is %f %f %f\n", cuboid_vertex_000.x, cuboid_vertex_000.y, cuboid_vertex_000.z);
			controller[0].printf("    cuboid 111 is %f %f %f\n", cuboid_vertex_111.x, cuboid_vertex_111.y, cuboid_vertex_111.z);


			k = 0.;
			if (controller[0].Command_Exist(this->module_name, "k"))
			{
				sscanf(controller[0].Command(this->module_name, "k"), "%f", &k);
			}
			controller[0].printf("    k is %f\n", k);

			Cuda_Malloc_Safely((void**)&boundary_total_energy, sizeof(float));
			controller[0].printf("    structure last modify date is %d\n", last_modify_date);
			is_initialized = 1;
		}
	}
	if (is_initialized && !is_controller_printf_initialized)
	{
		controller[0].Step_Print_Initial(this->module_name, "%.2f");
		is_controller_printf_initialized = 1;
	}
	if (is_initialized == 0)
	{
		printf("    No %s announced\n",this->module_name);
	}
	controller[0].printf("END INITIALIZING SPRING CUBOID BOUNDARY INFORMATION\n\n");
}
__global__ void Force_CUDA(const int atom_serial_start,const int atom_serial_end, const VECTOR *crd,
	const VECTOR cuboid_vertex_000, const VECTOR cuboid_vertex_111,const float k,
	VECTOR *frc)
{
	int atom_i = atom_serial_start+blockDim.x*blockIdx.x + threadIdx.x;
	if (atom_i < atom_serial_end)
	{
		VECTOR f;
		VECTOR temp_crd = crd[atom_i];
		//�����߽����������
		float dx=temp_crd.x - cuboid_vertex_000.x;
		f.x = -(float)signbit(dx)*dx;
		dx = cuboid_vertex_111.x - temp_crd.x;
		f.x = f.x + (float)signbit(dx)*dx;

		dx = temp_crd.y - cuboid_vertex_000.y;
		f.y = -(float)signbit(dx)*dx;
		dx = cuboid_vertex_111.y - temp_crd.y;
		f.y = f.y + (float)signbit(dx)*dx;

		dx = temp_crd.z - cuboid_vertex_000.z;
		f.z = -(float)signbit(dx)*dx;
		dx = cuboid_vertex_111.z - temp_crd.z;
		f.z = f.z + (float)signbit(dx)*dx;

		atomicAdd(&frc[atom_i].x, k*f.x);
		atomicAdd(&frc[atom_i].y, k*f.y);
		atomicAdd(&frc[atom_i].z, k*f.z);
	}
}
__global__ void Total_Energy_CUDA(const int atom_serial_start, const int atom_serial_end, const VECTOR *crd,
	const VECTOR cuboid_vertex_000, const VECTOR cuboid_vertex_111, const float k,
	float *boundary_total_energy)
{
	if (threadIdx.x == 0)
	{
		boundary_total_energy[0] = 0;
	}
	__syncthreads();
	float temp_energy = 0;
	VECTOR temp_crd;
	float dx;
	for (int i = threadIdx.x + atom_serial_start; i < atom_serial_end; i = i + blockDim.x)
	{
		temp_crd = crd[i];

		dx = temp_crd.x - cuboid_vertex_000.x;
		temp_energy = temp_energy + (float)signbit(dx)*dx*dx;
		dx = cuboid_vertex_111.x - temp_crd.x;
		temp_energy = temp_energy + (float)signbit(dx)*dx*dx;

		dx = temp_crd.y - cuboid_vertex_000.y;
		temp_energy = temp_energy + (float)signbit(dx)*dx*dx;
		dx = cuboid_vertex_111.y - temp_crd.y;
		temp_energy = temp_energy + (float)signbit(dx)*dx*dx;

		dx = temp_crd.z - cuboid_vertex_000.z;
		temp_energy = temp_energy + (float)signbit(dx)*dx*dx;
		dx = cuboid_vertex_111.z - temp_crd.z;
		temp_energy = temp_energy + (float)signbit(dx)*dx*dx;
	}
	atomicAdd(boundary_total_energy, 0.5*k*temp_energy);
}
void SPRING_CUBOID_BOUNDARY_INFORMATION::Force(const int atom_serial_start, const int atom_serial_end, const VECTOR *crd, VECTOR *frc)
{
	if (is_initialized)
	{
		int compute_atom_numbers = atom_serial_end - atom_serial_start;
		Force_CUDA
			<< <ceilf((float)compute_atom_numbers / this->threads_per_block), this->threads_per_block >> >
			(atom_serial_start, atom_serial_end, crd,
			cuboid_vertex_000, cuboid_vertex_111, k,
			frc);
	}
}
float SPRING_CUBOID_BOUNDARY_INFORMATION::Energy(const int atom_serial_start, const int atom_serial_end, const VECTOR *crd, int is_download)
{
	if (is_initialized)
	{
		Total_Energy_CUDA
			<< <1, 256 >> >
			(atom_serial_start, atom_serial_end, crd,
			cuboid_vertex_000, cuboid_vertex_111, k,
			boundary_total_energy);
		if (is_download)
		{
			cudaMemcpy(&h_boundary_total_energy, boundary_total_energy, sizeof(float), cudaMemcpyDeviceToHost);
			return h_boundary_total_energy;
		}
		else
		{
			return 0.;
		}
	}
	else
	{
		return 0.;
	}
}