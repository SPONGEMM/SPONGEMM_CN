#include "DPD_force.cuh"
static __global__ void DPD_Force_CUDA(
	const int atom_numbers, const ATOM_GROUP *nl,
	const UINT_VECTOR_LJ_TYPE *uint_crd, const VECTOR boxlength,
	const float *DPD_type_A, const float *DPD_type_B,const float *DPD_type_C,
	const float cutoff,const float k,
	VECTOR *frc,const VECTOR *vel,const float *random_frc,const int max_numbers )
{

	int atom_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (atom_i < atom_numbers)
	{
		ATOM_GROUP nl_i = nl[atom_i];
		int N = nl_i.atom_numbers;
		int Bp = ceilf((float)N / blockDim.y);
		int atom_j;
		int int_x;
		int int_y;
		int int_z;
		//int kkk=0;
		UINT_VECTOR_LJ_TYPE r1 = uint_crd[atom_i], r2;
		VECTOR v1 = vel[atom_i], v2;
		VECTOR dr, dv;
		float dr_abs, mid, rinv, cross, sigma;  //randnum
		float frc_abs = 0.;
		VECTOR frc_lin;
		VECTOR frc_record = { 0., 0., 0. };

		int x, y;
		int atom_pair_DPD_type;

		float A, B, C, rand_;
		for (int j = threadIdx.y*Bp; j < (threadIdx.y + 1)*Bp; j = j + 1)//����ѭ����ʽ������ĺ�����ѭ����ʽ����
		{
			if (j < N)
			{
				atom_j = nl_i.atom_serial[j];
				r2 = uint_crd[atom_j];
				v2 = vel[atom_j];
				int_x = r1.uint_x - r2.uint_x;
				int_y = r1.uint_y - r2.uint_y;
				int_z = r1.uint_z - r2.uint_z;
				dv.x = v1.x - v2.x;
				dv.y = v1.y - v2.y;
				dv.z = v1.z - v2.z;
				dr.x = boxlength.x*int_x;
				dr.y = boxlength.y*int_y;
				dr.z = boxlength.z*int_z;
				dr_abs = norm3df(dr.x, dr.y, dr.z);
				cross = dr.x*dv.x + dr.y*dv.y + dr.z*dv.z;
				rinv = 1.0 / dr_abs;

				if (dr_abs < cutoff)
				{

					y = (r2.LJ_type - r1.LJ_type);
					x = y >> 31;
					y = (y^x) - x;
					x = r2.LJ_type + r1.LJ_type;
					r2.LJ_type = (x + y) >> 1;
					x = (x - y) >> 1;
					atom_pair_DPD_type = (r2.LJ_type*(r2.LJ_type + 1) >> 1) + x;

					C = DPD_type_C[atom_pair_DPD_type];
					if (dr_abs < C)
					{
						A = DPD_type_A[atom_pair_DPD_type];
						B = DPD_type_B[atom_pair_DPD_type];
						rand_ = random_frc[atom_i * max_numbers + j];

						mid = 1.0 - dr_abs / C;
						//k=sqrtf(2.0*CONSTANT_kB*target_temperature / dt);
						sigma = k*sqrtf(B);
						rand_ = rand_*sigma*mid;

						frc_abs = A * mid;
						frc_abs = frc_abs - B * mid*mid*cross*rinv;   ///*15.0
						frc_abs = (frc_abs + rand_)*rinv;

						frc_lin.x = (frc_abs)*dr.x;
						frc_lin.y = (frc_abs)*dr.y;
						frc_lin.z = (frc_abs)*dr.z;

						frc_record.x = frc_record.x + frc_lin.x;
						frc_record.y = frc_record.y + frc_lin.y;
						frc_record.z = frc_record.z + frc_lin.z;

						atomicAdd(&frc[atom_j].x, -frc_lin.x);
						atomicAdd(&frc[atom_j].y, -frc_lin.y);
						atomicAdd(&frc[atom_j].z, -frc_lin.z);
					}
				}
			}
		}//atom_j cycle
		atomicAdd(&frc[atom_i].x, frc_record.x);
		atomicAdd(&frc[atom_i].y, frc_record.y);
		atomicAdd(&frc[atom_i].z, frc_record.z);
	}
}
static __global__ void DPD_Energy_CUDA(
	const int atom_numbers, const ATOM_GROUP *nl,
	const UINT_VECTOR_LJ_TYPE *uint_crd, const VECTOR boxlength,
	const float *DPD_type_A,  const float *DPD_type_C,
	const float cutoff, 
	float *d_DPD_energy_atom)
{

	int atom_i = blockDim.x*blockIdx.x + threadIdx.x;
	if (atom_i < atom_numbers)
	{
		ATOM_GROUP nl_i = nl[atom_i];
		int N = nl_i.atom_numbers;
		int Bp = ceilf((float)N / blockDim.y);
		int atom_j;
		int int_x;
		int int_y;
		int int_z;
		//int kkk=0;
		UINT_VECTOR_LJ_TYPE r1 = uint_crd[atom_i], r2;
		VECTOR dr;
		float dr_abs, mid;  //randnum

		int x, y;
		int atom_pair_DPD_type;

		float A, C;
		float ene_lin = 0.;
		for (int j = threadIdx.y*Bp; j < (threadIdx.y + 1)*Bp; j = j + 1)//����ѭ����ʽ������ĺ�����ѭ����ʽ����
		{
			if (j < N)
			{
				atom_j = nl_i.atom_serial[j];
				r2 = uint_crd[atom_j];
				int_x = r1.uint_x - r2.uint_x;
				int_y = r1.uint_y - r2.uint_y;
				int_z = r1.uint_z - r2.uint_z;
				dr.x = boxlength.x*int_x;
				dr.y = boxlength.y*int_y;
				dr.z = boxlength.z*int_z;
				dr_abs = norm3df(dr.x, dr.y, dr.z);
				if (dr_abs < cutoff)
				{

					y = (r2.LJ_type - r1.LJ_type);
					x = y >> 31;
					y = (y^x) - x;
					x = r2.LJ_type + r1.LJ_type;
					r2.LJ_type = (x + y) >> 1;
					x = (x - y) >> 1;
					atom_pair_DPD_type = (r2.LJ_type*(r2.LJ_type + 1) >> 1) + x;

					A = DPD_type_A[atom_pair_DPD_type];
					C = DPD_type_C[atom_pair_DPD_type];
					if (dr_abs < C)
					{
						mid = 1.0 - dr_abs / C;
						ene_lin = ene_lin + 0.5*A*C*mid*mid;
					}
				}
			}
		}//atom_j cycle
		atomicAdd(&d_DPD_energy_atom[atom_i], ene_lin);
	}
}
void DISSIPATIVE_PARTICLE_DYNAMICS_INFORMATION::Initial(CONTROLLER *controller, float cutoff, VECTOR box_length,int max_neighbor_numbers,float dt, char *module_name)
{
	if (module_name == NULL)
	{
		strcpy(this->module_name, "DPD");
	}
	else
	{
		strcpy(this->module_name, module_name);
	}
	controller[0].printf("START INITIALIZING DISSIPATIVE PARTICLE DYNAMICS INFORMATION:\n");
	if (controller[0].Command_Exist(this->module_name, "in_file"))
	{
		FILE *fp = NULL;
		Open_File_Safely(&fp, controller[0].Command(this->module_name, "in_file"), "r");

		fscanf(fp, "%d %d", &atom_numbers, &atom_type_numbers);
		controller[0].printf("    atom_numbers is %d\n", atom_numbers);
		controller[0].printf("    atom_DPD_type_number is %d\n", atom_type_numbers);
		pair_type_numbers = atom_type_numbers * (atom_type_numbers + 1) / 2;
		DPD_Malloc();

		for (int i = 0; i < pair_type_numbers; i++)
		{
			fscanf(fp, "%f", h_DPD_A + i);
		}
		for (int i = 0; i < pair_type_numbers; i++)
		{
			fscanf(fp, "%f", h_DPD_B + i);
		}
		for (int i = 0; i < pair_type_numbers; i++)
		{
			fscanf(fp, "%f", h_DPD_C + i);
		}
		for (int i = 0; i < atom_numbers; i++)
		{
			fscanf(fp, "%d", h_atom_DPD_type + i);
		}
		fclose(fp);
		Parameter_Host_To_Device();

		if (controller[0].Command_Exist(this->module_name, "target_temperature"))
		{
			target_temperature = atof(controller[0].Command(this->module_name, "target_temperature"));
			controller[0].printf("    DPD target_temperature is %f\n", target_temperature);
		}
		else
		{
			target_temperature = 300.;
			controller[0].printf("    DPD target_temperature set default %f\n", target_temperature);
		}

		if (controller[0].Command_Exist(this->module_name, "rand_seed"))
		{
			sscanf(controller[0].Command(this->module_name, "rand_seed"),"%d",&rand_seed);
			controller[0].printf("    DPD rand seed is %d\n", rand_seed);
		}
		else
		{
			rand_seed = 0;
			controller[0].printf("    DPD rand seed set default %d\n", rand_seed);
		}

		//random initial
		this->max_neighbor_numbers = max_neighbor_numbers;
		float4_numbers = ceil((double)atom_numbers*max_neighbor_numbers / 4.);
		Cuda_Malloc_Safely((void**)&random_force, sizeof(float4)* float4_numbers);
		Cuda_Malloc_Safely((void**)&rand_state, sizeof(curandStatePhilox4_32_10_t)* float4_numbers);
		Setup_Rand_Normal_Kernel << <(unsigned int)ceilf((float)float4_numbers / threads_per_block), threads_per_block >> >
			(float4_numbers, rand_state, rand_seed);

		is_initialized = 1;
	}
	if (is_initialized)
	{
		this->dt = dt;
		this->cutoff = cutoff;
		k = sqrtf(2.0*CONSTANT_kB*target_temperature / dt);

		this->uint_dr_to_dr_cof = 1.0f / CONSTANT_UINT_MAX_FLOAT * box_length;
		Cuda_Malloc_Safely((void **)&uint_crd_with_DPD, sizeof(UINT_VECTOR_LJ_TYPE)* atom_numbers);
		Copy_LJ_Type_To_New_Crd << <ceilf((float)this->atom_numbers / 32), 32 >> >
			(atom_numbers, uint_crd_with_DPD, d_atom_DPD_type);
	}
	if (is_initialized && !is_controller_printf_initialized)
	{
		controller[0].Step_Print_Initial(this->module_name, "%.2f");
		is_controller_printf_initialized = 1;
		controller[0].printf("    structure last modify date is %d\n", last_modify_date);
	}
	controller[0].printf("END INITIALIZING DISSIPATIVE PARTICLE DYNAMICS INFORMATION\n\n");
}
void DISSIPATIVE_PARTICLE_DYNAMICS_INFORMATION::DPD_Malloc()
{
	Malloc_Safely((void**)&h_DPD_energy_sum, sizeof(float));
	Malloc_Safely((void**)&h_DPD_energy_atom, sizeof(float)*atom_numbers);
	Malloc_Safely((void**)&h_atom_DPD_type, sizeof(int)*atom_numbers);
	Malloc_Safely((void**)&h_DPD_A, sizeof(float)*pair_type_numbers);
	Malloc_Safely((void**)&h_DPD_B, sizeof(float)*pair_type_numbers);
	Malloc_Safely((void**)&h_DPD_C, sizeof(float)*pair_type_numbers);

	Cuda_Malloc_Safely((void**)&d_DPD_energy_sum, sizeof(float));
	Cuda_Malloc_Safely((void**)&d_DPD_energy_atom, sizeof(float)*atom_numbers);
	Cuda_Malloc_Safely((void**)&d_atom_DPD_type, sizeof(int)*atom_numbers);
	Cuda_Malloc_Safely((void**)&d_DPD_A, sizeof(float)*pair_type_numbers);
	Cuda_Malloc_Safely((void**)&d_DPD_B, sizeof(float)*pair_type_numbers);
	Cuda_Malloc_Safely((void**)&d_DPD_C, sizeof(float)*pair_type_numbers);
}
void DISSIPATIVE_PARTICLE_DYNAMICS_INFORMATION::Parameter_Host_To_Device()
{
	cudaMemcpy(d_DPD_B, h_DPD_B, sizeof(float)*pair_type_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(d_DPD_A, h_DPD_A, sizeof(float)*pair_type_numbers, cudaMemcpyHostToDevice);
	cudaMemcpy(d_DPD_C, h_DPD_C, sizeof(float)*pair_type_numbers, cudaMemcpyHostToDevice);

	cudaMemcpy(d_atom_DPD_type, h_atom_DPD_type, sizeof(int)*atom_numbers, cudaMemcpyHostToDevice);
}
void DISSIPATIVE_PARTICLE_DYNAMICS_INFORMATION::DPD_Force(const UNSIGNED_INT_VECTOR *uint_crd,const float *charge, const ATOM_GROUP *nl, const VECTOR *vel, VECTOR *frc)
{
	if (is_initialized)
	{
		Copy_Crd_And_Charge_To_New_Crd << <(unsigned int)ceilf((float)atom_numbers / 32), 32 >> >(atom_numbers, uint_crd, uint_crd_with_DPD, charge);
		Rand_Normal << <ceilf((float)float4_numbers / 32.), 32 >> >
			(float4_numbers, rand_state, (float4 *)random_force);
		DPD_Force_CUDA << <(unsigned int)ceilf((float)atom_numbers / thread_DPD.x), thread_DPD >> >
			(atom_numbers, nl,
			uint_crd_with_DPD, uint_dr_to_dr_cof,
			d_DPD_A, d_DPD_B,d_DPD_C, cutoff,k,
			frc, vel, (float*)random_force, max_neighbor_numbers);
	}
}
float DISSIPATIVE_PARTICLE_DYNAMICS_INFORMATION::DPD_Energy(const UNSIGNED_INT_VECTOR *uint_crd, const float *charge, const ATOM_GROUP *nl, int is_download)
{
	if (is_initialized)
	{
		Copy_Crd_And_Charge_To_New_Crd << <(unsigned int)ceilf((float)atom_numbers / 32), 32 >> >(atom_numbers, uint_crd, uint_crd_with_DPD, charge);

		Reset_List(d_DPD_energy_atom, 0.0f, atom_numbers, 1024);
		DPD_Energy_CUDA << <(unsigned int)ceilf((float)atom_numbers / thread_DPD.x), thread_DPD >> >
			(atom_numbers, nl,
			uint_crd_with_DPD, uint_dr_to_dr_cof,
			d_DPD_A, d_DPD_C,
			cutoff, d_DPD_energy_atom);
		Sum_Of_List(d_DPD_energy_atom, d_DPD_energy_sum, atom_numbers);
		if (is_download == 1)
		{
			cudaMemcpy(&h_DPD_energy_sum, d_DPD_energy_sum, sizeof(float), cudaMemcpyDeviceToHost);
			return h_DPD_energy_sum;
		}
		else
		{
			return 0.;
		}
	}
	else
	{
		return 0.;
	}
}
void DISSIPATIVE_PARTICLE_DYNAMICS_INFORMATION::Clear()
{
	if (is_initialized)
	{
		free(h_atom_DPD_type),h_atom_DPD_type=NULL;
		cudaFree(d_atom_DPD_type),d_atom_DPD_type=NULL;

		free(h_DPD_A), h_DPD_A = NULL;
		cudaFree(d_DPD_A), d_DPD_A = NULL;
		free(h_DPD_B), h_DPD_B = NULL;
		cudaFree(d_DPD_B), d_DPD_B = NULL;
		free(h_DPD_C), h_DPD_C = NULL;
		cudaFree(d_DPD_C), d_DPD_C = NULL;

		free(h_DPD_energy_atom), h_DPD_energy_atom = NULL;
		cudaFree(d_DPD_energy_atom), d_DPD_energy_atom = NULL;
		cudaFree(d_DPD_energy_sum), d_DPD_energy_sum = NULL;

		cudaFree(random_force), random_force = NULL;
		cudaFree(rand_state), rand_state = NULL;
		cudaFree(uint_crd_with_DPD), uint_crd_with_DPD = NULL;

		is_initialized = 0;
	}
}